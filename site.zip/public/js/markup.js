// Texto formatado das novidades, sem HTML.
//
// O texto que o admin escreve usa um conjunto pequeno de marcas. Tudo vira elementos do
// DOM criados por código, então nada do que vem do banco pode virar HTML ou script.
//
//   ## Título         subtítulo grande
//   ### Título        subtítulo menor
//   - item            lista (uma linha por item, todas começando com "- ")
//   > texto           citação
//   **negrito**       negrito
//   `código`          trecho de código
//   [texto](https://endereço)   link (só https)
//   ![descrição](imagem:2)      imagem número 2 do post (de 1 a 6), sozinha num parágrafo
//
// Parágrafos são separados por uma linha em branco. Quebra de linha simples vira quebra de linha.

import { h } from './dom.js';

const INLINE = /(\*\*[^*\n]+\*\*)|(`[^`\n]+`)|(\[[^\]\n]+\]\(https:\/\/[^\s)]+\))/g;

function inline(texto) {
  const nos = [];
  let ultimo = 0;
  for (const achado of texto.matchAll(INLINE)) {
    if (achado.index > ultimo) nos.push(texto.slice(ultimo, achado.index));
    const marca = achado[0];
    if (marca.startsWith('**')) {
      nos.push(h('strong', {}, marca.slice(2, -2)));
    } else if (marca.startsWith('`')) {
      nos.push(h('code', {}, marca.slice(1, -1)));
    } else {
      const fim = marca.lastIndexOf('](');
      const rotulo = marca.slice(1, fim);
      const endereco = marca.slice(fim + 2, -1);
      nos.push(h('a', { href: endereco, target: '_blank', rel: 'noopener noreferrer' }, rotulo));
    }
    ultimo = achado.index + marca.length;
  }
  if (ultimo < texto.length) nos.push(texto.slice(ultimo));
  return nos;
}

function comQuebras(linhas) {
  const nos = [];
  linhas.forEach((linha, i) => {
    if (i > 0) nos.push(h('br'));
    nos.push(...inline(linha));
  });
  return nos;
}

// Devolve { nos, imagens }. "imagens" é um Map: número da imagem -> elemento <img> sem endereço
// ainda; a página preenche o "src" quando as imagens chegarem do banco.
export function renderizarCorpo(texto) {
  const nos = [];
  const imagens = new Map();
  const blocos = String(texto)
    .replace(/\r\n?/g, '\n')
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter(Boolean);

  for (const bloco of blocos) {
    const linhas = bloco.split('\n');

    let achado = /^(#{2,3}) (.+)$/.exec(bloco);
    if (linhas.length === 1 && achado) {
      nos.push(h(achado[1].length === 2 ? 'h2' : 'h3', {}, ...inline(achado[2])));
      continue;
    }

    achado = /^!\[([^\]\n]*)\]\(imagem:([1-6])\)$/.exec(bloco);
    if (achado) {
      const numero = Number(achado[2]);
      const alt = achado[1].slice(0, 120);
      const img = h('img', { alt, loading: 'lazy' });
      imagens.set(numero, img);
      const figura = h('figure', { class: 'corpo-figura' }, img, alt ? h('figcaption', {}, alt) : null);
      figura.hidden = true;
      img.addEventListener('load', () => {
        figura.hidden = false;
      });
      nos.push(figura);
      continue;
    }

    if (linhas.every((l) => l.startsWith('- '))) {
      nos.push(h('ul', {}, linhas.map((l) => h('li', {}, ...inline(l.slice(2))))));
      continue;
    }

    if (linhas.every((l) => l.startsWith('> '))) {
      nos.push(h('blockquote', {}, h('p', {}, ...comQuebras(linhas.map((l) => l.slice(2))))));
      continue;
    }

    nos.push(h('p', {}, ...comQuebras(linhas)));
  }

  return { nos, imagens };
}
