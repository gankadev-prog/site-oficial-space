// Botão de conta no topo do site: "Entrar", "@nick" ou "Concluir cadastro".
// Fica num módulo à parte para o resto do site abrir sem esperar o Firebase carregar.

import { iniciarAuth, ouvirAuth } from './auth.js';

export function iniciarTopoConta(link) {
  function mostrar(estado) {
    if (estado.usuario && estado.perfil) {
      link.textContent = '@' + estado.perfil.nick;
      link.setAttribute('href', '/conta');
      link.setAttribute('aria-label', 'Minha conta, @' + estado.perfil.nick);
    } else if (estado.usuario && !estado.erroPerfil) {
      link.textContent = 'Concluir cadastro';
      link.setAttribute('href', '/cadastrar');
      link.removeAttribute('aria-label');
    } else {
      link.textContent = 'Entrar';
      link.setAttribute('href', '/entrar');
      link.removeAttribute('aria-label');
    }
    link.hidden = false;
  }

  ouvirAuth(mostrar);
  iniciarAuth();
}
