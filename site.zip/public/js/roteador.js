// Roteador pequeno com History API. O Firebase Hosting devolve o index.html para qualquer
// endereço (veja "rewrites" no firebase.json) e este arquivo decide qual página montar.

import { h } from './dom.js';

const TITULO_PADRAO = 'Space Store e Creator Space — apps Android de um desenvolvedor independente';
const DESCRICAO_PADRAO =
  'Space Store, loja de apps e jogos para Android, e Creator Space, painel para desenvolvedores. Downloads, novidades, comunidade e regras, por Guilherme Lucena Gonçalves.';
const SUFIXO_TITULO = ' · Space';

let rotas = [];
let rotaNaoEncontrada = null;
let raiz = null;
let aoMudar = () => {};
let contador = 0;
let caminhoRenderizado = null;
let primeiraPagina = true;

function compilar(caminho) {
  const chaves = [];
  const escapado = caminho.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const padrao = escapado.replace(/:([a-zA-Z]+)/g, (_, nome) => {
    chaves.push(nome);
    return '([^/]+)';
  });
  return { regex: new RegExp('^' + padrao + '$'), chaves };
}

export function definirRotas(lista, naoEncontrada) {
  rotas = lista.map((rota) => ({ ...rota, ...compilar(rota.caminho) }));
  rotaNaoEncontrada = naoEncontrada;
}

function normalizar(caminho) {
  if (caminho.length <= 1) return '/';
  return caminho.replace(/\/+$/, '') || '/';
}

function procurar(caminho) {
  for (const rota of rotas) {
    const resultado = rota.regex.exec(caminho);
    if (!resultado) continue;
    const params = {};
    rota.chaves.forEach((nome, i) => {
      try {
        params[nome] = decodeURIComponent(resultado[i + 1]);
      } catch (erro) {
        params[nome] = resultado[i + 1];
      }
    });
    return { rota, params };
  }
  return null;
}

function paginaDeErro() {
  return {
    titulo: 'Algo deu errado',
    semIndexar: true,
    conteudo: h(
      'section',
      { class: 'pagina-curta' },
      h(
        'div',
        { class: 'container' },
        h('h1', {}, 'Não consegui abrir esta página'),
        h(
          'p',
          { class: 'lead' },
          'Pode ser a conexão ou um erro meu. Tente recarregar. Se continuar, me escreva em spacestorew@gmail.com.'
        ),
        h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/' }, 'Voltar ao início'))
      )
    ),
  };
}

function definirIndexacao(semIndexar) {
  let meta = document.querySelector('meta[name="robots"]');
  if (semIndexar) {
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'robots');
      document.head.append(meta);
    }
    meta.setAttribute('content', 'noindex');
  } else if (meta) {
    meta.remove();
  }
}

// Dados estruturados (JSON-LD) da página, para os buscadores. É só dado, nunca executa.
function definirJsonLd(dados) {
  let el = document.getElementById('jsonld-pagina');
  if (!dados) {
    if (el) el.remove();
    return;
  }
  if (!el) {
    el = document.createElement('script');
    el.id = 'jsonld-pagina';
    el.type = 'application/ld+json';
    document.head.append(el);
  }
  el.textContent = JSON.stringify(dados);
}

function definirMeta(pagina) {
  document.title = pagina.titulo ? pagina.titulo + SUFIXO_TITULO : TITULO_PADRAO;
  const meta = document.querySelector('meta[name="description"]');
  if (meta) meta.setAttribute('content', pagina.descricao || DESCRICAO_PADRAO);
  definirIndexacao(Boolean(pagina.semIndexar));
  definirJsonLd(pagina.jsonld);
}

function idDoHash() {
  const hash = window.location.hash.slice(1);
  if (!hash) return '';
  try {
    return decodeURIComponent(hash);
  } catch (erro) {
    return hash;
  }
}

function posicionar() {
  const id = idDoHash();
  const alvo = id ? document.getElementById(id) : null;

  if (alvo) {
    alvo.scrollIntoView();
    if (!alvo.hasAttribute('tabindex')) alvo.setAttribute('tabindex', '-1');
    alvo.focus({ preventScroll: true });
  } else {
    window.scrollTo(0, 0);
    // Leva o foco ao título para quem usa leitor de tela ou teclado perceber a troca de página.
    // Na primeira abertura não mexe no foco.
    if (!primeiraPagina) {
      const titulo = raiz.querySelector('h1');
      if (titulo) {
        titulo.setAttribute('tabindex', '-1');
        titulo.focus({ preventScroll: true });
      }
    }
  }
  primeiraPagina = false;
}

async function renderizar() {
  const minhaVez = ++contador;
  const caminho = normalizar(window.location.pathname);
  const achado = procurar(caminho);
  const rota = achado ? achado.rota : rotaNaoEncontrada;
  const contexto = { caminho, params: achado ? achado.params : {}, dados: rota.dados || {} };

  let pagina;
  try {
    const modulo = await rota.carregar();
    pagina = await modulo.default(contexto);
  } catch (erro) {
    console.error('Erro ao abrir a página', caminho, erro);
    pagina = paginaDeErro();
  }

  // Se a pessoa clicou em outro link enquanto esta página carregava, descarta esta.
  if (minhaVez !== contador) return;

  raiz.replaceChildren(pagina.conteudo);
  definirMeta(pagina);
  caminhoRenderizado = window.location.pathname + window.location.search;
  aoMudar(caminho);
  posicionar();
}

export function navegar(destino, { substituir = false } = {}) {
  const url = new URL(destino, window.location.href);
  if (url.origin !== window.location.origin) {
    window.location.assign(url.href);
    return Promise.resolve();
  }
  const novo = url.pathname + url.search + url.hash;
  if (substituir) {
    window.history.replaceState(null, '', novo);
  } else {
    window.history.pushState(null, '', novo);
  }
  return renderizar();
}

function aoClicar(evento) {
  if (evento.defaultPrevented || evento.button !== 0) return;
  if (evento.metaKey || evento.ctrlKey || evento.shiftKey || evento.altKey) return;

  const link = evento.target.closest ? evento.target.closest('a') : null;
  if (!link || !link.getAttribute('href')) return;
  if (link.target && link.target !== '_self') return;
  if (link.hasAttribute('download')) return;

  const url = new URL(link.href, window.location.href);
  if (url.origin !== window.location.origin) return;
  // Arquivos (sitemap.xml, imagens etc.) o navegador abre normalmente.
  if (/\.[a-z0-9]+$/i.test(url.pathname)) return;

  const mesmaPagina = url.pathname === window.location.pathname && url.search === window.location.search;
  if (mesmaPagina && url.hash && url.hash !== window.location.hash) return; // âncora na mesma página

  evento.preventDefault();

  if (mesmaPagina && url.hash === window.location.hash) {
    posicionar();
    return;
  }
  navegar(url.pathname + url.search + url.hash);
}

export function iniciarRoteador({ raiz: elementoRaiz, aoMudar: callback }) {
  raiz = elementoRaiz;
  if (callback) aoMudar = callback;

  document.addEventListener('click', aoClicar);
  window.addEventListener('popstate', () => {
    if (window.location.pathname + window.location.search === caminhoRenderizado) {
      posicionar();
      return;
    }
    renderizar();
  });

  return renderizar();
}
