// Formatação de tamanhos, datas e dados vindos do Firestore. Tudo que vem do banco é
// tratado como não confiável: imagens e links só passam se tiverem a forma esperada.

export function formatarBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '—';
  const unidades = ['B', 'KB', 'MB', 'GB'];
  let valor = bytes;
  let i = 0;
  while (valor >= 1024 && i < unidades.length - 1) {
    valor /= 1024;
    i += 1;
  }
  const numero = valor.toLocaleString('pt-BR', { maximumFractionDigits: i === 0 ? 0 : 1 });
  return numero + ' ' + unidades[i];
}

export function formatarData(carimbo) {
  if (!carimbo || typeof carimbo.toDate !== 'function') return '—';
  return carimbo.toDate().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
}

const ANDROID_POR_API = {
  21: '5.0',
  22: '5.1',
  23: '6.0',
  24: '7.0',
  25: '7.1',
  26: '8.0',
  27: '8.1',
  28: '9',
  29: '10',
  30: '11',
  31: '12',
  32: '12L',
  33: '13',
  34: '14',
  35: '15',
  36: '16',
};

export function androidDeApi(api) {
  return ANDROID_POR_API[api] || 'API ' + api;
}

const PERMISSOES = {
  INTERNET: 'Acesso à internet',
  ACCESS_NETWORK_STATE: 'Ver o estado da conexão',
  ACCESS_WIFI_STATE: 'Ver o estado do Wi-Fi',
  CAMERA: 'Usar a câmera',
  RECORD_AUDIO: 'Gravar áudio',
  READ_EXTERNAL_STORAGE: 'Ler arquivos do armazenamento',
  WRITE_EXTERNAL_STORAGE: 'Gravar arquivos no armazenamento',
  READ_MEDIA_IMAGES: 'Ler imagens do aparelho',
  READ_MEDIA_VIDEO: 'Ler vídeos do aparelho',
  READ_MEDIA_AUDIO: 'Ler áudios do aparelho',
  MANAGE_EXTERNAL_STORAGE: 'Acesso amplo aos arquivos',
  SYSTEM_ALERT_WINDOW: 'Mostrar por cima de outros apps',
  POST_NOTIFICATIONS: 'Enviar notificações',
  FOREGROUND_SERVICE: 'Rodar em primeiro plano',
  REQUEST_INSTALL_PACKAGES: 'Pedir para instalar apps',
  QUERY_ALL_PACKAGES: 'Ver a lista de apps instalados',
  PACKAGE_USAGE_STATS: 'Ver o uso de outros apps',
  VIBRATE: 'Vibrar',
  WAKE_LOCK: 'Manter o aparelho acordado',
  RECEIVE_BOOT_COMPLETED: 'Iniciar junto com o aparelho',
  MODIFY_AUDIO_SETTINGS: 'Mudar configurações de áudio',
};

// Devolve { rotulo, id } para mostrar uma permissão do Android.
export function descreverPermissao(id) {
  const texto = typeof id === 'string' ? id : '';
  const curto = texto.split('.').pop();
  return { rotulo: PERMISSOES[curto] || curto || 'Permissão', id: texto };
}

const MIMES_IMAGEM = ['image/png', 'image/jpeg', 'image/webp'];

// Monta um endereço "data:" só se o tipo e o conteúdo forem de imagem em Base64 de verdade.
export function imagemBase64(mime, base64, tamanhoMaximo = 200000) {
  if (!MIMES_IMAGEM.includes(mime)) return null;
  if (typeof base64 !== 'string' || base64.length === 0 || base64.length > tamanhoMaximo) return null;
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) return null;
  return `data:${mime};base64,${base64}`;
}

// Os APKs ficam no GitHub. Qualquer outro endereço não vira botão de download.
export function apkUrlSegura(url) {
  return typeof url === 'string' && /^https:\/\/github\.com\/[A-Za-z0-9._~%+/-]+$/.test(url) && url.length <= 400;
}

export function relatorioSeguro(url) {
  return typeof url === 'string' && /^https:\/\/www\.virustotal\.com\/[\x21-\x7E]*$/.test(url) && url.length <= 300;
}

export function ehHashSha256(valor) {
  return typeof valor === 'string' && /^[a-f0-9]{64}$/.test(valor);
}
