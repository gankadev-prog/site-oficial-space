// Login, cadastro e perfil. Todo o resto do site pergunta aqui quem está logado.
//
// Estado: { pronto, usuario, perfil, erroPerfil }
//  - usuario: a conta do Firebase Authentication (ou null)
//  - perfil: o documento usuarios/{uid} (ou null, quando a conta ainda não completou o cadastro)
//  - erroPerfil: true se não deu para ler o perfil (sem internet, por exemplo)

import { auth, db } from './firebase.js';
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  EmailAuthProvider,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  deleteUser,
} from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js';
import {
  doc,
  getDoc,
  writeBatch,
  updateDoc,
  serverTimestamp,
} from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';
import {
  IDADE_MINIMA,
  IDADE_RESPONSAVEL,
  VERSAO_DOCUMENTOS,
  NICK_REGEX,
  NICKS_RESERVADOS,
} from './config.js';
import { ErroSite } from './erros.js';
import { validarNascimento } from './idade.js';

let estado = { pronto: false, usuario: null, perfil: null, erroPerfil: false };
const ouvintes = new Set();
let iniciado = false;
let sequencia = 0;
let resolverPronto;
const prontoPromise = new Promise((resolver) => {
  resolverPronto = resolver;
});

async function carregarPerfil(uid) {
  const snap = await getDoc(doc(db, 'usuarios', uid));
  return snap.exists() ? { uid, ...snap.data() } : null;
}

// Relê o usuário e o perfil e avisa quem estiver ouvindo.
// A "sequencia" evita que uma leitura antiga, que terminou atrasada, apague uma mais nova.
async function sincronizar() {
  const minha = ++sequencia;
  const usuario = auth.currentUser;
  let perfil = null;
  let erroPerfil = false;

  if (usuario) {
    try {
      perfil = await carregarPerfil(usuario.uid);
    } catch (erro) {
      console.error('Não consegui ler o perfil', erro);
      erroPerfil = true;
    }
  }

  if (minha === sequencia) {
    estado = { pronto: true, usuario, perfil, erroPerfil };
    for (const aviso of ouvintes) {
      try {
        aviso(estado);
      } catch (erro) {
        console.error(erro);
      }
    }
  }
  return estado;
}

export function iniciarAuth() {
  if (!iniciado) {
    iniciado = true;
    onAuthStateChanged(auth, async () => {
      await sincronizar();
      resolverPronto();
    });
  }
  return prontoPromise;
}

export async function esperarAuth() {
  await iniciarAuth();
  return estado;
}

export function estadoAuth() {
  return estado;
}

// Chama "aviso" a cada mudança de estado. Devolve uma função para parar de ouvir.
export function ouvirAuth(aviso) {
  ouvintes.add(aviso);
  if (estado.pronto) aviso(estado);
  return () => ouvintes.delete(aviso);
}

export function temSenha(usuario) {
  return Boolean(usuario) && usuario.providerData.some((p) => p.providerId === 'password');
}

// ---------- Entrar, sair, recuperar ----------

export async function cadastrarComEmail(email, senha) {
  const credencial = await createUserWithEmailAndPassword(auth, email, senha);
  try {
    await sendEmailVerification(credencial.user);
  } catch (erro) {
    // A conta existe; a pessoa pode pedir o e-mail de novo em "Sua conta".
    console.error('Não consegui enviar o e-mail de confirmação', erro);
  }
  return sincronizar();
}

export async function entrarComEmail(email, senha) {
  await signInWithEmailAndPassword(auth, email, senha);
  return sincronizar();
}

export async function entrarComGoogle() {
  const provedor = new GoogleAuthProvider();
  provedor.setCustomParameters({ prompt: 'select_account' });
  await signInWithPopup(auth, provedor);
  return sincronizar();
}

export async function sair() {
  await signOut(auth);
  return sincronizar();
}

export function recuperarSenha(email) {
  return sendPasswordResetEmail(auth, email);
}

export async function reenviarVerificacao() {
  if (!auth.currentUser) throw new ErroSite('Entre na sua conta primeiro.');
  await sendEmailVerification(auth.currentUser);
}

// Relê a conta no servidor, para saber se o e-mail já foi confirmado.
export async function recarregarUsuario() {
  if (auth.currentUser) await auth.currentUser.reload();
  return sincronizar();
}

// ---------- Perfil ----------

export async function nickEmUso(nick) {
  const snap = await getDoc(doc(db, 'nicks', nick));
  return snap.exists();
}

export function validarNick(nick) {
  if (!NICK_REGEX.test(nick)) {
    return 'Use de 3 a 20 caracteres: letras minúsculas, números e _ (sublinhado). Sem espaços nem acentos.';
  }
  if (NICKS_RESERVADOS.includes(nick)) return 'Esse @nick é reservado. Escolha outro.';
  return null;
}

// Cria o perfil, o @nick, os dados de cadastro e o registro de aceite de uma vez só.
// Se qualquer parte for recusada pelas regras, nada é gravado.
export async function criarPerfil({ nome, nick, nascimento, consentimentoResponsavel }) {
  const usuario = auth.currentUser;
  if (!usuario) throw new ErroSite('Entre na sua conta primeiro.');

  const nomeLimpo = String(nome).trim().replace(/\s+/g, ' ');
  if (nomeLimpo.length < 1 || nomeLimpo.length > 50) throw new ErroSite('Digite seu nome, com até 50 letras.');

  const erroNick = validarNick(nick);
  if (erroNick) throw new ErroSite(erroNick);

  const idade = validarNascimento(nascimento);
  if (!idade.ok) throw new ErroSite(idade.erro);
  if (idade.idade < IDADE_MINIMA) {
    throw new ErroSite(`Para criar uma conta neste site é preciso ter pelo menos ${IDADE_MINIMA} anos.`);
  }
  const menor = idade.idade < IDADE_RESPONSAVEL;
  if (menor && !consentimentoResponsavel) {
    throw new ErroSite('Para menores de 18 anos, o responsável precisa concordar com a criação da conta.');
  }

  const uid = usuario.uid;
  const lote = writeBatch(db);
  lote.set(doc(db, 'nicks', nick), { uid });
  lote.set(doc(db, 'usuarios', uid), {
    nome: nomeLimpo,
    nick,
    bio: '',
    criadoEm: serverTimestamp(),
  });
  lote.set(doc(db, 'usuariosPrivado', uid), {
    nascimento,
    versaoAceita: VERSAO_DOCUMENTOS,
    criadoEm: serverTimestamp(),
  });
  lote.set(doc(db, 'aceites', `${uid}_${VERSAO_DOCUMENTOS}`), {
    uid,
    versao: VERSAO_DOCUMENTOS,
    aceitoEm: serverTimestamp(),
    consentimentoResponsavel: menor && Boolean(consentimentoResponsavel),
  });
  await lote.commit();

  return sincronizar();
}

export async function salvarPerfil({ nome, bio }) {
  const usuario = auth.currentUser;
  if (!usuario) throw new ErroSite('Entre na sua conta primeiro.');

  const nomeLimpo = String(nome).trim().replace(/\s+/g, ' ');
  const bioLimpa = String(bio).trim();
  if (nomeLimpo.length < 1 || nomeLimpo.length > 50) throw new ErroSite('Digite seu nome, com até 50 letras.');
  if (bioLimpa.length > 160) throw new ErroSite('A bio pode ter no máximo 160 caracteres.');

  await updateDoc(doc(db, 'usuarios', usuario.uid), { nome: nomeLimpo, bio: bioLimpa });
  return sincronizar();
}

// Apaga perfil, @nick e dados de cadastro, e depois a conta de login.
// Fica guardado só o registro de aceite dos termos (aceites), sem nome nem e-mail.
export async function excluirConta({ senha } = {}) {
  const usuario = auth.currentUser;
  const perfil = estado.perfil;
  if (!usuario) throw new ErroSite('Entre na sua conta primeiro.');

  // Primeiro confirma quem é, para não apagar os dados e falhar no meio.
  if (temSenha(usuario)) {
    if (!senha) throw new ErroSite('Digite sua senha para confirmar.');
    await reauthenticateWithCredential(usuario, EmailAuthProvider.credential(usuario.email, senha));
  } else {
    await reauthenticateWithPopup(usuario, new GoogleAuthProvider());
  }

  if (perfil) {
    const lote = writeBatch(db);
    lote.delete(doc(db, 'usuarios', usuario.uid));
    lote.delete(doc(db, 'usuariosPrivado', usuario.uid));
    lote.delete(doc(db, 'nicks', perfil.nick));
    await lote.commit();
  }

  await deleteUser(usuario);
  return sincronizar();
}
