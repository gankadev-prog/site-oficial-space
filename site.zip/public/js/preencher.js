import { h } from './dom.js';

const MARCA = /(\[PREENCHER:[^\]]*\])/g;

export function destacarPreencher(texto) {
  return String(texto).split(MARCA).map((parte, i) => i % 2 === 1 ? h('mark', { class: 'preencher' }, parte) : parte);
}
