// Configurações do site.
//
// A chave abaixo é pública por natureza: ela só identifica o projeto Firebase no navegador.
// Quem protege os dados são as regras do Firestore (arquivo firestore.rules) e os domínios
// autorizados no Authentication, não o sigilo desta chave.

export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyC69u5Om65tQhFoHmMYhYwumXlqb2p5TNE',
  authDomain: 'space-store-creator-space-web.firebaseapp.com',
  projectId: 'space-store-creator-space-web',
  storageBucket: 'space-store-creator-space-web.firebasestorage.app',
  messagingSenderId: '304372998184',
  appId: '1:304372998184:web:c0845776e97d1b6cf0951d',
};

// Idade mínima para criar conta no site.
// O ECA Digital (Lei 15.211/2025, em vigor desde 17/03/2026) exige que contas de menores de
// 16 anos sejam vinculadas a uma conta do responsável. O site ainda não tem esse vínculo,
// então a conta começa aos 16. Confirme com um advogado antes de mudar este número.
export const IDADE_MINIMA = 16;

// Entre a idade mínima e esta idade, a pessoa confirma que o responsável concorda.
export const IDADE_RESPONSAVEL = 18;

// Versão dos Termos de Uso e da Política de Privacidade que o cadastro registra.
// "provisoria-0" vale enquanto os textos reais não estão publicados (etapa 5).
export const VERSAO_DOCUMENTOS = 'provisoria-0';

export const SENHA_MINIMA = 8;

export const NICK_REGEX = /^[a-z0-9_]{3,20}$/;

// @nicks que ninguém pode usar, para ninguém se passar pela equipe ou pelos apps.
export const NICKS_RESERVADOS = [
  'admin',
  'administrador',
  'moderador',
  'moderacao',
  'suporte',
  'oficial',
  'equipe',
  'space',
  'spacestore',
  'creatorspace',
];
