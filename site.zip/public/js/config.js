// Configurações do site.
//
// A chave abaixo é pública por natureza: ela só identifica o projeto Firebase no navegador.
// Quem protege os dados são as regras do Firestore (arquivo firestore.rules) e os domínios
// autorizados no Authentication, não o sigilo desta chave.

export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyC69u5Om65tQhFoHmMYhYwumXlqb2p5TNE',
  authDomain: 'space-store-creator-space-web.firebaseapp.com',
  projectId: 'space-store-creator-space-web',
  messagingSenderId: '304372998184',
  appId: '1:304372998184:web:c0845776e97d1b6cf0951d',
};

// Configure o cloud name e um preset unsigned no Cloudinary antes de habilitar uploads.
// Não coloque segredos do Cloudinary no código publicado.
export const CLOUDINARY_CLOUD_NAME = '[PREENCHER: cloud name do Cloudinary]';
export const CLOUDINARY_UPLOAD_PRESET = '[PREENCHER: preset unsigned do Cloudinary]';
export const CLOUDINARY_PASTA = 'space-community';
export const LIMITE_TEXTO_POST = 5000;
export const LIMITE_TITULO_POST = 120;
export const LIMITE_COMENTARIO = 1000;
export const LIMITE_IMAGEM_PERFIL = 150000;
// Limites de conveniência no navegador; configure o preset/conta Cloudinary em conjunto.
export const LIMITE_FOTO_ORIGINAL_BYTES = 20 * 1024 * 1024;
export const LIMITE_VIDEO_COMUNIDADE_BYTES = 50 * 1024 * 1024;

// Idade mínima para criar conta no site.
// O ECA Digital (Lei 15.211/2025, em vigor desde 17/03/2026) exige que contas de menores de
// 16 anos sejam vinculadas a uma conta do responsável. O site ainda não tem esse vínculo,
// então a conta começa aos 16. Confirme com um advogado antes de mudar este número.
export const IDADE_MINIMA = 16;

// Entre a idade mínima e esta idade, a pessoa confirma que o responsável concorda.
export const IDADE_RESPONSAVEL = 18;

// Versão dos Termos de Uso e da Política de Privacidade que o cadastro registra.
// Aumente (use a data, AAAA-MM-DD) sempre que o sentido dos textos em docs-conteudo.js mudar.
export const VERSAO_DOCUMENTOS = '2026-11-07';

export const SENHA_MINIMA = 8;

export const NICK_REGEX = /^[a-z0-9_]{3,20}$/;

// @nicks que ninguém pode usar, para ninguém se passar pela equipe ou pelos apps.
export const NICKS_RESERVADOS = [
  'admin',
  'administrador',
  'moderador',
  'moderacao',
  'suporte',
  'oficial',
  'equipe',
  'space',
  'spacestore',
  'creatorspace',
];
