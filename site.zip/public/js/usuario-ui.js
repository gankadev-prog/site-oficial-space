import { h } from './dom.js';
import { imagemBase64 } from './formatar.js';
import { obterPerfilPublico } from './dados-comunidade.js';

export function linkAutor(nick, nome, { grande = false } = {}) {
  const href = '/u/' + encodeURIComponent(nick || '');
  const inicial = String(nome || nick || '?').slice(0, 1);
  const classes = `avatar-fallback${grande ? ' perfil-avatar-grande' : ''}`;
  const rosto = h('span', { class: classes, 'aria-hidden': 'true' }, inicial);
  const link = h('a', { href, 'aria-label': `Ver perfil de ${nome || 'pessoa usuária'}, @${nick || '—'}` }, rosto);
  if (nick) {
    obterPerfilPublico(nick).then((perfil) => {
      if (!perfil) return;
      const src = imagemBase64(perfil.avatarMime, perfil.avatarBase64, 150000);
      if (!src || !link.isConnected) return;
      const molduras = ['linha', 'folha', 'arco'];
      const classeMoldura = molduras.includes(perfil.moldura) ? ` moldura-${perfil.moldura}` : '';
      const imagem = h('img', { class: `avatar${grande ? ' perfil-avatar-grande' : ''}${classeMoldura}`, src, alt: '' });
      rosto.replaceWith(imagem);
    }).catch(() => {});
  }
  return link;
}
