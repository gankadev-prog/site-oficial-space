// Inicia o Firebase uma única vez. Quem precisa do banco importa "db" daqui;
// o login (auth.js) cria a própria instância a partir de "app".
// Analytics não é usado de propósito: exigiria aviso e consentimento de cookies.

import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';
import { FIREBASE_CONFIG } from './config.js';

export const app = initializeApp(FIREBASE_CONFIG);
export const db = getFirestore(app);
