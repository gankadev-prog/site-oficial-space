// Inicia o Firebase uma única vez. Quem precisa de login ou banco importa "auth" e "db" daqui.
// Analytics não é usado de propósito: exigiria aviso e consentimento de cookies.

import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';
import { FIREBASE_CONFIG } from './config.js';

const app = initializeApp(FIREBASE_CONFIG);

export const auth = getAuth(app);
auth.languageCode = 'pt-BR';

export const db = getFirestore(app);
