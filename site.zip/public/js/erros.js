// Traduz os erros do Firebase para português claro. Nada de "auth/invalid-credential" na tela.

// Erro do próprio site, com a mensagem já escrita para a pessoa ler.
export class ErroSite extends Error {
  constructor(mensagem) {
    super(mensagem);
    this.name = 'ErroSite';
  }
}

const CREDENCIAIS = 'E-mail ou senha incorretos. Confira e tente de novo.';
const JANELA_FECHADA = 'A janela do Google foi fechada antes de terminar. Tente de novo.';

const MENSAGENS = {
  'auth/invalid-credential': CREDENCIAIS,
  'auth/wrong-password': CREDENCIAIS,
  'auth/user-not-found': CREDENCIAIS,
  'auth/invalid-email': 'Esse e-mail não parece certo. Confira se tem @ e o final, como .com.',
  'auth/email-already-in-use': 'Esse e-mail já tem uma conta. Tente entrar ou recuperar a senha.',
  'auth/weak-password': 'A senha está fraca. Use pelo menos 8 caracteres.',
  'auth/too-many-requests': 'Muitas tentativas seguidas. Espere alguns minutos e tente de novo.',
  'auth/network-request-failed': 'A conexão com a internet falhou. Confira e tente de novo.',
  'auth/popup-closed-by-user': JANELA_FECHADA,
  'auth/cancelled-popup-request': JANELA_FECHADA,
  'auth/popup-blocked': 'O navegador bloqueou a janela do Google. Permita pop-ups para este site e tente de novo.',
  'auth/account-exists-with-different-credential':
    'Já existe uma conta com esse e-mail que entra de outro jeito. Entre com e-mail e senha.',
  'auth/user-disabled': 'Esta conta foi desativada. Se acha que foi engano, escreva para spacestorew@gmail.com.',
  'auth/requires-recent-login': 'Por segurança, entre de novo e repita o pedido.',
  'auth/operation-not-allowed': 'Esse jeito de entrar ainda não está ligado no site. Avise em spacestorew@gmail.com.',
  'auth/unauthorized-domain': 'Este endereço não está autorizado a fazer login. Avise em spacestorew@gmail.com.',
  'permission-denied':
    'O servidor recusou salvar isso. Se você estava criando a conta, o @nick pode ter sido pego agora há pouco. Tente outro.',
  unavailable: 'Não consegui falar com o servidor agora. Tente de novo em instantes.',
};

export function mensagemDeErro(erro) {
  if (erro instanceof ErroSite) return erro.message;
  const codigo = erro && erro.code ? String(erro.code) : '';
  return (
    MENSAGENS[codigo] ||
    'Algo deu errado do meu lado. Tente de novo em instantes. Se continuar, escreva para spacestorew@gmail.com.'
  );
}
