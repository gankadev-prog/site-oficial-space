// Alternância entre tema claro (padrão) e escuro.
// A escolha fica salva no navegador (localStorage). Isso precisa constar na política de cookies.

const CHAVE = 'space-tema';
const CORES = { claro: '#F5F3EE', escuro: '#121315' };

export function temaAtual() {
  return document.documentElement.getAttribute('data-tema') === 'escuro' ? 'escuro' : 'claro';
}

function aplicar(tema) {
  document.documentElement.setAttribute('data-tema', tema);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', CORES[tema]);
}

function guardar(tema) {
  try {
    localStorage.setItem(CHAVE, tema);
  } catch (erro) {
    // Sem armazenamento, o tema vale só até recarregar.
  }
}

export function iniciarTema(botao) {
  function atualizarBotao() {
    const escuro = temaAtual() === 'escuro';
    botao.setAttribute('aria-label', escuro ? 'Mudar para o tema claro' : 'Mudar para o tema escuro');
  }

  aplicar(temaAtual());
  atualizarBotao();

  botao.addEventListener('click', () => {
    const novo = temaAtual() === 'escuro' ? 'claro' : 'escuro';
    aplicar(novo);
    guardar(novo);
    atualizarBotao();
  });
}
