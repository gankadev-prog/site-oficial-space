// Menu de navegação do celular.

export function iniciarMenu(botao, nav) {
  function aberto() {
    return botao.getAttribute('aria-expanded') === 'true';
  }

  function definir(abrir) {
    botao.setAttribute('aria-expanded', String(abrir));
    botao.setAttribute('aria-label', abrir ? 'Fechar menu' : 'Abrir menu');
    nav.classList.toggle('aberto', abrir);
  }

  botao.addEventListener('click', () => definir(!aberto()));

  document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape' && aberto()) {
      definir(false);
      botao.focus();
    }
  });

  document.addEventListener('click', (evento) => {
    if (aberto() && !nav.contains(evento.target) && !botao.contains(evento.target)) {
      definir(false);
    }
  });

  return { fechar: () => definir(false) };
}
