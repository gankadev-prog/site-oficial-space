import { CLOUDINARY_CLOUD_NAME, CLOUDINARY_UPLOAD_PRESET, CLOUDINARY_PASTA } from './config.js';

function configValida() {
  return /^[A-Za-z0-9_-]{1,80}$/.test(CLOUDINARY_CLOUD_NAME) && /^[A-Za-z0-9_-]{1,80}$/.test(CLOUDINARY_UPLOAD_PRESET);
}

function blobImagemReduzida(arquivo) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(arquivo);
    const imagem = new Image();
    imagem.onload = () => {
      URL.revokeObjectURL(url);
      const escala = Math.min(1, 1280 / imagem.width, 1280 / imagem.height);
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(imagem.width * escala));
      canvas.height = Math.max(1, Math.round(imagem.height * escala));
      const contexto = canvas.getContext('2d');
      if (!contexto) return reject(new Error('Não consegui preparar esta foto no aparelho.'));
      contexto.drawImage(imagem, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('Não consegui reduzir esta foto.')), 'image/jpeg', 0.8);
    };
    imagem.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Este arquivo de imagem não abriu.')); };
    imagem.src = url;
  });
}

function conferirDuracao(arquivo) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(arquivo);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      const duracao = video.duration;
      URL.revokeObjectURL(url);
      if (!Number.isFinite(duracao) || duracao <= 0 || duracao > 54) reject(new Error('O vídeo precisa ter até 54 segundos.'));
      else resolve(duracao);
    };
    video.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Não consegui ler a duração deste vídeo.')); };
    video.src = url;
  });
}

export async function enviarMidia(arquivo, progresso = () => {}) {
  if (!configValida()) throw new Error('O upload de mídia ainda não foi configurado. O texto do formulário continua salvo; tente de novo depois da configuração.');
  const imagem = arquivo.type.startsWith('image/');
  const video = arquivo.type.startsWith('video/');
  if (!imagem && !video) throw new Error('Escolha uma foto ou um vídeo.');
  if (video) await conferirDuracao(arquivo);
  const payload = imagem ? await blobImagemReduzida(arquivo) : arquivo;
  const form = new FormData();
  form.append('file', payload, imagem ? 'foto.jpg' : arquivo.name);
  form.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  form.append('folder', CLOUDINARY_PASTA);
  const endereco = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/${imagem ? 'image' : 'video'}/upload`;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', endereco);
    xhr.upload.onprogress = (evento) => {
      if (evento.lengthComputable) progresso(Math.round((evento.loaded / evento.total) * 100));
    };
    xhr.onerror = () => reject(new Error('A conexão com o serviço de mídia falhou. Seu texto continua no formulário.'));
    xhr.onload = () => {
      let resposta;
      try { resposta = JSON.parse(xhr.responseText); } catch { resposta = null; }
      if (xhr.status < 200 || xhr.status >= 300 || !resposta?.secure_url) {
        reject(new Error('O envio da mídia não foi concluído. Seu texto continua no formulário.'));
        return;
      }
      if (!/^https:\/\/res\.cloudinary\.com\/[A-Za-z0-9_-]+\//.test(resposta.secure_url)) {
        reject(new Error('O serviço devolveu um endereço de mídia inesperado.'));
        return;
      }
      resolve({ tipo: imagem ? 'imagem' : 'video', url: resposta.secure_url });
    };
    xhr.send(form);
  });
}
