// Helpers seguros de DOM: dados entram como texto, nunca como marcação HTML.
const NS_SVG = 'http://www.w3.org/2000/svg';

export function urlSegura(valor) {
  if (typeof valor !== 'string' || valor !== valor.trim() || /[\u0000-\u001f\u007f]/.test(valor)) return false;
  if (valor.startsWith('//') || valor.startsWith('/\\')) return false;
  try {
    const url = new URL(valor, window.location.origin);
    if (url.protocol === 'https:' || url.protocol === 'mailto:') return true;
    return url.origin === window.location.origin && !/^[a-z][a-z0-9+.-]*:/i.test(valor);
  } catch {
    return false;
  }
}

function srcSegura(valor) {
  if (typeof valor !== 'string' || valor !== valor.trim()) return false;
  if (/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(valor) && valor.length <= 260000) return true;
  if (valor.startsWith('blob:')) return true;
  return urlSegura(valor);
}

function aplicarAtributos(el, atributos) {
  for (const [chave, valor] of Object.entries(atributos || {})) {
    if (valor === null || valor === undefined) continue;
    if (chave.toLowerCase().startsWith('on')) {
      if (typeof valor === 'function') el.addEventListener(chave.slice(2).toLowerCase(), valor);
      continue;
    }
    if (chave === 'href' && !urlSegura(String(valor))) continue;
    if (chave === 'src' && !srcSegura(String(valor))) continue;
    if (valor === false) continue;
    el.setAttribute(chave, valor === true ? '' : String(valor));
  }
}

function anexar(el, filhos) {
  for (const filho of filhos.flat(Infinity)) {
    if (filho === null || filho === undefined || filho === false) continue;
    el.append(filho instanceof Node ? filho : document.createTextNode(String(filho)));
  }
}

export function h(tag, atributos, ...filhos) {
  const el = document.createElement(tag);
  aplicarAtributos(el, atributos);
  anexar(el, filhos);
  return el;
}

export function s(tag, atributos, ...filhos) {
  const el = document.createElementNS(NS_SVG, tag);
  aplicarAtributos(el, atributos);
  anexar(el, filhos);
  return el;
}

export function linkExterno(href, conteudo, atributos = {}) {
  return h('a', { ...atributos, href, target: '_blank', rel: 'noopener noreferrer' }, conteudo);
}
