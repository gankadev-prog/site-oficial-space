// Utilitários para montar a interface sem innerHTML.
// Todo texto entra como nó de texto, então conteúdo de usuário nunca vira HTML.

const NS_SVG = 'http://www.w3.org/2000/svg';

// Só aceita endereços relativos, http, https e mailto. Bloqueia javascript: e similares.
export function urlSegura(valor) {
  try {
    const url = new URL(String(valor), window.location.origin);
    return ['http:', 'https:', 'mailto:'].includes(url.protocol);
  } catch (erro) {
    return false;
  }
}

function aplicarAtributos(el, atributos) {
  for (const [chave, valor] of Object.entries(atributos || {})) {
    if (valor === null || valor === undefined) continue;

    if (chave.startsWith('on')) {
      // Só funções viram evento; "onclick" em texto é ignorado de propósito.
      if (typeof valor === 'function') {
        el.addEventListener(chave.slice(2).toLowerCase(), valor);
      }
      continue;
    }

    if (chave.startsWith('aria-')) {
      el.setAttribute(chave, String(valor));
      continue;
    }

    if (valor === false) continue;

    if ((chave === 'href' || chave === 'src') && !urlSegura(valor)) continue;

    el.setAttribute(chave, valor === true ? '' : String(valor));
  }
}

function anexar(el, filhos) {
  for (const filho of filhos.flat(Infinity)) {
    if (filho === null || filho === undefined || filho === false) continue;
    el.append(filho instanceof Node ? filho : document.createTextNode(String(filho)));
  }
}

// h('a', { href: '/x' }, 'texto') cria um elemento HTML.
export function h(tag, atributos, ...filhos) {
  const el = document.createElement(tag);
  aplicarAtributos(el, atributos);
  anexar(el, filhos);
  return el;
}

// s('path', { d: '...' }) cria um elemento SVG.
export function s(tag, atributos, ...filhos) {
  const el = document.createElementNS(NS_SVG, tag);
  aplicarAtributos(el, atributos);
  anexar(el, filhos);
  return el;
}

// Link para fora do site, sempre com rel seguro.
export function linkExterno(href, conteudo, atributos = {}) {
  return h('a', { ...atributos, href, target: '_blank', rel: 'noopener noreferrer' }, conteudo);
}
