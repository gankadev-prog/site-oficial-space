import { h } from './dom.js';
import { denunciar, MOTIVOS } from './dados-comunidade.js';
import { mensagemDeErro } from './erros.js';

export function formularioDenuncia(alvoTipo, alvoId, rotulo = 'Denunciar') {
  const id = `denuncia-${alvoTipo}-${Math.random().toString(36).slice(2, 8)}`;
  const motivo = h('select', { id: `${id}-motivo`, required: true }, MOTIVOS.map((m) => h('option', { value: m }, m)));
  const detalhe = h('textarea', { id: `${id}-detalhe`, maxlength: '500', rows: '3', 'aria-describedby': `${id}-ajuda` });
  const status = h('p', { role: 'status', 'aria-live': 'polite' });
  const botao = h('button', { type: 'submit', class: 'botao botao-secundario' }, 'Enviar denúncia');
  const form = h('form', { class: 'form' },
    h('div', { class: 'campo' }, h('label', { for: `${id}-motivo` }, 'Motivo'), motivo),
    h('div', { class: 'campo' }, h('label', { for: `${id}-detalhe` }, 'Detalhe opcional'), h('p', { id: `${id}-ajuda`, class: 'campo-ajuda' }, 'Até 500 caracteres. Seu nome não aparece para a pessoa denunciada.'), detalhe),
    status, botao);
  form.addEventListener('submit', async (evento) => {
    evento.preventDefault(); botao.disabled = true;
    try { await denunciar({ alvoTipo, alvoId, motivo: motivo.value, detalhe: detalhe.value }); status.textContent = 'Recebi sua denúncia. Seu nome não será mostrado à pessoa denunciada.'; form.reset(); }
    catch (erro) { status.textContent = mensagemDeErro(erro); }
    finally { botao.disabled = false; }
  });
  return h('details', { class: 'form-denuncia' }, h('summary', {}, rotulo), form);
}
