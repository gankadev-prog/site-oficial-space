// Roda antes de a página aparecer, para o tema salvo não piscar.
// Tema claro é o padrão; só muda se a pessoa já escolheu o escuro.
(function () {
  var tema = 'claro';
  try {
    var salvo = localStorage.getItem('space-tema');
    if (salvo === 'escuro' || salvo === 'claro') {
      tema = salvo;
    }
  } catch (erro) {
    // Armazenamento bloqueado: segue com o tema claro.
  }
  document.documentElement.setAttribute('data-tema', tema);
})();
