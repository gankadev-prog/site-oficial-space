// Texto dos documentos do site: Termos de Uso, Privacidade, Cookies, Diretrizes da Comunidade
// e Segurança. Cada documento é uma lista de seções; cada seção, uma lista de blocos:
//   "texto"                          parágrafo
//   { lista: ['a', 'b'] }            lista
//   { tabela: { cab: [...], linhas: [[...], ...] } }
// Trechos "[PREENCHER: ...]" aparecem destacados na página.
//
// IMPORTANTE: toda vez que o sentido de um texto mudar, aumente VERSAO_DOCUMENTOS (em config.js).
// Quem se cadastra passa a registrar o aceite dessa versão.

export { VERSAO_DOCUMENTOS } from './config.js';

// Troque para true só depois que um advogado revisar os textos e você preencher todos os
// "[PREENCHER: ...]". Enquanto for false, a página mostra um aviso de minuta.
export const REVISADO_POR_ADVOGADO = false;

export const EMAIL_CONTATO = 'spacestorew@gmail.com';

export const DOCUMENTOS = [
  // ------------------------------------------------------------------ TERMOS
  {
    id: 'termos',
    titulo: 'Termos de Uso',
    resumo: 'As regras para usar este site e a conta dele.',
    secoes: [
      {
        titulo: 'Quem faz este site',
        blocos: [
          'Este site reúne os downloads, as novidades, a comunidade e as regras da Space Store (loja de apps e jogos para Android) e do Creator Space (painel para desenvolvedores publicarem na Space Store). Eu o mantenho como desenvolvedor independente.',
          'Responsável: Guilherme Lucena Gonçalves, [PREENCHER: CPF ou CNPJ], [PREENCHER: cidade e estado]. Contato: spacestorew@gmail.com.',
        ],
      },
      {
        titulo: 'Aceite e mudanças',
        blocos: [
          'Ao criar uma conta, você declara que leu e aceita estes Termos e a Política de Privacidade. Para só navegar e baixar os apps, não é preciso criar conta.',
          'Eu posso atualizar estes textos. Cada versão tem uma data. Quando a mudança for importante, aviso no site e peço um novo aceite. Se você não concordar com a versão nova, pode excluir a sua conta.',
        ],
      },
      {
        titulo: 'Quem pode criar conta',
        blocos: [
          'É preciso ter pelo menos 16 anos. Quem tem entre 16 e 17 anos precisa ter a concordância do pai, da mãe ou do responsável legal, que você confirma no cadastro.',
          'Pedimos a data de nascimento para conferir a idade. Se eu descobrir que uma conta foi criada com dados de idade falsos, posso suspendê-la ou encerrá-la.',
          'A regra de 16 anos existe porque a lei brasileira que protege crianças e adolescentes no ambiente digital (Lei nº 15.211/2025, o ECA Digital) exige que contas de menores de 16 anos sejam vinculadas à conta de um responsável, e este site ainda não tem esse recurso.',
        ],
      },
      {
        titulo: 'Sua conta',
        blocos: [
          'Informe dados verdadeiros e mantenha o seu e-mail acessível. A conta é pessoal: não a empreste nem a venda.',
          'Guarde a sua senha. Você é responsável pelo que for feito na sua conta enquanto ela estiver aberta por você ou com o seu consentimento. Se desconfiar de acesso indevido, troque a senha e me escreva.',
          'Você pode excluir a conta a qualquer momento, em "Minha conta". A exclusão apaga o seu perfil, o seu @nick e os seus dados de cadastro, como explica a Política de Privacidade.',
        ],
      },
      {
        titulo: '@nick e perfil',
        blocos: [
          'O @nick é único e público. Não é permitido usar @nick ou nome que imite a equipe, os apps, outra pessoa ou outra marca, nem que seja ofensivo. Alguns @nicks são reservados. Posso pedir a troca ou removê-lo se desrespeitar essas regras.',
        ],
      },
      {
        titulo: 'O que pode e o que não pode',
        blocos: [
          'Você se compromete a usar o site de acordo com a lei e com as Diretrizes da Comunidade, que fazem parte destes Termos. Também não é permitido:',
          {
            lista: [
              'tentar invadir, sobrecarregar ou burlar a segurança do site;',
              'coletar dados de outras pessoas por meios automáticos;',
              'usar o site para enviar spam, golpes ou arquivos maliciosos;',
              'se passar por outra pessoa ou por mim.',
            ],
          },
        ],
      },
      {
        titulo: 'O que você publica',
        blocos: [
          'Quando a comunidade estiver aberta, o que você publicar (textos, avaliações, comentários, imagens) continua sendo seu. Você me dá uma licença gratuita, não exclusiva, para exibir esse conteúdo no site e nos apps do ecossistema enquanto ele estiver publicado, e para copiá-lo ou reduzi-lo tecnicamente quando isso for necessário para exibir (por exemplo, reduzir uma imagem).',
          'Você é responsável pelo que publica e declara que tem o direito de publicar. Posso remover conteúdo que descumpra a lei, estes Termos ou as Diretrizes, e explico o motivo sempre que for possível.',
          'Se você achar que um conteúdo viola direitos seus, escreva para spacestorew@gmail.com, com o endereço do conteúdo e o motivo.',
        ],
      },
      {
        titulo: 'Downloads e apps',
        blocos: [
          'Os apps listados aqui são baixados de links oficiais, hospedados no GitHub. Cada versão mostra o tamanho e o código SHA-256 do arquivo, para você conferir se baixou o arquivo certo.',
          'Antes de um app de terceiros entrar na Space Store, eu faço uma verificação: análise de segurança com o VirusTotal e revisão do conteúdo. Essa verificação reduz o risco, mas não garante que o app esteja livre de erros ou de problemas. Instalar um app é uma decisão sua.',
          'Os apps publicados por outros desenvolvedores são de responsabilidade deles, e cada um tem a sua política de privacidade e as suas regras. Os apps podem ter regras próprias, além destas.',
          'Como o Android pode mostrar avisos ao instalar um app de fora da Google Play, a página de downloads explica o passo a passo.',
        ],
      },
      {
        titulo: 'Propriedade intelectual',
        blocos: [
          'O nome Space Store, o nome Creator Space, as marcas, os textos e o código do site pertencem a mim, salvo quando houver aviso de outra autoria. Você pode compartilhar links do site. Não pode copiar o site ou as marcas para dar a entender que são seus ou oficiais.',
        ],
      },
      {
        titulo: 'Disponibilidade',
        blocos: [
          'Este é um projeto independente e gratuito. Faço o possível para mantê-lo no ar, mas pode haver instabilidade, manutenção ou mudança de recursos sem aviso. Posso mudar ou encerrar partes do site. Se encerrar contas ou o site, aviso com antecedência razoável.',
        ],
      },
      {
        titulo: 'Responsabilidade',
        blocos: [
          'Na medida permitida pela lei, não respondo por danos causados por conteúdo de terceiros, por apps de outros desenvolvedores ou por indisponibilidade do site. Nada nestes Termos retira direitos que a lei garante a você, como os do Código de Defesa do Consumidor, quando se aplicarem.',
        ],
      },
      {
        titulo: 'Suspensão e encerramento',
        blocos: [
          'Posso suspender ou encerrar uma conta que descumpra estes Termos ou as Diretrizes, ou que seja usada para algo ilegal. Sempre que possível, aviso o motivo por e-mail e você pode responder para contestar. Em casos graves, como material de abuso sexual infantil, a conta é encerrada na hora e o caso pode ser comunicado às autoridades.',
        ],
      },
      {
        titulo: 'Lei aplicável e foro',
        blocos: [
          'Estes Termos seguem a lei brasileira. Para resolver qualquer conflito, fica eleito o foro de [PREENCHER: comarca], ressalvado o direito do consumidor de propor ação no foro do seu domicílio, quando a lei assim prever.',
          'Contato para qualquer dúvida sobre estes Termos: spacestorew@gmail.com.',
        ],
      },
    ],
  },

  // ------------------------------------------------------------- PRIVACIDADE
  {
    id: 'privacidade',
    titulo: 'Política de Privacidade',
    resumo: 'Quais dados eu guardo, por quê, com quem passam e como você controla.',
    secoes: [
      {
        titulo: 'Em poucas palavras',
        blocos: [
          {
            lista: [
              'Para navegar e baixar apps, você não precisa informar nada.',
              'Para ter conta, eu guardo o seu e-mail, nome, @nick e data de nascimento.',
              'Não uso anúncios, não vendo dados e não uso ferramentas de análise de audiência.',
              'Você pode ver, corrigir e apagar os seus dados em "Minha conta" ou pedindo por e-mail.',
            ],
          },
        ],
      },
      {
        titulo: 'Quem é o controlador dos dados',
        blocos: [
          'O controlador, quem decide como os dados são tratados, é Guilherme Lucena Gonçalves, [PREENCHER: CPF ou CNPJ], [PREENCHER: cidade e estado]. Eu mesmo sou o encarregado pelo tratamento de dados (DPO). Contato: spacestorew@gmail.com.',
        ],
      },
      {
        titulo: 'Quais dados eu trato',
        blocos: [
          {
            tabela: {
              cab: ['Dado', 'Para quê', 'Visível a quem'],
              linhas: [
                ['E-mail e senha (a senha é guardada de forma protegida pelo serviço de login, eu não a vejo), ou login com a conta Google', 'Criar e proteger a sua conta, e recuperar o acesso', 'Só você e eu'],
                ['Nome', 'Identificar você no perfil', 'Público, no seu perfil'],
                ['@nick', 'Seu nome único no site', 'Público'],
                ['Bio (opcional)', 'Apresentação no perfil', 'Público'],
                ['Data de nascimento', 'Conferir a idade mínima e a necessidade de concordância do responsável', 'Só você e eu; não aparece no perfil'],
                ['Registro de aceite (seu identificador, a versão dos textos, a data e se houve concordância do responsável)', 'Comprovar que você aceitou os Termos', 'Só você e eu'],
                ['Conteúdo que você publicar na comunidade (quando aberta): textos, avaliações, comentários, imagens e vídeos curtos', 'Exibir o que você publicou', 'Público'],
                ['Dados técnicos de acesso (como endereço IP e tipo de navegador), registrados pelos serviços de hospedagem e de login', 'Funcionamento, segurança e prevenção de abuso', 'Só os prestadores de serviço e eu'],
              ],
            },
          },
          'Não peço CPF, endereço, telefone nem localização aos usuários do site.',
        ],
      },
      {
        titulo: 'Por que posso tratar esses dados',
        blocos: [
          'A Lei Geral de Proteção de Dados (LGPD, Lei nº 13.709/2018) exige uma justificativa para cada uso. As minhas são:',
          {
            lista: [
              'execução do serviço que você pediu (criar e manter a conta, mostrar o perfil e o que você publica);',
              'cumprimento de obrigação legal ou regulatória, como conferir a idade e proteger crianças e adolescentes;',
              'exercício regular de direitos, ao guardar o registro de aceite como prova;',
              'legítimo interesse, para manter o site seguro e prevenir fraudes e abusos.',
            ],
          },
        ],
      },
      {
        titulo: 'Crianças e adolescentes',
        blocos: [
          'Este site é para quem tem 16 anos ou mais. Entre 16 e 17 anos, o cadastro exige a concordância do responsável. Os dados de adolescentes são tratados no melhor interesse deles, como a LGPD e o ECA Digital pedem, e de forma mínima.',
          'Se você é responsável por uma pessoa menor de 16 anos e acha que ela criou uma conta, escreva para spacestorew@gmail.com e eu excluo a conta.',
        ],
      },
      {
        titulo: 'Com quem os dados passam',
        blocos: [
          'Não vendo nem alugo dados. Uso estes prestadores de serviço, que tratam dados em meu nome:',
          {
            tabela: {
              cab: ['Prestador', 'O que faz'],
              linhas: [
                ['Google (Firebase: Hosting, Authentication e Firestore)', 'Hospeda o site, faz o login e guarda os dados da conta e do conteúdo'],
                ['Google Fonts', 'Entrega as fontes das letras; o seu navegador se conecta ao Google ao abrir o site'],
                ['GitHub', 'Hospeda os arquivos dos apps (APK); ao baixar, o GitHub recebe o seu endereço IP'],
                ['Cloudinary (quando a comunidade estiver aberta)', 'Guarda fotos e vídeos curtos que você publicar'],
              ],
            },
          },
          'Também posso informar dados a autoridades quando a lei ou uma ordem judicial exigir, ou para proteger direitos e a segurança de pessoas, em especial de crianças e adolescentes.',
        ],
      },
      {
        titulo: 'Dados fora do Brasil',
        blocos: [
          'Os prestadores acima podem tratar dados em servidores fora do Brasil. Nesse caso, a transferência acontece com base nos mecanismos que a LGPD permite, como as cláusulas contratuais e as garantias oferecidas por esses prestadores. [PREENCHER: confirmar com um advogado a base legal da transferência internacional.]',
        ],
      },
      {
        titulo: 'Por quanto tempo guardo',
        blocos: [
          {
            lista: [
              'Dados da conta: enquanto a conta existir. Ao excluí-la, apago o perfil, o @nick e os dados de cadastro.',
              'Registro de aceite: fica guardado depois da exclusão, sem nome nem e-mail, apenas com o identificador, a versão, a data e a marca de concordância do responsável, para eu poder comprovar o consentimento.',
              'Conteúdo publicado: até você apagar ou a conta ser excluída. [PREENCHER: confirmar o que acontece com os comentários ao excluir a conta, quando a comunidade abrir.]',
              'Registros técnicos: pelo tempo que os prestadores mantêm, e pelo prazo que a lei exigir.',
            ],
          },
        ],
      },
      {
        titulo: 'Os seus direitos',
        blocos: [
          'Pela LGPD, você pode pedir: confirmação de que trato dados seus; acesso a eles; correção; anonimização, bloqueio ou eliminação do que for desnecessário ou excessivo; portabilidade; informação sobre com quem compartilhei; e a revogação do consentimento. Você também pode se opor a um tratamento que considere irregular.',
          'Nome, bio e a exclusão da conta você faz em "Minha conta". Para o resto, escreva para spacestorew@gmail.com. Respondo em até 15 dias. Se não ficar satisfeito, você pode reclamar à Autoridade Nacional de Proteção de Dados (ANPD).',
        ],
      },
      {
        titulo: 'Segurança',
        blocos: [
          'O site usa conexão segura (HTTPS). O login é feito pelo Firebase Authentication, e o acesso aos dados é limitado por regras de segurança no banco, de modo que cada pessoa só altera os próprios dados. Nenhum sistema é perfeito. Se houver um incidente de segurança que possa causar dano relevante, aviso as pessoas afetadas e a ANPD, como a lei determina.',
        ],
      },
      {
        titulo: 'Mudanças nesta política',
        blocos: [
          'Posso atualizar esta política. A versão e a data ficam no alto da página. Mudanças relevantes são avisadas no site.',
        ],
      },
    ],
  },

  // ----------------------------------------------------------------- COOKIES
  {
    id: 'cookies',
    titulo: 'Cookies e armazenamento',
    resumo: 'O que este site guarda no seu navegador.',
    secoes: [
      {
        titulo: 'O que é e o que eu uso',
        blocos: [
          'Cookies e recursos parecidos (como o armazenamento local do navegador) guardam pequenas informações no seu aparelho. Este site não usa cookies de publicidade nem de análise de audiência, e não tem o seu próprio cookie.',
          {
            tabela: {
              cab: ['O que', 'Para quê', 'Quando é usado'],
              linhas: [
                ['Tema (claro ou escuro), no armazenamento local, chave "space-tema"', 'Lembrar a sua escolha de tema', 'Quando você troca o tema'],
                ['Sessão de login, no armazenamento do navegador (criado pelo Firebase Authentication)', 'Manter você conectado', 'Só se você entrar na conta'],
                ['Cookies do Google, na janela de login com a conta Google', 'Fazer o login com o Google', 'Só se você escolher entrar com o Google'],
              ],
            },
          },
          'Os dois primeiros são necessários para o recurso que você pediu. Por isso, o site não mostra faixa de aceite de cookies: não há o que aceitar ou recusar. Se um dia eu usar algo além disso, peço o seu consentimento antes.',
        ],
      },
      {
        titulo: 'Como apagar',
        blocos: [
          'Você pode apagar esses dados nas configurações do navegador. Se apagar a sessão de login, você precisará entrar de novo. Ao sair da conta, a sessão é encerrada.',
          'Serviços de terceiros que o seu navegador acessa para exibir o site, como o Google Fonts e o GitHub (nos downloads), recebem o seu endereço IP. Veja a Política de Privacidade.',
        ],
      },
    ],
  },

  // -------------------------------------------------------------- DIRETRIZES
  {
    id: 'diretrizes',
    titulo: 'Diretrizes da Comunidade',
    resumo: 'Como conversar e publicar com respeito, e o que acontece quando as regras são quebradas.',
    secoes: [
      {
        titulo: 'O espírito da coisa',
        blocos: [
          'A comunidade é para dúvidas, sugestões e para mostrar apps. Trate as pessoas como você gostaria de ser tratado. Discordar é normal; desrespeitar não é.',
        ],
      },
      {
        titulo: 'O que não é permitido',
        blocos: [
          {
            lista: [
              'Qualquer conteúdo sexual envolvendo crianças ou adolescentes. Tolerância zero: o conteúdo é removido, a conta é encerrada e o caso pode ser comunicado às autoridades.',
              'Pornografia e conteúdo sexual explícito.',
              'Ameaças, incitação à violência, assédio, perseguição e humilhação.',
              'Discriminação e ódio por raça, cor, origem, religião, gênero, orientação sexual, deficiência ou qualquer outra característica.',
              'Divulgar dados pessoais de alguém (endereço, telefone, documentos), mesmo que sejam verdadeiros.',
              'Incentivar suicídio, automutilação ou transtornos alimentares.',
              'Golpes, spam, propaganda enganosa e venda de itens proibidos, como drogas e jogos de azar.',
              'Malware, links para arquivos perigosos ou pedidos de senha.',
              'Se passar por outra pessoa, pela equipe ou por um app.',
              'Publicar conteúdo de outra pessoa sem direito de usar (pirataria, plágio).',
              'Qualquer conteúdo ilegal.',
            ],
          },
        ],
      },
      {
        titulo: 'Se você ou alguém precisa de ajuda',
        blocos: [
          'Se você está passando por um momento difícil, procure apoio. No Brasil, o CVV atende 24 horas pelo telefone 188 e pelo site cvv.org.br. Em caso de risco imediato, ligue para o 192 (SAMU) ou o 190 (Polícia). Para denunciar violência contra crianças e adolescentes, ligue para o Disque 100.',
        ],
      },
      {
        titulo: 'Como denunciar',
        blocos: [
          'Quando a comunidade abrir, cada publicação terá o botão "Denunciar". Até lá, e para qualquer caso grave, escreva para spacestorew@gmail.com com o endereço do conteúdo. Leio todas as denúncias. Não é preciso ter conta para denunciar por e-mail.',
        ],
      },
      {
        titulo: 'O que eu faço',
        blocos: [
          'Dependendo da gravidade e do histórico, posso: pedir que você edite o conteúdo; remover o conteúdo; suspender a conta por um tempo; ou encerrar a conta. Em casos graves, a medida é imediata.',
          'Sempre que for possível, explico o motivo por e-mail. Se você achar que errei, responda explicando e eu revejo.',
        ],
      },
    ],
  },

  // --------------------------------------------------------------- SEGURANÇA
  {
    id: 'seguranca',
    titulo: 'Segurança',
    resumo: 'Como os apps são verificados, como você confere um download e como avisar de uma falha.',
    secoes: [
      {
        titulo: 'Como eu verifico um app antes de publicar',
        blocos: [
          'Todo app que chega pelo Creator Space passa por uma análise de segurança com o VirusTotal, que reúne vários antivírus, e por uma revisão de conteúdo feita por mim. A página de cada app mostra o resultado: quantos motores acusaram algo e um link para o relatório.',
          'Isso ajuda, mas não é garantia. O VirusTotal pode errar nos dois sentidos, e eu não consigo prever tudo o que um app faz. Leia as permissões e a descrição antes de instalar.',
        ],
      },
      {
        titulo: 'Como conferir o arquivo que você baixou',
        blocos: [
          'Cada versão mostra um código SHA-256. Depois de baixar, você pode calcular o SHA-256 do arquivo (existem apps gratuitos para isso) e comparar com o código da página. Se forem diferentes, apague o arquivo e não instale.',
          'Baixe só pelos links desta página. Os links oficiais apontam para o GitHub. Desconfie de qualquer outro endereço que ofereça os mesmos apps.',
        ],
      },
      {
        titulo: 'Aviso do Android ao instalar',
        blocos: [
          'Como os apps não vêm da Google Play, o Android pede que você autorize instalar de fonte externa, e o Play Protect pode avisar que o app não é conhecido. Isso é esperado. Autorize apenas para o navegador ou o gerenciador de arquivos que você usou, e desative a permissão depois, se preferir.',
        ],
      },
      {
        titulo: 'Proteja a sua conta',
        blocos: [
          {
            lista: [
              'Use uma senha longa e que você não usa em outros lugares.',
              'Eu nunca peço a sua senha, por e-mail ou mensagem. Desconfie de quem pedir.',
              'Saia da conta em aparelhos que não são seus.',
            ],
          },
        ],
      },
      {
        titulo: 'Encontrou uma falha?',
        blocos: [
          'Se encontrar uma falha de segurança no site, na Space Store ou no Creator Space, escreva para spacestorew@gmail.com com o que viu e como reproduzir. Peço que não divulgue antes de eu ter tempo de corrigir, e que não acesse nem altere dados de outras pessoas ao testar. Agradeço de boa-fé e vou responder.',
        ],
      },
    ],
  },
];
