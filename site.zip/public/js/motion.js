// Movimento de entrada progressivo, com redução respeitada e fallback sem IntersectionObserver.
const preferenciaMovimentoReduzido = window.matchMedia?.('(prefers-reduced-motion: reduce)');
let observador = null;

function garantirObservador() {
  if (observador || !('IntersectionObserver' in window)) return observador;
  observador = new IntersectionObserver((entradas) => {
    for (const entrada of entradas) {
      if (!entrada.isIntersecting) continue;
      entrada.target.classList.add('motion-visivel');
      observador.unobserve(entrada.target);
    }
  }, { threshold: 0.12, rootMargin: '0px 0px -5% 0px' });
  return observador;
}

export function prepararMovimento(raiz) {
  if (!raiz || preferenciaMovimentoReduzido?.matches || !('IntersectionObserver' in window)) return;
  const obs = garantirObservador();
  if (!obs) return;
  const seletores = [
    'h1', '.hero-painel', '.secao > .container > .caixa', '.coluna-titulo',
    '.linha', '.passos > li', '.ficha', '.novidade-item', '.post-item',
    '.docs-corpo > .doc', '.form-publicacao', '.docs-indice', '.app-cabecalho',
  ].join(',');
  const alvos = raiz.querySelectorAll(seletores);
  let ordem = 0;
  for (const alvo of alvos) {
    if (alvo.dataset.motionPreparado === 'true') continue;
    alvo.dataset.motionPreparado = 'true';
    alvo.dataset.motion = 'revelar';
    alvo.style.setProperty('--motion-delay', `${Math.min(ordem, 4) * 55}ms`);
    ordem += 1;
    obs.observe(alvo);
  }
  document.documentElement.classList.add('motion-ativo');
}

preferenciaMovimentoReduzido?.addEventListener?.('change', (evento) => {
  if (!evento.matches) return;
  document.querySelectorAll('[data-motion="revelar"]').forEach((elemento) => {
    elemento.classList.add('motion-visivel');
    elemento.style.removeProperty('--motion-delay');
  });
  document.documentElement.classList.remove('motion-ativo');
});
