// Datas de nascimento e idade. A data é só conferida; não aparece no perfil público.

function doisDigitos(n) {
  return String(n).padStart(2, '0');
}

// Hoje, no formato AAAA-MM-DD, no fuso do aparelho.
export function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${doisDigitos(d.getMonth() + 1)}-${doisDigitos(d.getDate())}`;
}

export function calcularIdade(iso, hoje = new Date()) {
  const [ano, mes, dia] = iso.split('-').map(Number);
  let idade = hoje.getFullYear() - ano;
  const mesAtual = hoje.getMonth() + 1;
  const jaFezAniversario = mesAtual > mes || (mesAtual === mes && hoje.getDate() >= dia);
  if (!jaFezAniversario) idade -= 1;
  return idade;
}

// Devolve { ok: true, idade } ou { ok: false, erro } com a mensagem pronta.
export function validarNascimento(iso) {
  if (!iso) return { ok: false, erro: 'Informe sua data de nascimento.' };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return { ok: false, erro: 'Essa data não parece certa. Confira.' };

  const [ano, mes, dia] = iso.split('-').map(Number);
  const data = new Date(ano, mes - 1, dia);
  const existe = data.getFullYear() === ano && data.getMonth() === mes - 1 && data.getDate() === dia;
  if (!existe) return { ok: false, erro: 'Essa data não existe. Confira o dia e o mês.' };
  if (ano < 1900) return { ok: false, erro: 'Confira o ano de nascimento.' };

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  if (data > hoje) return { ok: false, erro: 'A data de nascimento não pode ser no futuro.' };

  return { ok: true, idade: calcularIdade(iso) };
}
