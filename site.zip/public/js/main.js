// Ponto de entrada: liga tema, menu e roteador.

import { definirRotas, iniciarRoteador } from './roteador.js';
import { rotas, rotaNaoEncontrada } from './rotas.js';
import { iniciarTema } from './tema.js';
import { iniciarMenu } from './menu.js';

const raiz = document.getElementById('conteudo');
const nav = document.getElementById('nav-principal');
const links = Array.from(nav.querySelectorAll('a'));

iniciarTema(document.getElementById('botao-tema'));
const menu = iniciarMenu(document.getElementById('botao-menu'), nav);

const ano = document.getElementById('ano');
if (ano) ano.textContent = String(new Date().getFullYear());

function marcarPaginaAtual(caminho) {
  for (const link of links) {
    const prefixos = (link.dataset.prefixos || link.getAttribute('href')).split(',');
    const atual = prefixos.some((prefixo) => caminho === prefixo || caminho.startsWith(prefixo + '/'));
    if (atual) {
      link.setAttribute('aria-current', 'page');
    } else {
      link.removeAttribute('aria-current');
    }
  }
}

definirRotas(rotas, rotaNaoEncontrada);

iniciarRoteador({
  raiz,
  aoMudar: (caminho) => {
    marcarPaginaAtual(caminho);
    menu.fechar();
  },
});

// O botão de conta carrega o Firebase depois, para as páginas abrirem sem esperar por ele.
const linkConta = document.getElementById('link-conta');
import('./topo-conta.js')
  .then((modulo) => modulo.iniciarTopoConta(linkConta))
  .catch((erro) => {
    console.error('Não consegui iniciar o login', erro);
    linkConta.hidden = false;
  });
