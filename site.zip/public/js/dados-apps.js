// Leitura dos apps publicados (siteApps no Firestore). Quem escreve esses dados é só o admin.
// As regras do Firestore só deixam o público ler o que está com publicado = true.

import { db } from './firebase.js';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
} from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';

// Os dois apps do ecossistema, na ordem em que aparecem.
export const SLUGS = ['space-store', 'creator-space'];

export async function listarApps() {
  const resposta = await getDocs(query(collection(db, 'siteApps'), where('publicado', '==', true)));
  const apps = resposta.docs.map((d) => ({ slug: d.id, ...d.data() }));
  apps.sort((a, b) => SLUGS.indexOf(a.slug) - SLUGS.indexOf(b.slug));
  return apps;
}

// Devolve o app, ou null se não existe ou ainda não foi publicado.
// Se vier com previa = true, quem leu é o admin (as regras escondem rascunhos de todo mundo):
// a página mostra como prévia.
export async function obterApp(slug) {
  try {
    const resposta = await getDoc(doc(db, 'siteApps', slug));
    if (!resposta.exists()) return null;
    const dados = resposta.data();
    return { slug, ...dados, previa: dados.publicado !== true };
  } catch (erro) {
    // Para quem não é admin, as regras recusam a leitura de app não publicado.
    if (erro && erro.code === 'permission-denied') return null;
    throw erro;
  }
}

export async function listarVersoes(slug) {
  const resposta = await getDocs(
    query(collection(db, 'siteApps', slug, 'versoes'), orderBy('codigo', 'desc'), limit(10))
  );
  return resposta.docs.map((d) => d.data());
}

export async function listarCapturas(slug) {
  const resposta = await getDocs(query(collection(db, 'siteApps', slug, 'capturas'), orderBy('ordem')));
  return resposta.docs.map((d) => d.data());
}
