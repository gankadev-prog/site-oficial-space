// Ícones de traço fino, desenhados na grade de 24px. Nada de emoji.
import { s } from './dom.js';

const DESENHOS = {
  seta: ['M5 12h14', 'M13 6l6 6-6 6'],
  download: ['M12 3v12', 'M7 10l5 5 5-5', 'M5 21h14'],
  email: ['M4 5h16v14H4z', 'M4 7l8 6 8-6'],
};

export function icone(nome, { tamanho = 20 } = {}) {
  const svg = s('svg', {
    class: 'icone',
    viewBox: '0 0 24 24',
    width: tamanho,
    height: tamanho,
    fill: 'none',
    stroke: 'currentColor',
    'stroke-width': '1.75',
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
    'aria-hidden': 'true',
    focusable: 'false',
  });
  for (const d of DESENHOS[nome] || []) {
    svg.append(s('path', { d }));
  }
  return svg;
}
