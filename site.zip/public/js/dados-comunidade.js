// Dados da comunidade. As regras do Firestore continuam sendo a autoridade para toda escrita.
import { db } from './firebase.js';
import { esperarAuth } from './auth.js';
import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs, limit, orderBy, query,
  deleteField, runTransaction, serverTimestamp, setDoc, startAfter, updateDoc, where, writeBatch,
} from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';
import { LIMITE_COMENTARIO, LIMITE_TEXTO_POST, LIMITE_TITULO_POST } from './config.js';

const CATEGORIAS = ['Dúvidas', 'Sugestões', 'Mostre seu app', 'Geral'];
const MOTIVOS = ['Spam ou golpe', 'Assédio ou ameaça', 'Conteúdo sexual', 'Discurso de ódio', 'Dados pessoais expostos', 'Malware ou pirataria', 'Outro motivo'];
export { CATEGORIAS, MOTIVOS };

async function pessoaVerificada() {
  const estado = await esperarAuth();
  if (!estado.usuario || !estado.perfil) throw new Error('Entre na sua conta para continuar.');
  if (!estado.usuario.emailVerified) throw new Error('Confirme seu e-mail antes de participar.');
  if (estado.perfil.suspenso === true) throw new Error('Esta conta não pode publicar no momento.');
  return estado;
}

export async function verificarModeracao(uid) {
  if (!uid) return false;
  const snap = await getDoc(doc(db, 'admins', uid));
  return snap.exists();
}

export async function listarPosts({ depoisDoc = null, quantidade = 20 } = {}) {
  const condicoes = [where('oculto', '==', false), orderBy('criadoEm', 'desc')];
  if (depoisDoc) condicoes.push(startAfter(depoisDoc));
  condicoes.push(limit(quantidade));
  const snap = await getDocs(query(collection(db, 'posts'), ...condicoes));
  return { itens: snap.docs.map((d) => ({ id: d.id, ...d.data() })), cursor: snap.docs.at(-1) || null, temMais: snap.size === quantidade };
}

export async function obterPost(id) {
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) return null;
  const snap = await getDoc(doc(db, 'posts', id));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function listarPostsDoPerfil(uid, quantidade = 10) {
  const q = query(collection(db, 'posts'), where('autorUid', '==', uid), where('oculto', '==', false), orderBy('criadoEm', 'desc'), limit(quantidade));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function obterPerfilPublico(nick) {
  if (!/^[a-z0-9_]{3,20}$/.test(nick)) return null;
  const nickSnap = await getDoc(doc(db, 'nicks', nick));
  if (!nickSnap.exists()) return null;
  const userSnap = await getDoc(doc(db, 'usuarios', nickSnap.data().uid));
  return userSnap.exists() ? { uid: userSnap.id, ...userSnap.data() } : null;
}

export async function listarComentarios(postId, depoisDoc = null, quantidade = 20) {
  const base = [collection(db, 'posts', postId, 'comentarios'), orderBy('criadoEm', 'asc')];
  if (depoisDoc) base.push(startAfter(depoisDoc));
  base.push(limit(quantidade));
  const snap = await getDocs(query(...base));
  return { itens: snap.docs.map((d) => ({ id: d.id, ...d.data() })), cursor: snap.docs.at(-1) || null, temMais: snap.size === quantidade };
}

export async function criarPost({ titulo, texto, categoria, appSlug, midia = [] }) {
  const { usuario, perfil } = await pessoaVerificada();
  const nome = String(perfil.nome || '').trim().slice(0, 50);
  const nick = String(perfil.nick || '').slice(0, 20);
  const t = String(titulo || '').trim();
  const corpo = String(texto || '').trim();
  if (t.length < 1 || t.length > LIMITE_TITULO_POST) throw new Error('O título precisa ter de 1 a 120 caracteres.');
  if (corpo.length < 1 || corpo.length > LIMITE_TEXTO_POST) throw new Error('O texto precisa ter de 1 a 5.000 caracteres.');
  if (!CATEGORIAS.includes(categoria)) throw new Error('Escolha uma categoria válida.');
  if (!Array.isArray(midia) || midia.length > 5 || midia.some((m) => !m || !['imagem', 'video'].includes(m.tipo) || !/^https:\/\/res\.cloudinary\.com\/[A-Za-z0-9_-]+\//.test(m.url))) throw new Error('Uma das mídias não tem um endereço permitido.');
  if (midia.filter((m) => m.tipo === 'imagem').length > 4 || midia.filter((m) => m.tipo === 'video').length > 1) throw new Error('Use até quatro fotos e um vídeo.');
  const referencia = doc(collection(db, 'posts'));
  const lote = writeBatch(db);
  const novo = {
    autorUid: usuario.uid, autorNick: nick, autorNome: nome, titulo: t, texto: corpo,
    categoria, midia, criadoEm: serverTimestamp(), oculto: false, curtidas: 0, comentarios: 0,
  };
  if (appSlug === 'space-store' || appSlug === 'creator-space') novo.appSlug = appSlug;
  lote.set(referencia, novo);
  lote.update(doc(db, 'usuarios', usuario.uid), { ultimoPostEm: serverTimestamp() });
  await lote.commit();
  return referencia.id;
}

export async function editarPost(id, { titulo, texto, categoria }) {
  const { usuario } = await pessoaVerificada();
  const snap = await getDoc(doc(db, 'posts', id));
  if (!snap.exists() || snap.data().autorUid !== usuario.uid) throw new Error('Não encontrei uma publicação sua para editar.');
  const criado = snap.data().criadoEm?.toDate?.();
  if (!criado || Date.now() - criado.getTime() > 15 * 60 * 1000) throw new Error('O prazo de edição de 15 minutos terminou. Você ainda pode apagar a publicação.');
  const t = String(titulo || '').trim();
  const corpo = String(texto || '').trim();
  if (!t || t.length > LIMITE_TITULO_POST || !corpo || corpo.length > LIMITE_TEXTO_POST || !CATEGORIAS.includes(categoria)) throw new Error('Confira o título, o texto e a categoria.');
  await updateDoc(doc(db, 'posts', id), { titulo: t, texto: corpo, categoria, editadoEm: serverTimestamp() });
}

export async function apagarPost(id) {
  const { usuario } = await pessoaVerificada();
  const ref = doc(db, 'posts', id);
  const snap = await getDoc(ref);
  if (!snap.exists() || snap.data().autorUid !== usuario.uid) throw new Error('Você só pode apagar uma publicação sua.');
  await deleteDoc(ref);
}

export async function alternarCurtida(postId) {
  const { usuario, perfil } = await pessoaVerificada();
  const postRef = doc(db, 'posts', postId);
  const likeRef = doc(db, 'curtidas', `${postId}_${usuario.uid}`);
  return runTransaction(db, async (tx) => {
    const [postSnap, likeSnap] = await Promise.all([tx.get(postRef), tx.get(likeRef)]);
    if (!postSnap.exists() || postSnap.data().oculto === true) throw new Error('Esta publicação não está disponível.');
    const atual = Number(postSnap.data().curtidas) || 0;
    if (likeSnap.exists()) {
      tx.delete(likeRef);
      tx.update(postRef, { curtidas: Math.max(0, atual - 1) });
      return false;
    }
    tx.set(likeRef, { autorUid: usuario.uid, postId, criadoEm: serverTimestamp() });
    tx.update(postRef, { curtidas: atual + 1 });
    return true;
  });
}

export async function usuarioCurtiu(postId, uid) {
  if (!uid) return false;
  return (await getDoc(doc(db, 'curtidas', `${postId}_${uid}`))).exists();
}

export async function criarComentario(postId, texto) {
  const { usuario, perfil } = await pessoaVerificada();
  const corpo = String(texto || '').trim();
  if (corpo.length < 1 || corpo.length > LIMITE_COMENTARIO) throw new Error('O comentário precisa ter de 1 a 1.000 caracteres.');
  const postRef = doc(db, 'posts', postId);
  const postSnap = await getDoc(postRef);
  if (!postSnap.exists() || postSnap.data().oculto === true) throw new Error('Esta publicação não está disponível.');
  const commentRef = doc(collection(db, 'posts', postId, 'comentarios'));
  const lote = writeBatch(db);
  lote.set(commentRef, { autorUid: usuario.uid, autorNick: perfil.nick, autorNome: perfil.nome, texto: corpo, criadoEm: serverTimestamp() });
  lote.update(postRef, { comentarios: (Number(postSnap.data().comentarios) || 0) + 1, ultimoComentarioId: commentRef.id });
  await lote.commit();
}

export async function apagarComentario(postId, commentId) {
  const { usuario } = await pessoaVerificada();
  const postRef = doc(db, 'posts', postId);
  const commentRef = doc(db, 'posts', postId, 'comentarios', commentId);
  const [postSnap, commentSnap] = await Promise.all([getDoc(postRef), getDoc(commentRef)]);
  if (!postSnap.exists() || !commentSnap.exists()) return;
  if (commentSnap.data().autorUid !== usuario.uid && !(await verificarModeracao(usuario.uid))) throw new Error('Você não pode apagar este comentário.');
  const lote = writeBatch(db);
  lote.delete(commentRef);
  lote.update(postRef, { comentarios: Math.max(0, (Number(postSnap.data().comentarios) || 0) - 1), ultimoComentarioId: commentId });
  await lote.commit();
}

export async function denunciar({ alvoTipo, alvoId, motivo, detalhe = '' }) {
  const { usuario } = await pessoaVerificada();
  if (!['post', 'comentario', 'perfil', 'app'].includes(alvoTipo) || !MOTIVOS.includes(motivo)) throw new Error('Escolha um motivo da lista.');
  const nota = String(detalhe || '').trim();
  if (nota.length > 500) throw new Error('O detalhe pode ter até 500 caracteres.');
  const item = { alvoTipo, alvoId: String(alvoId).slice(0, 160), motivo, denuncianteUid: usuario.uid, criadoEm: serverTimestamp(), estado: 'pendente' };
  if (nota) item.detalhe = nota;
  await addDoc(collection(db, 'denuncias'), item);
}

export async function listarDenunciasPendentes() {
  const estado = await esperarAuth();
  if (!estado.usuario || !(await verificarModeracao(estado.usuario.uid))) throw new Error('Esta área está disponível apenas para a equipe autorizada.');
  const snap = await getDocs(query(collection(db, 'denuncias'), where('estado', '==', 'pendente'), orderBy('criadoEm', 'desc'), limit(100)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function moderarAlvo({ denunciaId, alvoTipo, alvoId, acao, motivo = '' }) {
  const estado = await pessoaVerificada();
  if (!(await verificarModeracao(estado.usuario.uid))) throw new Error('Ação não autorizada.');
  const lote = writeBatch(db);
  if (alvoTipo === 'post' && ['ocultar', 'remover'].includes(acao)) {
    const ref = doc(db, 'posts', alvoId);
    if (acao === 'remover') lote.delete(ref);
    else lote.update(ref, { oculto: true, motivoOcultacao: String(motivo).slice(0, 200) || 'Revisão da comunidade' });
  } else if (alvoTipo === 'comentario' && acao === 'remover') {
    const [postId, commentId] = String(alvoId).split(':');
    if (!postId || !commentId) throw new Error('O comentário denunciado não tem um endereço válido.');
    const postRef = doc(db, 'posts', postId);
    const commentRef = doc(db, 'posts', postId, 'comentarios', commentId);
    const [postSnap, commentSnap] = await Promise.all([getDoc(postRef), getDoc(commentRef)]);
    if (!postSnap.exists() || !commentSnap.exists()) throw new Error('O comentário já não está disponível.');
    lote.delete(commentRef);
    lote.update(postRef, { comentarios: Math.max(0, (Number(postSnap.data().comentarios) || 0) - 1), ultimoComentarioId: commentId });
  } else if (alvoTipo === 'app' && acao === 'remover') {
    if (!['space-store', 'creator-space'].includes(alvoId)) throw new Error('App não reconhecido.');
    lote.update(doc(db, 'siteApps', alvoId), { publicado: false, atualizadoEm: serverTimestamp() });
  } else if (alvoTipo === 'perfil' && ['suspender', 'reativar'].includes(acao)) {
    lote.update(doc(db, 'usuarios', alvoId), { suspenso: acao === 'suspender' });
  }
  lote.set(doc(collection(db, 'moderacao')), {
    acao, alvoTipo, alvoId: String(alvoId).slice(0, 160), motivo: String(motivo).slice(0, 200), autorUid: estado.usuario.uid, quando: serverTimestamp(),
  });
  if (denunciaId) lote.update(doc(db, 'denuncias', denunciaId), { estado: 'resolvida' });
  await lote.commit();
}

export async function resumirAvaliacoes(appSlug) {
  const snap = await getDocs(query(collection(db, 'avaliacoes'), where('appSlug', '==', appSlug), orderBy('atualizadoEm', 'desc'), limit(200)));
  const notas = snap.docs.map((d) => Number(d.data().nota)).filter((n) => Number.isInteger(n) && n >= 1 && n <= 5);
  const media = notas.length ? notas.reduce((a, b) => a + b, 0) / notas.length : null;
  return { quantidade: notas.length, media, itens: snap.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => (b.atualizadoEm?.toMillis?.() || 0) - (a.atualizadoEm?.toMillis?.() || 0)).slice(0, 20), aviso: 'Resumo calculado no navegador sobre até 200 avaliações; sem agregador no servidor.' };
}

export async function obterMinhaAvaliacao(appSlug, uid) {
  if (!uid) return null;
  const snap = await getDoc(doc(db, 'avaliacoes', `${appSlug}_${uid}`));
  return snap.exists() ? snap.data() : null;
}

export async function salvarAvaliacao(appSlug, nota, comentario = '') {
  const { usuario, perfil } = await pessoaVerificada();
  if (!['space-store', 'creator-space'].includes(appSlug)) throw new Error('App não reconhecido.');
  const n = Number(nota);
  const texto = String(comentario || '').trim();
  if (!Number.isInteger(n) || n < 1 || n > 5 || texto.length > 500) throw new Error('A avaliação precisa ser de 1 a 5 estrelas e o comentário pode ter até 500 caracteres.');
  const ref = doc(db, 'avaliacoes', `${appSlug}_${usuario.uid}`);
  const anterior = await getDoc(ref);
  const item = { appSlug, autorUid: usuario.uid, autorNick: perfil.nick, nota: n, atualizadoEm: serverTimestamp() };
  if (!anterior.exists()) item.criadoEm = serverTimestamp();
  if (texto) item.comentario = texto;
  else if (anterior.exists() && anterior.data().comentario) item.comentario = deleteField();
  await setDoc(ref, item, { merge: true });
}
