// Mapa de endereços do site. Páginas que ainda não existem usam a página "em construção".

const emBreve = () => import('./paginas/emBreve.js');

export const rotas = [
  { caminho: '/', carregar: () => import('./paginas/inicio.js') },
  { caminho: '/ecossistema', carregar: () => import('./paginas/ecossistema.js') },
  { caminho: '/sobre', carregar: () => import('./paginas/sobre.js') },

  { caminho: '/entrar', carregar: () => import('./paginas/entrar.js') },
  { caminho: '/cadastrar', carregar: () => import('./paginas/cadastrar.js') },
  { caminho: '/esqueci-senha', carregar: () => import('./paginas/esqueci.js') },
  { caminho: '/conta', carregar: () => import('./paginas/conta.js') },

  { caminho: '/downloads', carregar: () => import('./paginas/downloads.js') },
  { caminho: '/apps/:slug', carregar: () => import('./paginas/app.js') },

  { caminho: '/novidades', carregar: () => import('./paginas/novidades.js') },
  { caminho: '/novidades/:slug', carregar: () => import('./paginas/novidade.js') },

  {
    caminho: '/comunidade',
    carregar: emBreve,
    dados: {
      titulo: 'Comunidade',
      previsao: 'Um espaço para dúvidas, sugestões e para mostrar apps. Ainda está sendo construído.',
    },
  },
  {
    caminho: '/comunidade/post/:id',
    carregar: emBreve,
    dados: { titulo: 'Publicação', previsao: 'A comunidade ainda está sendo construída.' },
  },
  {
    caminho: '/u/:nick',
    carregar: emBreve,
    dados: { titulo: 'Perfil', previsao: 'Os perfis ainda estão sendo construídos.' },
  },
  {
    caminho: '/docs',
    carregar: emBreve,
    dados: {
      titulo: 'Documentação e políticas',
      previsao:
        'Termos de Uso, Privacidade, Cookies, Diretrizes da Comunidade e as demais regras vão ficar aqui, numa página só.',
    },
  },
  {
    caminho: '/contato',
    carregar: emBreve,
    dados: { titulo: 'Contato', previsao: 'O formulário de contato ainda está sendo construído.' },
  },
  {
    caminho: '/faq',
    carregar: emBreve,
    dados: { titulo: 'Perguntas frequentes', previsao: 'As perguntas frequentes ainda estão sendo escritas.' },
  },
];

export const rotaNaoEncontrada = { carregar: () => import('./paginas/naoEncontrada.js') };
