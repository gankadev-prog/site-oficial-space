// Mapa de rotas públicas e privadas. Páginas privadas sempre atualizam robots para noindex.
export const rotas = [
  { caminho: '/', carregar: () => import('./paginas/inicio.js') },
  { caminho: '/ecossistema', carregar: () => import('./paginas/ecossistema.js') },
  { caminho: '/sobre', carregar: () => import('./paginas/sobre.js') },
  { caminho: '/entrar', carregar: () => import('./paginas/entrar.js') },
  { caminho: '/cadastrar', carregar: () => import('./paginas/cadastrar.js') },
  { caminho: '/esqueci-senha', carregar: () => import('./paginas/esqueci.js') },
  { caminho: '/conta', carregar: () => import('./paginas/conta.js') },
  { caminho: '/conta/moderacao', carregar: () => import('./paginas/moderacao.js') },
  { caminho: '/downloads', carregar: () => import('./paginas/downloads.js') },
  { caminho: '/apps/:slug', carregar: () => import('./paginas/app.js') },
  { caminho: '/novidades', carregar: () => import('./paginas/novidades.js') },
  { caminho: '/novidades/:slug', carregar: () => import('./paginas/novidade.js') },
  { caminho: '/comunidade', carregar: () => import('./paginas/comunidade.js') },
  { caminho: '/comunidade/post/:id', carregar: () => import('./paginas/post.js') },
  { caminho: '/u/:nick', carregar: () => import('./paginas/perfil.js') },
  { caminho: '/docs', carregar: () => import('./paginas/docs.js') },
  { caminho: '/contato', carregar: () => import('./paginas/contato.js') },
  { caminho: '/faq', carregar: () => import('./paginas/faq.js') },
];
export const rotaNaoEncontrada = { carregar: () => import('./paginas/naoEncontrada.js') };
