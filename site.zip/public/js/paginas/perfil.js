import { h } from '../dom.js';
import { esperarAuth } from '../auth.js';
import { imagemBase64, formatarData } from '../formatar.js';
import { obterPerfilPublico, listarPostsDoPerfil } from '../dados-comunidade.js';
import { formularioDenuncia } from '../denuncia-ui.js';
import { renderizarCorpo } from '../markup.js';
import { mensagemDeErro } from '../erros.js';
import { paginaForm } from './_comum.js';

export default async function perfil({ params }) {
  const nick = String(params.nick || '').toLowerCase();
  let pessoa;
  try { pessoa = await obterPerfilPublico(nick); }
  catch (erro) { return { titulo: 'Perfil', semIndexar: true, conteudo: paginaForm({ titulo: 'Não consegui carregar este perfil', lead: mensagemDeErro(erro) }, h('a', { href: '/comunidade' }, 'Voltar à comunidade')) }; }
  if (!pessoa) return { titulo: 'Perfil não encontrado', semIndexar: true, conteudo: paginaForm({ titulo: 'Não encontrei este perfil', lead: 'Confira o endereço ou volte à comunidade.' }, h('a', { href: '/comunidade' }, 'Voltar à comunidade')) };
  const banner = imagemBase64(pessoa.bannerMime, pessoa.bannerBase64, 220000);
  const avatar = imagemBase64(pessoa.avatarMime, pessoa.avatarBase64, 150000);
  const moldura = ['linha', 'folha', 'arco'].includes(pessoa.moldura) ? ` moldura-${pessoa.moldura}` : '';
  let posts = [];
  if (pessoa.suspenso !== true) { try { posts = await listarPostsDoPerfil(pessoa.uid, 10); } catch (erro) { console.error('Perfil: publicações', erro); } }
  const estado = await esperarAuth();
  const denunciarBotao = estado.usuario && estado.usuario.emailVerified && estado.usuario.uid !== pessoa.uid && pessoa.suspenso !== true
    ? formularioDenuncia('perfil', pessoa.uid, 'Denunciar perfil') : null;
  const conteudos = posts.map((p) => h('article', { class: 'post-item' }, h('h3', { class: 'post-titulo' }, h('a', { href: '/comunidade/post/' + encodeURIComponent(p.id) }, p.titulo)), h('time', {}, formatarData(p.criadoEm)), ...renderizarCorpo(String(p.texto || '').slice(0, 600), { permitirImagens: false }).nos));
  const cabecalho = h('section', { class: 'pagina-topo' }, h('div', { class: 'container' }, banner ? h('img', { class: 'banner-perfil', src: banner, alt: `Banner de ${pessoa.nome || nick}` }) : null,
    h('div', { class: 'perfil-cabecalho' }, avatar ? h('img', { class: `avatar perfil-avatar-grande${moldura}`, src: avatar, alt: `Avatar de ${pessoa.nome || nick}` }) : h('span', { class: `avatar-fallback perfil-avatar-grande${moldura}`, 'aria-hidden': 'true' }, String(pessoa.nome || nick).slice(0,1)),
      h('div', {}, h('p', { class: 'sobretitulo' }, 'Perfil público'), h('h1', {}, pessoa.nome || 'Pessoa usuária'), h('p', { class: 'suave' }, '@' + pessoa.nick))),
    pessoa.bio ? h('p', {}, pessoa.bio) : null,
    pessoa.moldura ? h('span', { class: 'etiqueta' }, 'Moldura de perfil') : null,
    pessoa.suspenso === true ? h('p', { class: 'alerta alerta-erro', role: 'status' }, 'Esta conta está suspensa.') : h('p', { class: 'suave' }, 'Membro desde ' + formatarData(pessoa.criadoEm)),
    h('div', { class: 'acoes' }, denunciarBotao)));
  return { titulo: pessoa.nome || 'Perfil', descricao: `Perfil público de @${pessoa.nick}.`, conteudo: h('div', {}, cabecalho, h('section', { class: 'secao' }, h('div', { class: 'container' }, h('h2', {}, 'Publicações recentes'), pessoa.suspenso ? h('p', {}, 'As publicações deste perfil não estão disponíveis.') : conteudos.length ? conteudos : h('p', { class: 'estado-vazio' }, 'Ainda não há publicações públicas neste perfil.')))) };
}
