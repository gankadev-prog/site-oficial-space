// Peças que várias páginas usam.

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { navegar } from '../roteador.js';

// Seção da página. "rotulo" é o id do título da seção (usado para acessibilidade e âncoras).
export function secao({ rotulo, colunas = false } = {}, ...filhos) {
  const interno = h('div', { class: colunas ? 'container duas-colunas' : 'container' }, ...filhos);
  return h('section', { class: 'secao', 'aria-labelledby': rotulo }, interno);
}

export function linkSeta(href, texto) {
  return h('a', { class: 'link-seta', href }, texto, icone('seta', { tamanho: 18 }));
}

// Página curta com título e um corpo (formulários, avisos).
export function paginaForm({ sobretitulo, titulo, lead }, ...corpo) {
  return h(
    'section',
    { class: 'pagina-curta' },
    h(
      'div',
      { class: 'container' },
      sobretitulo ? h('p', { class: 'sobretitulo' }, sobretitulo) : null,
      h('h1', {}, titulo),
      lead ? h('p', { class: 'lead' }, lead) : null,
      ...corpo
    )
  );
}

// Só aceita caminhos do próprio site ("/conta"), nunca endereços de fora.
export function destinoSeguro(valor) {
  if (typeof valor !== 'string') return null;
  if (!valor.startsWith('/') || valor.startsWith('//') || valor.startsWith('/\\')) return null;
  return valor;
}

export function sufixoVoltar(voltar) {
  return voltar ? '?voltar=' + encodeURIComponent(voltar) : '';
}

// Faixa de aviso para o admin, quando ele abre algo que ainda não foi publicado.
export function avisoPrevia() {
  return h(
    'div',
    { class: 'previa' },
    h(
      'div',
      { class: 'container' },
      h('strong', {}, 'Prévia. '),
      'Isto ainda não foi publicado. Só você, como admin, consegue ver esta página.'
    )
  );
}

// Manda a pessoa para outra página. O roteador descarta a página que estava sendo montada.
export function redirecionar(destino) {
  navegar(destino, { substituir: true });
  return { titulo: null, semIndexar: true, conteudo: h('div', {}) };
}
