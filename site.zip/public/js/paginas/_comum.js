// Peças que várias páginas usam.

import { h } from '../dom.js';
import { icone } from '../icones.js';

// Seção da página. "rotulo" é o id do título da seção (usado para acessibilidade e âncoras).
export function secao({ rotulo, colunas = false } = {}, ...filhos) {
  const interno = h('div', { class: colunas ? 'container duas-colunas' : 'container' }, ...filhos);
  return h('section', { class: 'secao', 'aria-labelledby': rotulo }, interno);
}

export function linkSeta(href, texto) {
  return h('a', { class: 'link-seta', href }, texto, icone('seta', { tamanho: 18 }));
}
