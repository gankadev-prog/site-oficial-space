import { h } from '../dom.js';
import { esperarAuth } from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { formatarData } from '../formatar.js';
import { renderizarCorpo } from '../markup.js';
import { listarPosts, criarPost, CATEGORIAS, LIMITE_ALTERNATIVO } from '../dados-comunidade.js';
import { enviarMidia } from '../upload-cloudinary.js';
import { LIMITE_FOTO_ORIGINAL_BYTES, LIMITE_VIDEO_COMUNIDADE_BYTES } from '../config.js';
import { paginaForm } from './_comum.js';
import { linkAutor } from '../usuario-ui.js';

function dataRelativa(carimbo) {
  const d = carimbo?.toDate?.();
  if (!d) return 'Data não informada';
  const dias = Math.floor((Date.now() - d.getTime()) / 86400000);
  if (dias === 0) return 'hoje';
  if (dias === 1) return 'ontem';
  if (dias < 7) return `há ${dias} dias`;
  return formatarData(carimbo);
}
function postItem(item) {
  const autor = linkAutor(item.autorNick, item.autorNome);
  const corpo = renderizarCorpo(String(item.texto || '').slice(0, 600), { permitirImagens: false });
  return h('article', { class: 'post-item' },
    h('div', { class: 'post-meta' }, autor, h('span', {}, h('a', { href: '/u/' + encodeURIComponent(item.autorNick || '') }, `${item.autorNome || 'Pessoa'} · @${item.autorNick || '—'}`)), h('time', { datetime: item.criadoEm?.toDate?.().toISOString?.() || '' }, dataRelativa(item.criadoEm)), h('span', { class: 'etiqueta' }, item.categoria || 'Geral'), item.appSlug ? h('span', { class: 'etiqueta' }, item.appSlug === 'space-store' ? 'Space Store' : 'Creator Space') : null),
    h('h2', { class: 'post-titulo' }, h('a', { href: '/comunidade/post/' + encodeURIComponent(item.id) }, item.titulo || 'Publicação')),
    h('div', {}, ...corpo.nos),
    item.midia?.length ? h('div', { class: 'post-midia' }, item.midia.slice(0, 5).map((m) => m.tipo === 'video' ? h('video', { src: m.url, controls: true, preload: 'none', 'aria-label': 'Vídeo da publicação' }) : h('img', { src: m.url, alt: 'Imagem da publicação', loading: 'lazy' }))) : null,
    h('p', { class: 'post-acoes' }, h('span', {}, `${Number(item.curtidas) || 0} curtidas`), h('a', { href: '/comunidade/post/' + encodeURIComponent(item.id) }, `${Number(item.comentarios) || 0} comentários`)));
}

export default async function comunidade() {
  const estado = await esperarAuth();
  let pagina = { itens: [], cursor: null, temMais: false };
  let erroLista = '';
  try { pagina = await listarPosts(); } catch (erro) { erroLista = mensagemDeErro(erro); }
  const lista = h('div', { class: 'feed-lista', 'aria-live': 'polite' });
  const status = h('p', { class: 'suave', role: 'status' });
  const filtroCategoria = h('select', { id: 'filtro-categoria' }, h('option', { value: '' }, 'Todas as categorias'), CATEGORIAS.map((c) => h('option', { value: c }, c)));
  const filtroApp = h('select', { id: 'filtro-app' }, h('option', { value: '' }, 'Todos os apps'), h('option', { value: 'space-store' }, 'Space Store'), h('option', { value: 'creator-space' }, 'Creator Space'), h('option', { value: 'nenhum' }, 'Sem app relacionado'));
  let itens = pagina.itens;
  function renderLista() {
    const filtrados = itens.filter((p) => (!filtroCategoria.value || p.categoria === filtroCategoria.value) && (!filtroApp.value || (filtroApp.value === 'nenhum' ? !p.appSlug : p.appSlug === filtroApp.value)));
    lista.replaceChildren(...filtrados.map(postItem));
    if (!filtrados.length) {
      status.className = 'status-vazio';
      status.textContent = itens.length ? 'Nenhuma publicação corresponde a esses filtros.' : 'Ainda não há publicações por aqui. Quando alguém publicar, elas aparecem nesta lista.';
    } else {
      status.className = pagina.indiceAlternativo ? 'status-vazio' : 'suave';
      status.textContent = `${filtrados.length} publicações carregadas.`;
    }
    if (pagina.indiceAlternativo) {
      status.className = 'status-vazio';
      status.textContent += ` A consulta está usando uma alternativa limitada a ${LIMITE_ALTERNATIVO} publicações; crie os índices do arquivo firestore.indexes.json no Firebase para paginação integral.`;
    }
  }
  filtroCategoria.addEventListener('change', renderLista); filtroApp.addEventListener('change', renderLista);
  if (erroLista) {
    status.className = 'status-erro';
    status.textContent = `Não consegui carregar a comunidade. ${erroLista}`;
    status.append(' ', h('button', { type: 'button', class: 'link-discreto', onclick: () => window.location.reload() }, 'Recarregar'));
  } else renderLista();

  let formulario = null;
  if (estado.usuario && estado.perfil && estado.usuario.emailVerified && estado.perfil.suspenso !== true) {
    const aviso = h('p', { role: 'status', 'aria-live': 'polite' });
    const titulo = h('input', { id: 'novo-titulo', name: 'titulo', maxlength: '120', required: true });
    const texto = h('textarea', { id: 'novo-texto', name: 'texto', maxlength: '5000', rows: '5', required: true, 'aria-describedby': 'novo-ajuda' });
    const categoria = h('select', { id: 'nova-categoria', name: 'categoria', required: true }, CATEGORIAS.map((c) => h('option', { value: c }, c)));
    const appSlug = h('select', { id: 'novo-app', name: 'appSlug' }, h('option', { value: '' }, 'Nenhum app'), h('option', { value: 'space-store' }, 'Space Store'), h('option', { value: 'creator-space' }, 'Creator Space'));
    const arquivos = h('input', { id: 'novo-arquivo', name: 'midia', type: 'file', accept: 'image/jpeg,image/png,image/webp,video/*', multiple: true, 'aria-describedby': 'midia-ajuda' });
    const progresso = h('progress', { class: 'progresso', max: 100, value: 0, 'aria-label': 'Progresso do envio de mídia' });
    const enviar = h('button', { class: 'botao botao-primario', type: 'submit' }, 'Publicar');
    const form = h('form', { class: 'form-publicacao' }, aviso,
      h('div', { class: 'campo' }, h('label', { for: 'novo-titulo' }, 'Título'), titulo),
      h('div', { class: 'campo' }, h('label', { for: 'novo-texto' }, 'Texto'), h('p', { id: 'novo-ajuda', class: 'campo-ajuda' }, 'Até 5.000 caracteres. Marcação simples é aceita; não use HTML.'), texto),
      h('div', { class: 'campo' }, h('label', { for: 'nova-categoria' }, 'Categoria'), categoria),
      h('div', { class: 'campo' }, h('label', { for: 'novo-app' }, 'App relacionado (opcional)'), appSlug),
      h('div', { class: 'campo' }, h('label', { for: 'novo-arquivo' }, 'Fotos ou vídeo (opcional)'), h('p', { id: 'midia-ajuda', class: 'campo-ajuda' }, 'Até 4 fotos JPEG, PNG ou WebP (20 MB por arquivo, reduzidas no aparelho) e 1 vídeo de até 54 segundos e 50 MB.'), arquivos), progresso,
      h('div', { class: 'acoes' }, enviar));
    form.addEventListener('submit', async (evento) => {
      evento.preventDefault(); aviso.textContent = '';
      const tituloValor = titulo.value.trim(); const textoValor = texto.value.trim(); const selecionados = Array.from(arquivos.files || []);
      if (!tituloValor || tituloValor.length > 120 || !textoValor || textoValor.length > 5000) { aviso.textContent = 'Confira: título de 1 a 120 caracteres e texto de 1 a 5.000.'; return; }
      const fotos = selecionados.filter((f) => ['image/jpeg', 'image/png', 'image/webp'].includes(String(f.type || '').toLowerCase()));
      const videos = selecionados.filter((f) => String(f.type || '').toLowerCase().startsWith('video/'));
      if (fotos.length + videos.length !== selecionados.length) { aviso.textContent = 'Escolha fotos JPEG, PNG ou WebP e vídeos compatíveis.'; return; }
      if (fotos.length > 4 || videos.length > 1) { aviso.textContent = 'Escolha até quatro fotos e um vídeo.'; return; }
      if (fotos.some((f) => f.size > LIMITE_FOTO_ORIGINAL_BYTES)) { aviso.textContent = 'Cada foto pode ter até 20 MB antes da redução no aparelho.'; return; }
      if (videos.some((f) => f.size > LIMITE_VIDEO_COMUNIDADE_BYTES)) { aviso.textContent = 'O vídeo pode ter até 50 MB e 54 segundos.'; return; }
      enviar.disabled = true; enviar.textContent = 'Enviando…';
      try {
        const midia = [];
        for (const arquivo of selecionados) {
          const envio = await import('../upload-cloudinary.js').then((m) => m.enviarMidia(arquivo, (p) => { progresso.value = p; progresso.setAttribute('aria-valuenow', String(p)); }));
          midia.push(envio);
        }
        const id = await criarPost({ titulo: tituloValor, texto: textoValor, categoria: categoria.value, appSlug: appSlug.value, midia });
        window.location.assign('/comunidade/post/' + encodeURIComponent(id));
      } catch (erro) { aviso.textContent = mensagemDeErro(erro); enviar.disabled = false; enviar.textContent = 'Publicar'; }
    });
    formulario = h('section', { class: 'secao', 'aria-labelledby': 'criar-post' }, h('div', { class: 'container' }, h('h2', { id: 'criar-post' }, 'Escrever na comunidade'), form));
  } else if (estado.usuario && !estado.usuario.emailVerified) {
    formulario = h('section', { class: 'secao' }, h('div', { class: 'container caixa' }, h('p', {}, 'Confirme seu e-mail em ', h('a', { href: '/conta' }, 'Sua conta'), ' antes de publicar.')));
  } else if (!estado.usuario) {
    formulario = h('section', { class: 'secao' }, h('div', { class: 'container caixa' }, h('p', {}, 'Entre na sua conta para participar.', ' ', h('a', { href: '/entrar?voltar=%2Fcomunidade' }, 'Entrar'), ' ou ', h('a', { href: '/cadastrar?voltar=%2Fcomunidade' }, 'criar conta'), '.')));
  } else {
    formulario = h('section', { class: 'secao' }, h('div', { class: 'container caixa' }, h('p', {}, 'Esta conta não pode publicar no momento.')));
  }
  const mais = h('button', { type: 'button', class: 'botao botao-secundario', hidden: !pagina.temMais }, 'Carregar mais publicações');
  mais.addEventListener('click', async () => {
    mais.disabled = true; mais.textContent = 'Carregando…';
    try { const proxima = await listarPosts({ depoisDoc: pagina.cursor }); pagina = proxima; itens = [...itens, ...proxima.itens]; renderLista(); mais.hidden = !proxima.temMais; }
    catch (erro) { status.className = 'status-erro'; status.textContent = `Não consegui carregar mais publicações. ${mensagemDeErro(erro)}`; }
    finally { mais.disabled = false; mais.textContent = 'Carregar mais publicações'; }
  });
  const filtros = h('div', { class: 'feed-filtros' }, h('div', { class: 'campo' }, h('label', { for: 'filtro-categoria' }, 'Categoria'), filtroCategoria), h('div', { class: 'campo' }, h('label', { for: 'filtro-app' }, 'App'), filtroApp));
  return { titulo: 'Comunidade', descricao: 'Dúvidas, sugestões e publicações de pessoas que usam o ecossistema Space.', conteudo: h('div', {}, paginaForm({ sobretitulo: 'Espaço de conversa', titulo: 'Comunidade', lead: 'Compartilhe dúvidas e ideias com respeito. Regras de participação em Diretrizes da Comunidade.' }, formulario), h('section', { class: 'secao', 'aria-labelledby': 'feed-titulo' }, h('div', { class: 'container' }, h('h2', { id: 'feed-titulo' }, 'Publicações'), filtros, status, lista, h('div', { class: 'acoes' }, mais)))) };
}
