import { h } from '../dom.js';
import { paginaForm } from './_comum.js';
import { campo, areaAlerta, botaoEnvio, ocupar, EMAIL_REGEX } from './_forms.js';
import { mensagemDeErro } from '../erros.js';

const ASSUNTOS = ['Dúvida', 'Bug', 'Denúncia', 'Imprensa/Parceria', 'Privacidade/LGPD'];

export default function contato() {
  const alerta = areaAlerta();
  const nome = campo({ id: 'contato-nome', rotulo: 'Seu nome', maximo: 80 });
  const email = campo({ id: 'contato-email', rotulo: 'E-mail para resposta', tipo: 'email', maximo: 160, autocompletar: 'email' });
  const mensagem = campo({ id: 'contato-mensagem', rotulo: 'Mensagem', tipo: 'textarea', maximo: 2000, ajuda: 'Até 2.000 caracteres.' });
  const assunto = h('select', { id: 'contato-assunto', name: 'assunto', required: true }, ASSUNTOS.map((a) => h('option', { value: a }, a)));
  const botao = botaoEnvio('Enviar mensagem');
  // Campo-isca: pessoas não o veem; um robô que o preencher não envia nada.
  const isca = h('div', { class: 'campo campo-isca', 'aria-hidden': 'true' }, h('label', { for: 'site-web' }, 'Deixe este campo vazio'), h('input', { id: 'site-web', name: 'site-web', type: 'text', tabindex: '-1', autocomplete: 'off' }));

  async function enviar(evento) {
    evento.preventDefault();
    alerta.limpar();
    [nome, email, mensagem].forEach((c) => c.limpar());
    const n = nome.valor().trim();
    const e = email.valor().trim();
    const m = mensagem.valor().trim();
    if (!n || n.length > 80) nome.erro('Digite seu nome, com até 80 caracteres.');
    if (!EMAIL_REGEX.test(e) || e.length > 160) email.erro('Confira o e-mail para resposta.');
    if (!m || m.length > 2000) mensagem.erro('A mensagem precisa ter até 2.000 caracteres.');
    if (isca.querySelector('input').value) { alerta.ok('Recebi sua mensagem.'); return; }
    if ([nome, email, mensagem].some((c) => c.entrada.getAttribute('aria-invalid') === 'true')) return;
    ocupar(botao, true, 'Enviando…');
    try {
      const { db } = await import('../firebase.js');
      const { addDoc, collection, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js');
      await addDoc(collection(db, 'contatos'), { nome: n, email: e, assunto: assunto.value, mensagem: m, criadoEm: serverTimestamp() });
      alerta.ok('Mensagem enviada. Obrigado por escrever. Não prometo um prazo fixo; retorno quando conseguir analisar.');
      nome.entrada.value = ''; email.entrada.value = ''; mensagem.entrada.value = '';
    } catch (erro) {
      alerta.erro(mensagemDeErro(erro) + ' Se preferir, escreva para spacestorew@gmail.com.');
    } finally { ocupar(botao, false); }
  }
  return {
    titulo: 'Contato',
    descricao: 'Fale com Guilherme sobre dúvidas, bugs, denúncias, parcerias ou privacidade.',
    conteudo: paginaForm({ sobretitulo: 'Ajuda', titulo: 'Contato', lead: 'O e-mail spacestorew@gmail.com também fica disponível caso o formulário não funcione.' },
      h('p', {}, h('a', { class: 'link-seta', href: 'mailto:spacestorew@gmail.com' }, 'Escrever por e-mail')),
      h('form', { class: 'form', novalidate: true, onsubmit: enviar }, alerta.el, nome.el, email.el,
        h('div', { class: 'campo' }, h('label', { for: 'contato-assunto' }, 'Assunto'), assunto), mensagem.el, isca,
        h('div', { class: 'acoes' }, botao))),
  };
}
