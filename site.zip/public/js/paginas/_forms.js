// Peças de formulário: campo com rótulo, ajuda e erro, caixa de marcar, avisos e botões.

import { h } from '../dom.js';

// Campo de texto (ou textarea, com tipo: 'textarea').
export function campo({ id, rotulo, tipo = 'text', autocompletar, ajuda, maximo, valor = '', extras = {} }) {
  const ajudaId = ajuda ? id + '-ajuda' : null;
  const erroId = id + '-erro';
  const atributos = {
    id,
    name: id,
    autocomplete: autocompletar,
    maxlength: maximo,
    'aria-describedby': [ajudaId, erroId].filter(Boolean).join(' '),
    ...extras,
  };

  let entrada;
  if (tipo === 'textarea') {
    entrada = h('textarea', { ...atributos, rows: 4 });
    entrada.value = valor;
  } else {
    entrada = h('input', { ...atributos, type: tipo, value: valor });
  }

  const erroEl = h('p', { class: 'campo-erro', id: erroId });
  const el = h(
    'div',
    { class: 'campo' },
    h('label', { for: id }, rotulo),
    ajuda ? h('p', { class: 'campo-ajuda', id: ajudaId }, ajuda) : null,
    entrada,
    erroEl
  );

  return {
    el,
    entrada,
    valor: () => entrada.value,
    erro(texto) {
      erroEl.textContent = texto;
      entrada.setAttribute('aria-invalid', 'true');
    },
    limpar() {
      erroEl.textContent = '';
      entrada.removeAttribute('aria-invalid');
    },
  };
}

// Caixa de marcar. "rotulo" pode ter texto e links.
export function caixaMarcar({ id, rotulo }) {
  const erroId = id + '-erro';
  const entrada = h('input', { id, name: id, type: 'checkbox', 'aria-describedby': erroId });
  const erroEl = h('p', { class: 'campo-erro', id: erroId });
  const el = h(
    'div',
    { class: 'campo' },
    h('div', { class: 'marcar' }, entrada, h('label', { for: id }, rotulo)),
    erroEl
  );

  return {
    el,
    entrada,
    marcado: () => entrada.checked,
    erro(texto) {
      erroEl.textContent = texto;
      entrada.setAttribute('aria-invalid', 'true');
    },
    limpar() {
      erroEl.textContent = '';
      entrada.removeAttribute('aria-invalid');
    },
  };
}

// Área de avisos. Fica na página desde o começo para leitores de tela anunciarem o que entrar.
export function areaAlerta() {
  const el = h('div', { class: 'alerta-area', 'aria-live': 'polite' });
  return {
    el,
    erro(texto) {
      el.replaceChildren(h('p', { class: 'alerta alerta-erro' }, texto));
    },
    ok(texto) {
      el.replaceChildren(h('p', { class: 'alerta alerta-ok' }, texto));
    },
    limpar() {
      el.replaceChildren();
    },
  };
}

export function botaoEnvio(texto, classe = 'botao botao-primario') {
  return h('button', { type: 'submit', class: classe }, texto);
}

// Trava o botão enquanto espera o servidor, para a pessoa não enviar duas vezes.
export function ocupar(botao, ocupado, textoOcupado) {
  if (ocupado) {
    botao.dataset.texto = botao.textContent;
    botao.textContent = textoOcupado;
    botao.disabled = true;
    botao.setAttribute('aria-busy', 'true');
  } else {
    botao.textContent = botao.dataset.texto || botao.textContent;
    botao.disabled = false;
    botao.removeAttribute('aria-busy');
  }
}

// Leva o foco ao primeiro campo com erro.
export function focarPrimeiroErro(campos) {
  const primeiro = campos.find((c) => c.entrada.getAttribute('aria-invalid') === 'true');
  if (primeiro) primeiro.entrada.focus();
}

export const EMAIL_REGEX = /^\S+@\S+\.\S+$/;
