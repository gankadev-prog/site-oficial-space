// Página provisória para o que ainda não foi construído.

import { h } from '../dom.js';

export default function emBreve({ dados }) {
  const titulo = dados.titulo || 'Em construção';
  const previsao = dados.previsao || 'Esta página ainda está sendo construída.';

  return {
    titulo,
    descricao: previsao,
    conteudo: h(
      'section',
      { class: 'pagina-curta' },
      h(
        'div',
        { class: 'container' },
        h('p', { class: 'sobretitulo' }, 'Em construção'),
        h('h1', {}, titulo),
        h('p', { class: 'lead' }, previsao),
        h(
          'p',
          {},
          'Enquanto isso, você pode me escrever em ',
          h('a', { href: 'mailto:spacestorew@gmail.com' }, 'spacestorew@gmail.com'),
          '.'
        ),
        h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/' }, 'Voltar ao início'))
      )
    ),
  };
}
