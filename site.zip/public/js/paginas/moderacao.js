import { h } from '../dom.js';
import { esperarAuth } from '../auth.js';
import { navegar } from '../roteador.js';
import { listarDenunciasPendentes, moderarAlvo, MOTIVOS, verificarModeracao } from '../dados-comunidade.js';
import { mensagemDeErro } from '../erros.js';
import { paginaForm } from './_comum.js';

export default async function moderacao() {
  const estado = await esperarAuth();
  if (!estado.usuario) { navegar('/entrar?voltar=' + encodeURIComponent('/conta/moderacao'), { substituir: true }); return { titulo: 'Moderação', semIndexar: true, conteudo: h('div', {}) }; }
  if (!(await verificarModeracao(estado.usuario.uid).catch(() => false))) return { titulo: 'Área restrita', semIndexar: true, conteudo: paginaForm({ titulo: 'Esta área não está disponível para sua conta', lead: 'Volte para Sua conta.' }, h('a', { href: '/conta' }, 'Sua conta')) };
  const status = h('p', { role: 'status', 'aria-live': 'polite' });
  let denuncias = [];
  try { denuncias = await listarDenunciasPendentes(); }
  catch (erro) { status.textContent = mensagemDeErro(erro); }
  const lista = h('div', {});
  function atualizar() {
    if (!denuncias.length) { lista.replaceChildren(h('p', { class: 'estado-vazio' }, 'Não há denúncias pendentes.')); return; }
    lista.replaceChildren(...denuncias.map((d) => {
      const postId = d.alvoTipo === 'comentario' ? String(d.alvoId || '').split(':')[0] : d.alvoId;
      const destino = d.alvoTipo === 'post' || d.alvoTipo === 'comentario'
        ? '/comunidade/post/' + encodeURIComponent(postId || '')
        : d.alvoTipo === 'app' ? '/apps/' + encodeURIComponent(d.alvoId || '')
          : '/conta/moderacao';
      const alvo = h('a', { href: destino }, `Abrir contexto (${d.alvoTipo})`);
      const detalhe = h('p', {}, d.detalhe || 'Sem detalhe adicional.');
      const motivo = h('p', {}, `Motivo: ${d.motivo || 'não informado'}`);
      const feedback = h('p', { role: 'status', 'aria-live': 'polite' });
      const acoes = [];
      const tipos = d.alvoTipo === 'post' ? [['ocultar', 'Ocultar'], ['remover', 'Remover']] : d.alvoTipo === 'perfil' ? [['suspender', 'Suspender perfil'], ['reativar', 'Reativar perfil']] : [['remover', 'Remover']];
      for (const [acao, texto] of tipos) {
        const b = h('button', { type: 'button', class: 'botao botao-secundario' }, texto);
        b.addEventListener('click', async () => { b.disabled = true; try { await moderarAlvo({ denunciaId: d.id, alvoTipo: d.alvoTipo, alvoId: d.alvoId, acao, motivo: d.motivo }); denuncias = denuncias.filter((x) => x.id !== d.id); atualizar(); status.textContent = 'Ação registrada.'; } catch (e) { feedback.textContent = mensagemDeErro(e); b.disabled = false; } });
        acoes.push(b);
      }
      const nota = h('p', {}, 'Motivos disponíveis: ' + MOTIVOS.join(', '));
      return h('article', { class: 'post-item caixa' }, h('p', { class: 'sobretitulo' }, d.estado || 'pendente'), motivo, detalhe, h('p', {}, alvo), nota, h('div', { class: 'acoes' }, acoes), feedback);
    }));
  }
  atualizar();
  return { titulo: 'Moderação', semIndexar: true, descricao: 'Fila privada de denúncias pendentes.', conteudo: paginaForm({ sobretitulo: 'Conta', titulo: 'Denúncias pendentes', lead: 'As denúncias são privadas. Registre somente ações necessárias e proporcionais.' }, status, lista, h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/conta' }, 'Voltar à conta'))) };
}
