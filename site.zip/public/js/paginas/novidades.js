// Página "Novidades": lista das atualizações, da mais nova para a mais antiga.

import { h } from '../dom.js';
import { listarNovidades } from '../dados-novidades.js';
import { formatarData } from '../formatar.js';
import { secao } from './_comum.js';

const NOMES_TAGS = { SS: 'Space Store', CS: 'Creator Space', Geral: 'Geral' };

export function etiquetas(tags) {
  const lista = Array.isArray(tags) ? tags.filter((t) => NOMES_TAGS[t]) : [];
  if (lista.length === 0) return null;
  return h('ul', { class: 'etiquetas', 'aria-label': 'Assuntos' }, lista.map((t) => h('li', { class: 'etiqueta' }, NOMES_TAGS[t])));
}

export function linhaMeta(novidade) {
  const partes = [formatarData(novidade.publicadoEm)];
  if (typeof novidade.versao === 'string' && novidade.versao) partes.push('Versão ' + novidade.versao);
  return partes.join(' · ');
}

function item(novidade) {
  return h(
    'article',
    { class: 'novidade-item' },
    h('p', { class: 'novidade-meta' }, linhaMeta(novidade)),
    h('h2', {}, h('a', { href: '/novidades/' + novidade.slug }, novidade.titulo)),
    novidade.resumo ? h('p', {}, novidade.resumo) : null,
    etiquetas(novidade.tags)
  );
}

function valida(novidade) {
  return novidade && typeof novidade.titulo === 'string' && novidade.titulo.length > 0;
}

export default async function novidades() {
  const lista = h('div', { class: 'novidades-lista' });
  const rodape = h('div', { class: 'novidades-rodape' });
  const aviso = h('div', { 'aria-live': 'polite' });

  let ultimo = null;
  let carregando = false;

  const botaoMais = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Ver novidades mais antigas');

  async function carregar() {
    if (carregando) return;
    carregando = true;
    botaoMais.disabled = true;
    aviso.replaceChildren();
    try {
      const pagina = await listarNovidades({ depoisDe: ultimo });
      lista.append(...pagina.itens.filter(valida).map(item));
      ultimo = pagina.ultimo;
      if (pagina.temMais) {
        rodape.replaceChildren(botaoMais);
      } else {
        rodape.replaceChildren();
      }
      if (lista.children.length === 0) {
        aviso.replaceChildren(
          h(
            'div',
            { class: 'caixa bloco' },
            h('h2', {}, 'Ainda não há novidades'),
            h('p', {}, 'Quando eu publicar a primeira atualização, ela aparece aqui.')
          )
        );
      }
    } catch (erro) {
      console.error('Não consegui ler as novidades', erro);
      aviso.replaceChildren(
        h(
          'div',
          { class: 'caixa bloco' },
          h('h2', {}, 'Não consegui carregar as novidades'),
          h('p', {}, 'Pode ser a conexão. Tente de novo em instantes.')
        )
      );
    } finally {
      carregando = false;
      botaoMais.disabled = false;
    }
  }

  botaoMais.addEventListener('click', carregar);
  await carregar();

  return {
    titulo: 'Novidades',
    descricao: 'Atualizações da Space Store, do Creator Space e do site, publicadas por Guilherme Lucena Gonçalves.',
    conteudo: h(
      'div',
      {},
      h(
        'section',
        { class: 'pagina-topo' },
        h(
          'div',
          { class: 'container' },
          h('p', { class: 'sobretitulo' }, 'Novidades'),
          h('h1', {}, 'O que mudou nos apps e no site'),
          h('p', { class: 'lead' }, 'Eu publico aqui cada atualização: o que melhorou, o que foi corrigido e o que vem por aí.')
        )
      ),
      secao({ rotulo: 'lista-novidades' }, h('h2', { id: 'lista-novidades', class: 'so-leitor' }, 'Lista de novidades'), lista, aviso, rodape)
    ),
  };
}
