// Página de novidades. A navegação não espera o Firestore; cada estado fica visível e acessível.

import { h } from '../dom.js';
import { listarNovidades, SLUG_VALIDO } from '../dados-novidades.js';
import { formatarData } from '../formatar.js';
import { secao } from './_comum.js';

const NOMES_TAGS = { SS: 'Space Store', CS: 'Creator Space', Geral: 'Geral' };

export function etiquetas(tags) {
  const lista = Array.isArray(tags) ? tags.filter((t) => NOMES_TAGS[t]) : [];
  if (lista.length === 0) return null;
  return h('ul', { class: 'etiquetas', 'aria-label': 'Assuntos' }, lista.map((t) => h('li', { class: 'etiqueta' }, NOMES_TAGS[t])));
}

export function linhaMeta(novidade) {
  const partes = [formatarData(novidade.publicadoEm)];
  if (typeof novidade.versao === 'string' && novidade.versao) partes.push('Versão ' + novidade.versao);
  return partes.join(' · ');
}

function item(novidade) {
  return h(
    'article',
    { class: 'novidade-item' },
    h('p', { class: 'novidade-meta' }, linhaMeta(novidade)),
    h('h2', {}, h('a', { href: '/novidades/' + novidade.slug }, novidade.titulo)),
    novidade.resumo ? h('p', {}, novidade.resumo) : null,
    etiquetas(novidade.tags)
  );
}

function valida(novidade) {
  return Boolean(
    novidade &&
    typeof novidade.slug === 'string' && SLUG_VALIDO.test(novidade.slug) &&
    typeof novidade.titulo === 'string' && novidade.titulo.trim().length > 0
  );
}

export default function novidades() {
  const lista = h('div', { class: 'novidades-lista' });
  const rodape = h('div', { class: 'novidades-rodape' });
  const aviso = h('div', { 'aria-live': 'polite', role: 'status' }, h('p', { class: 'suave' }, 'Carregando novidades…'));

  let ultimo = null;
  let carregando = false;
  const botaoMais = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Ver novidades mais antigas');

  async function carregar() {
    if (carregando) return;
    carregando = true;
    botaoMais.disabled = true;
    aviso.replaceChildren(h('p', { class: 'suave', role: 'status' }, ultimo ? 'Carregando mais novidades…' : 'Carregando novidades…'));
    try {
      const pagina = await listarNovidades({ depoisDe: ultimo });
      lista.append(...pagina.itens.filter(valida).map(item));
      ultimo = pagina.ultimo;
      if (pagina.temMais) rodape.replaceChildren(botaoMais);
      else rodape.replaceChildren();
      if (lista.children.length === 0) {
        aviso.replaceChildren(
          h(
            'div',
            { class: 'caixa bloco status-vazio' },
            h('h2', {}, 'Ainda não há novidades'),
            h('p', {}, 'Quando eu publicar a primeira atualização, ela aparece aqui.')
          )
        );
      } else {
        aviso.replaceChildren();
      }
    } catch (erro) {
      console.error('Não consegui ler as novidades', erro);
      const tentar = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Tentar novamente');
      tentar.addEventListener('click', carregar);
      aviso.replaceChildren(
        h(
          'div',
          { class: 'caixa bloco status-erro' },
          h('h2', {}, 'Não consegui carregar as novidades'),
          h('p', {}, 'Pode ser a conexão ou uma configuração do Firebase. Tente novamente; se o problema continuar, confira as regras e os índices.'),
          tentar
        )
      );
    } finally {
      carregando = false;
      botaoMais.disabled = false;
    }
  }

  botaoMais.addEventListener('click', carregar);
  void carregar();

  return {
    titulo: 'Novidades',
    descricao: 'Atualizações da Space Store, do Creator Space e do site, publicadas por Guilherme Lucena Gonçalves.',
    conteudo: h(
      'div',
      {},
      h(
        'section',
        { class: 'pagina-topo' },
        h(
          'div',
          { class: 'container' },
          h('p', { class: 'sobretitulo' }, 'Novidades'),
          h('h1', {}, 'O que mudou nos apps e no site'),
          h('p', { class: 'lead' }, 'Eu publico aqui cada atualização: o que melhorou, o que foi corrigido e o que vem por aí.')
        )
      ),
      secao({ rotulo: 'lista-novidades' }, h('h2', { id: 'lista-novidades', class: 'so-leitor' }, 'Lista de novidades'), lista, aviso, rodape)
    ),
  };
}
