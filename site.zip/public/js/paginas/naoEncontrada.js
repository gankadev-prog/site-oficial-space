// Página 404.

import { h } from '../dom.js';

export default function naoEncontrada() {
  return {
    titulo: 'Página não encontrada',
    semIndexar: true,
    conteudo: h(
      'section',
      { class: 'pagina-curta' },
      h(
        'div',
        { class: 'container' },
        h('p', { class: 'sobretitulo' }, 'Erro 404'),
        h('h1', {}, 'Essa página não existe, ou mudou de lugar'),
        h(
          'p',
          { class: 'lead' },
          'O endereço pode estar errado. Se você chegou aqui por um link meu, me avise em spacestorew@gmail.com que eu corrijo.'
        ),
        h(
          'p',
          { class: 'acoes' },
          h('a', { class: 'botao botao-primario', href: '/' }, 'Voltar ao início'),
          h('a', { class: 'botao botao-secundario', href: '/ecossistema' }, 'Ver o ecossistema')
        )
      )
    ),
  };
}
