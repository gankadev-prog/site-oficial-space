// Página "Quem faz": eu, em primeira pessoa.

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { secao } from './_comum.js';

function topo() {
  return h(
    'section',
    { class: 'pagina-topo' },
    h(
      'div',
      { class: 'container' },
      h('p', { class: 'sobretitulo' }, 'Sobre'),
      h('h1', {}, 'Quem faz'),
      h(
        'p',
        { class: 'lead' },
        'Eu sou Guilherme Lucena Gonçalves, desenvolvedor independente e brasileiro. Crio apps Android em Java.'
      )
    )
  );
}

function corpo() {
  return secao(
    { rotulo: 'titulo-historia', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h(
        'div',
        { class: 'foto-reservada', role: 'img', 'aria-label': 'Espaço reservado para a foto do Guilherme' },
        '[PREENCHER: foto]'
      )
    ),
    h(
      'div',
      { class: 'texto' },
      h('h2', { id: 'titulo-historia' }, 'Por que a Space Store existe'),
      h('p', {}, '[PREENCHER: a história real, em primeira pessoa. Como começou, o que você queria resolver, o que já aprendeu.]'),
      h('h2', {}, 'O que eu faço aqui'),
      h(
        'p',
        {},
        'A Space Store e o Creator Space são projetos meus. Eu desenvolvo os apps, confiro o que é publicado na loja e mantenho este site.'
      ),
      h('h2', {}, 'Responsável'),
      h('p', {}, 'Guilherme Lucena Gonçalves.'),
      h('p', {}, '[PREENCHER: CPF ou CNPJ e cidade/UF, que também entram nos documentos legais.]'),
      h('h2', {}, 'Falar comigo'),
      h(
        'p',
        {},
        h(
          'a',
          { class: 'link-seta', href: 'mailto:spacestorew@gmail.com' },
          icone('email', { tamanho: 18 }),
          'spacestorew@gmail.com'
        )
      )
    )
  );
}

export default function sobre() {
  return {
    titulo: 'Quem faz',
    descricao: 'Guilherme Lucena Gonçalves, desenvolvedor independente brasileiro por trás da Space Store e do Creator Space.',
    conteudo: h('div', {}, topo(), corpo()),
  };
}
