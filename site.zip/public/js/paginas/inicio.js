// Página inicial.

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { secao, linkSeta } from './_comum.js';
import { destacarPreencher } from '../preencher.js';

const DESCRICAO =
  'Space Store, loja de apps e jogos para Android, e Creator Space, painel para desenvolvedores. Downloads, novidades, comunidade e regras, por Guilherme Lucena Gonçalves.';

function hero() {
  const etapas = [
    ['01', 'Envio pelo Creator Space', 'O desenvolvedor envia o app e as informações da publicação.'],
    ['02', 'Verificação', 'VirusTotal e revisão do conteúdo antes da publicação.'],
    ['03', 'Space Store', 'O resultado da verificação fica visível na página do app.'],
  ];
  const painel = h(
    'aside',
    { class: 'hero-painel', 'aria-label': 'Resumo do fluxo de publicação' },
    h(
      'div',
      { class: 'hero-painel-cabecalho' },
      h('p', { class: 'hero-painel-marca' }, icone('escudo', { tamanho: 18 }), 'Como funciona'),
      h('span', { class: 'hero-painel-ordem' }, '3 etapas')
    ),
    h('ol', { class: 'hero-trilha' }, etapas.map(([numero, titulo, texto]) => h(
      'li',
      {},
      h('span', { class: 'hero-trilha-numero', 'aria-hidden': 'true' }, numero),
      h('div', {}, h('h2', {}, titulo), h('p', {}, texto))
    ))),
    h('p', { class: 'hero-painel-nota' }, 'A verificação ajuda a reduzir riscos; não é uma garantia de que um app nunca terá problemas.')
  );
  return h(
    'section',
    { class: 'hero' },
    h(
      'div',
      { class: 'container hero-grid' },
      h(
        'div',
        { class: 'hero-texto' },
        h('p', { class: 'sobretitulo' }, 'Space Store · Creator Space'),
        h('h1', {}, 'Apps Android feitos por uma pessoa e conferidos antes de chegar até você.'),
        h(
          'p',
          { class: 'lead' },
          'Eu sou o Guilherme. Mantenho uma loja de apps e jogos para Android, um painel para outros desenvolvedores publicarem nela, e eu confiro cada publicação antes de ela entrar na loja. Este site reúne os downloads, as novidades, a comunidade e as regras de tudo isso.'
        ),
        h(
          'p',
          { class: 'acoes' },
          h('a', { class: 'botao botao-primario', href: '/downloads' }, icone('download'), 'Ver downloads'),
          h('a', { class: 'botao botao-secundario', href: '/ecossistema' }, 'Como funciona')
        )
      ),
      painel
    )
  );
}

function parte(nome, texto, href, chamada) {
  return h('li', { class: 'linha' }, h('h3', {}, nome), h('p', {}, texto), linkSeta(href, chamada));
}

function partes() {
  return secao(
    { rotulo: 'titulo-partes', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h('h2', { id: 'titulo-partes' }, 'Os dois apps'),
      h('p', { class: 'suave' }, 'Cada um faz um trabalho diferente. Juntos, levam um app do desenvolvedor até o seu celular.')
    ),
    h(
      'ul',
      { class: 'linhas' },
      parte(
        'Space Store',
        'Loja de apps e jogos para Android. Cada app tem a própria página, com avaliações, desenvolvedor, informações sobre anúncios e compras e o resultado da verificação de segurança. Os perfis têm avatar, moldura, banner e @nick.',
        '/apps/space-store',
        'Conhecer a Space Store'
      ),
      parte(
        'Creator Space',
        'Painel para desenvolvedores enviarem e gerenciarem os próprios apps na Space Store.',
        '/apps/creator-space',
        'Conhecer o Creator Space'
      )
    )
  );
}

function passo(titulo, texto) {
  return h('li', {}, h('div', {}, h('h3', {}, titulo), h('p', {}, texto)));
}

function caminho() {
  return secao(
    { rotulo: 'titulo-caminho', colunas: true },
    h('div', { class: 'coluna-titulo' }, h('h2', { id: 'titulo-caminho' }, 'Como um app chega na loja')),
    h(
      'div',
      {},
      h(
        'ol',
        { class: 'passos' },
        passo('O desenvolvedor envia o app', 'Pelo Creator Space, com as informações do app.'),
        passo('Eu verifico', 'Análise de segurança com o VirusTotal e revisão do conteúdo.'),
        passo(
          'O app aparece na loja',
          'Se estiver tudo certo, ele entra na Space Store, com o resultado da verificação visível na página dele.'
        )
      ),
      linkSeta('/ecossistema', 'Ver o fluxo completo')
    )
  );
}

// Na etapa de Novidades, esta caixa passa a mostrar o último post do Firestore.
function novidade() {
  const texto = h('p', { role: 'status', 'aria-live': 'polite' }, 'Carregando a novidade mais recente…');
  const caixa = h('div', { class: 'caixa novidade-destaque' }, texto, linkSeta('/novidades', 'Ver todas as novidades'));

  // A última novidade chega depois, para a página inicial abrir sem esperar o banco.
  import('../dados-novidades.js')
    .then((modulo) => modulo.listarNovidades({ quantidade: 1 }))
    .then((pagina) => {
      const ultima = pagina.itens[0];
      if (!ultima || typeof ultima.titulo !== 'string' || !ultima.titulo.trim()) {
        texto.textContent = 'Ainda não há novidades publicadas. Quando eu publicar a primeira, ela aparece aqui.';
        return;
      }
      const partes = [];
      if (ultima.publicadoEm && typeof ultima.publicadoEm.toDate === 'function') {
        partes.push(
          ultima.publicadoEm.toDate().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })
        );
      }
      if (typeof ultima.versao === 'string' && ultima.versao) partes.push('Versão ' + ultima.versao);
      caixa.replaceChildren(
        partes.length ? h('p', { class: 'suave' }, partes.join(' · ')) : null,
        h('h3', {}, h('a', { href: '/novidades/' + ultima.slug }, ultima.titulo)),
        ultima.resumo ? h('p', {}, ultima.resumo) : null,
        linkSeta('/novidades', 'Ver todas as novidades')
      );
    })
    .catch((erro) => {
      console.error('Última novidade', erro);
      texto.textContent = 'Não consegui carregar a novidade agora. Você pode tentar novamente na página de novidades.';
    });

  return secao(
    { rotulo: 'titulo-novidade', colunas: true },
    h('div', { class: 'coluna-titulo' }, h('h2', { id: 'titulo-novidade' }, 'Última novidade')),
    caixa
  );
}

function quemFaz() {
  return secao(
    { rotulo: 'titulo-quem-faz', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h(
        'div',
        { class: 'foto-reservada', role: 'img', 'aria-label': 'Espaço reservado para a foto do Guilherme' },
        destacarPreencher('[PREENCHER: foto]')
      )
    ),
    h(
      'div',
      { class: 'texto' },
      h('h2', { id: 'titulo-quem-faz' }, 'Quem faz'),
      h(
        'p',
        {},
        'Meu nome é Guilherme Lucena Gonçalves. Sou desenvolvedor independente, brasileiro, e crio apps Android em Java.'
      ),
      h('p', {}, destacarPreencher('[PREENCHER: a história real de como a Space Store começou, em três ou quatro frases.]')),
      linkSeta('/sobre', 'Mais sobre mim')
    )
  );
}

export default function inicio() {
  return {
    titulo: null,
    descricao: DESCRICAO,
    jsonld: {
      '@context': 'https://schema.org',
      '@graph': [
        { '@type': 'Organization', name: 'Space Store · Creator Space', url: 'https://space-store-creator-space-web.web.app/', email: 'spacestorew@gmail.com', founder: { '@type': 'Person', name: 'Guilherme Lucena Gonçalves' } },
        { '@type': 'WebSite', name: 'Space Store · Creator Space', url: 'https://space-store-creator-space-web.web.app/', inLanguage: 'pt-BR' },
      ],
    },
    conteudo: h('div', {}, hero(), partes(), caminho(), novidade(), quemFaz()),
  };
}
