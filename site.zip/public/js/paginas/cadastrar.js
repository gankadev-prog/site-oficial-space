// Página "Criar conta". Também serve para completar o cadastro de quem entrou com o Google
// e ainda não escolheu @nick nem informou a data de nascimento.

import { h } from '../dom.js';
import { navegar } from '../roteador.js';
import {
  esperarAuth,
  estadoAuth,
  cadastrarComEmail,
  entrarComGoogle,
  criarPerfil,
  nickEmUso,
  validarNick,
} from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { IDADE_MINIMA, IDADE_RESPONSAVEL, SENHA_MINIMA } from '../config.js';
import { hojeISO, validarNascimento } from '../idade.js';
import { campo, caixaMarcar, areaAlerta, botaoEnvio, ocupar, focarPrimeiroErro, EMAIL_REGEX } from './_forms.js';
import { paginaForm, redirecionar, destinoSeguro } from './_comum.js';

function linkNovaAba(href, texto) {
  return h('a', { href, target: '_blank', rel: 'noopener noreferrer' }, texto);
}

export default async function cadastrar() {
  const estado = await esperarAuth();
  const voltar = destinoSeguro(new URLSearchParams(window.location.search).get('voltar'));

  if (estado.usuario && estado.perfil) return redirecionar(voltar || '/conta');

  if (estado.erroPerfil) {
    return {
      titulo: 'Cadastro',
      semIndexar: true,
      conteudo: paginaForm(
        {
          titulo: 'Não consegui carregar seus dados',
          lead: 'Pode ser a conexão. Recarregue a página para tentar de novo.',
        },
        h(
          'p',
          { class: 'acoes' },
          h(
            'button',
            { type: 'button', class: 'botao botao-primario', onclick: () => window.location.reload() },
            'Recarregar'
          )
        )
      ),
    };
  }

  const completando = Boolean(estado.usuario);

  const alerta = areaAlerta();
  const nome = campo({
    id: 'nome',
    rotulo: 'Nome',
    autocompletar: 'name',
    maximo: 50,
    valor: completando ? (estado.usuario.displayName || '').slice(0, 50) : '',
    ajuda: 'Como você quer aparecer. Até 50 letras.',
  });
  const nick = campo({
    id: 'nick',
    rotulo: '@nick',
    autocompletar: 'username',
    maximo: 21,
    ajuda: 'De 3 a 20 caracteres: letras minúsculas, números e _. Depois de criado, não dá para trocar.',
    extras: { autocapitalize: 'none', spellcheck: 'false' },
  });
  const email = campo({
    id: 'email',
    rotulo: 'E-mail',
    tipo: 'email',
    autocompletar: 'email',
    extras: { autocapitalize: 'none', spellcheck: 'false', inputmode: 'email' },
  });
  const senha = campo({
    id: 'senha',
    rotulo: 'Senha',
    tipo: 'password',
    autocompletar: 'new-password',
    ajuda: `Pelo menos ${SENHA_MINIMA} caracteres.`,
  });
  const nascimento = campo({
    id: 'nascimento',
    rotulo: 'Data de nascimento',
    tipo: 'date',
    autocompletar: 'bday',
    ajuda: `Serve só para conferir a idade mínima (${IDADE_MINIMA} anos). Não aparece no seu perfil.`,
    extras: { min: '1900-01-01', max: hojeISO() },
  });
  const responsavel = caixaMarcar({
    id: 'responsavel',
    rotulo: 'Tenho menos de 18 anos e meu pai, minha mãe ou meu responsável legal sabe e concorda que eu crie esta conta.',
  });
  responsavel.el.hidden = true;
  const aceite = caixaMarcar({
    id: 'aceite',
    rotulo: [
      'Li e aceito os ',
      linkNovaAba('/docs#termos', 'Termos de Uso'),
      ' e a ',
      linkNovaAba('/docs#privacidade', 'Política de Privacidade'),
      '.',
    ],
  });

  const botao = botaoEnvio(completando ? 'Concluir cadastro' : 'Criar conta');

  function atualizarResponsavel() {
    const resultado = validarNascimento(nascimento.valor());
    const menor = resultado.ok && resultado.idade >= IDADE_MINIMA && resultado.idade < IDADE_RESPONSAVEL;
    responsavel.el.hidden = !menor;
    if (!menor) {
      responsavel.entrada.checked = false;
      responsavel.limpar();
    }
  }
  nascimento.entrada.addEventListener('input', atualizarResponsavel);
  nascimento.entrada.addEventListener('change', atualizarResponsavel);

  let removerCamposDeLogin = () => {};

  async function enviar(evento) {
    evento.preventDefault();
    alerta.limpar();
    const todos = [nome, nick, email, senha, nascimento, responsavel, aceite];
    todos.forEach((c) => c.limpar());

    const valorNome = nome.valor().trim().replace(/\s+/g, ' ');
    const valorNick = nick.valor().trim().replace(/^@/, '').toLowerCase();
    const valorEmail = email.valor().trim();
    const valorSenha = senha.valor();
    const valorNascimento = nascimento.valor();
    const precisaLogin = !estadoAuth().usuario;

    if (!valorNome) nome.erro('Digite seu nome.');
    else if (valorNome.length > 50) nome.erro('O nome pode ter no máximo 50 letras.');

    const erroNick = validarNick(valorNick);
    if (erroNick) nick.erro(erroNick);

    if (precisaLogin) {
      if (!valorEmail) email.erro('Digite seu e-mail.');
      else if (!EMAIL_REGEX.test(valorEmail)) email.erro('Esse e-mail não parece certo. Confira se tem @ e o final, como .com.');
      if (valorSenha.length < SENHA_MINIMA) senha.erro(`A senha precisa ter pelo menos ${SENHA_MINIMA} caracteres.`);
    }

    const nasc = validarNascimento(valorNascimento);
    if (!nasc.ok) nascimento.erro(nasc.erro);

    if (nasc.ok && nasc.idade >= IDADE_MINIMA && nasc.idade < IDADE_RESPONSAVEL && !responsavel.marcado()) {
      responsavel.erro('Marque aqui para confirmar que o responsável concorda.');
    }
    if (!aceite.marcado()) aceite.erro('Para criar a conta, você precisa aceitar os Termos e a Política de Privacidade.');

    if (nasc.ok && nasc.idade < IDADE_MINIMA) {
      alerta.erro(
        `Para criar uma conta neste site é preciso ter pelo menos ${IDADE_MINIMA} anos. Você ainda pode navegar pelo site sem conta.`
      );
      nascimento.entrada.focus();
      return;
    }

    if (todos.some((c) => c.entrada.getAttribute('aria-invalid') === 'true')) {
      focarPrimeiroErro(todos);
      return;
    }

    ocupar(botao, true, completando ? 'Salvando…' : 'Criando conta…');
    let contaCriadaAgora = false;
    try {
      if (await nickEmUso(valorNick)) {
        nick.erro('Esse @nick já está em uso. Escolha outro.');
        nick.entrada.focus();
        return;
      }
      if (precisaLogin) {
        await cadastrarComEmail(valorEmail, valorSenha);
        contaCriadaAgora = true;
      }
      await criarPerfil({
        nome: valorNome,
        nick: valorNick,
        nascimento: valorNascimento,
        consentimentoResponsavel: responsavel.marcado(),
      });
      navegar(voltar || '/conta');
    } catch (erro) {
      if (erro && erro.code === 'auth/email-already-in-use') {
        email.erro('Esse e-mail já tem uma conta. Tente entrar ou recuperar a senha.');
        email.entrada.focus();
      } else if (contaCriadaAgora || estadoAuth().usuario) {
        // A conta de login existe, mas o perfil não foi salvo. A pessoa só completa o que falta.
        removerCamposDeLogin();
        botao.dataset.texto = 'Concluir cadastro';
        alerta.erro(
          'Sua conta foi criada, mas não consegui salvar o perfil. ' + mensagemDeErro(erro) + ' Ajuste o que for preciso e toque em Concluir cadastro.'
        );
      } else {
        alerta.erro(mensagemDeErro(erro));
      }
    } finally {
      ocupar(botao, false);
    }
  }

  removerCamposDeLogin = () => {
    email.el.remove();
    senha.el.remove();
  };

  const formulario = h(
    'form',
    { class: 'form', novalidate: true, onsubmit: enviar },
    alerta.el,
    nome.el,
    nick.el,
    completando ? null : email.el,
    completando ? null : senha.el,
    nascimento.el,
    responsavel.el,
    aceite.el,
    h('div', { class: 'acoes' }, botao)
  );

  const botaoGoogle = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Continuar com o Google');
  botaoGoogle.addEventListener('click', async () => {
    alerta.limpar();
    botaoGoogle.disabled = true;
    try {
      const novo = await entrarComGoogle();
      // Se a conta Google já tem perfil, vai para a conta; senão, a página recarrega no modo "completar".
      navegar(novo.perfil ? voltar || '/conta' : '/cadastrar', { substituir: !novo.perfil });
    } catch (erro) {
      alerta.erro(mensagemDeErro(erro));
    } finally {
      botaoGoogle.disabled = false;
    }
  });

  return {
    titulo: completando ? 'Concluir cadastro' : 'Criar conta',
    semIndexar: true,
    descricao: 'Crie sua conta para participar da comunidade da Space Store e do Creator Space.',
    conteudo: paginaForm(
      {
        sobretitulo: 'Conta',
        titulo: completando ? 'Complete seu cadastro' : 'Criar conta',
        lead: completando
          ? 'Você entrou com o Google. Falta escolher seu @nick e confirmar alguns dados.'
          : 'Com conta, você poderá comentar, avaliar e participar da comunidade.',
      },
      completando ? null : h('div', { class: 'form' }, botaoGoogle),
      completando ? null : h('p', { class: 'separador' }, 'ou crie com e-mail e senha'),
      formulario,
      completando
        ? null
        : h('p', { class: 'form-rodape' }, 'Já tem conta? ', h('a', { href: '/entrar' }, 'Entrar'))
    ),
  };
}
