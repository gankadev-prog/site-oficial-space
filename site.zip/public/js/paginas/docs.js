// Documentação e políticas, numa página só. Os textos ficam em docs-conteudo.js.

import { h } from '../dom.js';
import { DOCUMENTOS, VERSAO_DOCUMENTOS, REVISADO_POR_ADVOGADO } from '../docs-conteudo.js';

const MARCA = /(\[PREENCHER:[^\]]*\])/g;

// Texto com os "[PREENCHER: ...]" destacados. Com o grupo na expressão, os trechos
// que combinam ficam nas posições ímpares da lista.
function texto(valor) {
  return String(valor)
    .split(MARCA)
    .map((parte, i) => (i % 2 === 1 ? h('mark', { class: 'preencher' }, parte) : parte));
}

function bloco(item) {
  if (typeof item === 'string') return h('p', {}, ...texto(item));
  if (item && Array.isArray(item.lista)) return h('ul', {}, item.lista.map((l) => h('li', {}, ...texto(l))));
  if (item && item.tabela) {
    const { cab, linhas } = item.tabela;
    return h(
      'div',
      { class: 'tabela-rolavel', role: 'region', tabindex: '0', 'aria-label': 'Tabela, role para o lado se precisar' },
      h(
        'table',
        { class: 'tabela-doc' },
        h('thead', {}, h('tr', {}, cab.map((c) => h('th', { scope: 'col' }, c)))),
        h('tbody', {}, linhas.map((linha) => h('tr', {}, linha.map((c) => h('td', {}, ...texto(c))))))
      )
    );
  }
  return null;
}

function documento(doc) {
  return h(
    'section',
    { class: 'doc', 'aria-labelledby': doc.id },
    h('h2', { id: doc.id }, doc.titulo),
    h('p', { class: 'suave' }, doc.resumo),
    doc.secoes.map((s, i) => [
      h('h3', {}, `${i + 1}. ${s.titulo}`),
      s.blocos.map(bloco),
    ]),
    h('p', {}, h('a', { class: 'link-seta', href: '#indice-docs' }, 'Voltar ao índice'))
  );
}

function avisoMinuta() {
  if (REVISADO_POR_ADVOGADO) return null;
  return h(
    'div',
    { class: 'caixa aviso-minuta', role: 'note' },
    h('strong', {}, 'Texto em revisão. '),
    'Estes documentos ainda estão sendo revisados e podem mudar. Os trechos destacados serão completados antes da abertura pública.'
  );
}

export default function docs() {
  return {
    titulo: 'Documentação e políticas',
    descricao:
      'Termos de Uso, Política de Privacidade, Cookies, Diretrizes da Comunidade e Segurança da Space Store e do Creator Space.',
    conteudo: h(
      'div',
      {},
      h(
        'section',
        { class: 'pagina-topo' },
        h(
          'div',
          { class: 'container' },
          h('p', { class: 'sobretitulo' }, 'Documentação'),
          h('h1', {}, 'Regras, privacidade e segurança'),
          h(
            'p',
            { class: 'lead' },
            'Tudo o que você precisa saber para usar o site e os apps, em linguagem direta. Versão ' + VERSAO_DOCUMENTOS + '.'
          ),
          avisoMinuta()
        )
      ),
      h(
        'div',
        { class: 'container docs-layout' },
        h(
          'nav',
          { class: 'docs-indice', id: 'indice-docs', 'aria-label': 'Índice dos documentos' },
          h('p', { class: 'rodape-titulo' }, 'Nesta página'),
          h('ul', {}, DOCUMENTOS.map((d) => h('li', {}, h('a', { href: '#' + d.id }, d.titulo))))
        ),
        h('div', { class: 'docs-corpo' }, DOCUMENTOS.map(documento))
      )
    ),
  };
}
