// Página "Entrar": e-mail e senha, ou Google.

import { h } from '../dom.js';
import { navegar } from '../roteador.js';
import { esperarAuth, entrarComEmail, entrarComGoogle } from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { campo, areaAlerta, botaoEnvio, ocupar, focarPrimeiroErro, EMAIL_REGEX } from './_forms.js';
import { paginaForm, redirecionar, destinoSeguro, sufixoVoltar } from './_comum.js';

export default async function entrar() {
  const estado = await esperarAuth();
  const voltar = destinoSeguro(new URLSearchParams(window.location.search).get('voltar'));
  const sufixo = sufixoVoltar(voltar);

  if (estado.usuario && estado.perfil) return redirecionar(voltar || '/conta');
  if (estado.usuario && !estado.erroPerfil) return redirecionar('/cadastrar' + sufixo);

  const alerta = areaAlerta();
  const email = campo({
    id: 'email',
    rotulo: 'E-mail',
    tipo: 'email',
    autocompletar: 'email',
    extras: { autocapitalize: 'none', spellcheck: 'false', inputmode: 'email' },
  });
  const senha = campo({ id: 'senha', rotulo: 'Senha', tipo: 'password', autocompletar: 'current-password' });
  const botao = botaoEnvio('Entrar');
  const botaoGoogle = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Entrar com o Google');

  function depoisDoLogin(novoEstado) {
    if (novoEstado.perfil) {
      navegar(voltar || '/conta');
    } else {
      navegar('/cadastrar' + sufixo);
    }
  }

  async function enviar(evento) {
    evento.preventDefault();
    alerta.limpar();
    email.limpar();
    senha.limpar();

    const valorEmail = email.valor().trim();
    const valorSenha = senha.valor();

    if (!valorEmail) {
      email.erro('Digite seu e-mail.');
    } else if (!EMAIL_REGEX.test(valorEmail)) {
      email.erro('Esse e-mail não parece certo. Confira se tem @ e o final, como .com.');
    }
    if (!valorSenha) senha.erro('Digite sua senha.');

    if (email.entrada.getAttribute('aria-invalid') || senha.entrada.getAttribute('aria-invalid')) {
      focarPrimeiroErro([email, senha]);
      return;
    }

    ocupar(botao, true, 'Entrando…');
    try {
      depoisDoLogin(await entrarComEmail(valorEmail, valorSenha));
    } catch (erro) {
      alerta.erro(mensagemDeErro(erro));
    } finally {
      ocupar(botao, false);
    }
  }

  botaoGoogle.addEventListener('click', async () => {
    alerta.limpar();
    botaoGoogle.disabled = true;
    try {
      depoisDoLogin(await entrarComGoogle());
    } catch (erro) {
      alerta.erro(mensagemDeErro(erro));
    } finally {
      botaoGoogle.disabled = false;
    }
  });

  const formulario = h(
    'form',
    { class: 'form', novalidate: true, onsubmit: enviar },
    alerta.el,
    email.el,
    senha.el,
    h('div', { class: 'acoes' }, botao)
  );

  return {
    titulo: 'Entrar',
    semIndexar: true,
    descricao: 'Entre na sua conta da Space Store e do Creator Space.',
    conteudo: paginaForm(
      { sobretitulo: 'Conta', titulo: 'Entrar' },
      formulario,
      h('p', { class: 'separador' }, 'ou'),
      h('div', { class: 'form' }, botaoGoogle),
      h(
        'p',
        { class: 'form-rodape' },
        h('a', { href: '/esqueci-senha' }, 'Esqueci minha senha'),
        ' · Não tem conta? ',
        h('a', { href: '/cadastrar' + sufixo }, 'Criar conta')
      )
    ),
  };
}
