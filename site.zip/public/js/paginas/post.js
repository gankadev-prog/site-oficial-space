import { h } from '../dom.js';
import { esperarAuth } from '../auth.js';
import { formatarData } from '../formatar.js';
import { renderizarCorpo } from '../markup.js';
import { mensagemDeErro } from '../erros.js';
import { obterPost, listarComentarios, alternarCurtida, usuarioCurtiu, criarComentario, apagarComentario, editarPost, apagarPost, verificarModeracao, moderarAlvo, CATEGORIAS } from '../dados-comunidade.js';
import { paginaForm } from './_comum.js';
import { formularioDenuncia } from '../denuncia-ui.js';

function midiaItem(item) {
  return item.tipo === 'video'
    ? h('video', { controls: true, preload: 'metadata', src: item.url, 'aria-label': 'Vídeo da publicação' })
    : h('img', { src: item.url, loading: 'lazy', alt: 'Imagem da publicação' });
}

export default async function post({ params }) {
  const id = params.id;
  let item;
  try { item = await obterPost(id); }
  catch (erro) {
    const removida = erro?.code === 'permission-denied';
    return { titulo: removida ? 'Publicação removida' : 'Publicação', semIndexar: true, conteudo: paginaForm({ titulo: removida ? 'Publicação removida' : 'Não consegui carregar esta publicação', lead: removida ? 'Removido pela moderação.' : mensagemDeErro(erro) }, h('a', { href: '/comunidade' }, 'Voltar à comunidade')) };
  }
  if (!item) return { titulo: 'Publicação não encontrada', semIndexar: true, conteudo: paginaForm({ titulo: 'Não encontrei esta publicação', lead: 'Ela pode ter sido removida ou o endereço está incorreto.' }, h('a', { href: '/comunidade' }, 'Voltar à comunidade')) };
  const estado = await esperarAuth();
  const pessoa = estado.usuario && estado.perfil;
  const dono = Boolean(pessoa && item.autorUid === estado.usuario.uid);
  const equipe = Boolean(estado.usuario && await verificarModeracao(estado.usuario.uid).catch(() => false));
  const ocultoPrivado = item.oculto === true && !dono && !equipe;
  if (ocultoPrivado) return { titulo: 'Publicação removida', semIndexar: true, conteudo: paginaForm({ titulo: 'Publicação removida', lead: 'Removido pela moderação.' }, h('a', { href: '/comunidade' }, 'Voltar à comunidade')) };

  const aviso = h('p', { role: 'status', 'aria-live': 'polite' });
  const btnLike = h('button', { type: 'button', class: 'botao botao-secundario' }, `${Number(item.curtidas) || 0} curtidas`);
  if (pessoa && estado.usuario.emailVerified && item.oculto !== true) {
    usuarioCurtiu(id, estado.usuario.uid).then((sim) => { btnLike.textContent = `${sim ? 'Curtido' : 'Curtir'} · ${Number(item.curtidas) || 0}`; }).catch(() => {});
    btnLike.addEventListener('click', async () => { btnLike.disabled = true; try { const gostou = await alternarCurtida(id); btnLike.textContent = `${gostou ? 'Curtido' : 'Curtir'} · ${Math.max(0, (Number(item.curtidas) || 0) + (gostou ? 1 : -1))}`; item.curtidas = Math.max(0, (Number(item.curtidas) || 0) + (gostou ? 1 : -1)); } catch (e) { aviso.textContent = mensagemDeErro(e); } finally { btnLike.disabled = false; } });
  } else btnLike.disabled = true;
  const compartilhar = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Compartilhar');
  compartilhar.addEventListener('click', async () => { const url = window.location.href; try { if (navigator.share) await navigator.share({ title: item.titulo, url }); else { await navigator.clipboard.writeText(url); aviso.textContent = 'Link copiado.'; } } catch { aviso.textContent = 'Não consegui compartilhar agora. Você pode copiar o endereço do navegador.'; } });

  const comentarioStatus = h('p', { role: 'status', 'aria-live': 'polite' });
  const comentarioLista = h('ol', { class: 'comentarios' });
  let cursorComentarios = null;
  let temMais = false;
  async function carregarComentarios(mais = false) {
    try {
      const resultado = await listarComentarios(id, mais ? cursorComentarios : null);
      cursorComentarios = resultado.cursor; temMais = resultado.temMais;
      const nos = resultado.itens.map((c) => {
        const linha = h('li', {}, h('p', {}, h('a', { href: '/u/' + encodeURIComponent(c.autorNick || '') }, `${c.autorNome || 'Pessoa'} · @${c.autorNick || '—'}`), ' · ', formatarData(c.criadoEm)), h('p', {}, c.texto));
        if (pessoa && (c.autorUid === estado.usuario.uid || equipe)) {
          const apagar = h('button', { type: 'button', class: 'link-discreto' }, 'Apagar comentário');
          apagar.addEventListener('click', async () => { apagar.disabled = true; try { await apagarComentario(id, c.id); linha.remove(); } catch (err) { comentarioStatus.textContent = mensagemDeErro(err); apagar.disabled = false; } });
          linha.append(apagar);
        } else if (pessoa && estado.usuario.emailVerified && estado.perfil.suspenso !== true) {
          linha.append(formularioDenuncia('comentario', `${id}:${c.id}`, 'Denunciar comentário'));
        }
        return linha;
      });
      comentarioLista.append(...nos); comentarioStatus.textContent = comentarioLista.children.length ? `${comentarioLista.children.length} comentários carregados.` : 'Ainda não há comentários.'; btnMais.hidden = !temMais;
    } catch (e) { comentarioStatus.textContent = `Não consegui carregar os comentários. ${mensagemDeErro(e)}`; }
  }
  const btnMais = h('button', { type: 'button', class: 'botao botao-secundario', hidden: true }, 'Carregar mais comentários');
  btnMais.addEventListener('click', () => carregarComentarios(true));
  await carregarComentarios();

  let formComentario = null;
  if (pessoa && estado.usuario.emailVerified && !item.oculto) {
    const textoComentario = h('textarea', { id: 'comentario-texto', maxlength: '1000', rows: '3', required: true });
    const enviar = h('button', { type: 'submit', class: 'botao botao-primario' }, 'Comentar');
    formComentario = h('form', { class: 'form', onsubmit: async (e) => { e.preventDefault(); enviar.disabled = true; try { await criarComentario(id, textoComentario.value); textoComentario.value = ''; comentarioLista.replaceChildren(); cursorComentarios = null; await carregarComentarios(); } catch (err) { comentarioStatus.textContent = mensagemDeErro(err); } finally { enviar.disabled = false; } } }, h('div', { class: 'campo' }, h('label', { for: 'comentario-texto' }, 'Seu comentário'), textoComentario), h('div', { class: 'acoes' }, enviar));
  } else if (!estado.usuario) formComentario = h('p', {}, 'Entre para comentar. ', h('a', { href: '/entrar?voltar=' + encodeURIComponent(window.location.pathname) }, 'Entrar'));

  let formEdicao = null;
  if (dono && !item.oculto) {
    const titulo = h('input', { id: 'editar-titulo', maxlength: '120', value: item.titulo || '' });
    const texto = h('textarea', { id: 'editar-texto', maxlength: '5000', rows: '6' }); texto.value = item.texto || '';
    const categoria = h('select', { id: 'editar-categoria' }, CATEGORIAS.map((c) => h('option', { value: c, selected: item.categoria === c }, c)));
    const mensagem = h('p', { role: 'status', 'aria-live': 'polite' });
    formEdicao = h('details', {}, h('summary', {}, 'Editar publicação (até 15 minutos após publicar)'), h('form', { class: 'form', onsubmit: async (e) => { e.preventDefault(); try { await editarPost(id, { titulo: titulo.value, texto: texto.value, categoria: categoria.value }); mensagem.textContent = 'Publicação atualizada.'; window.location.reload(); } catch (err) { mensagem.textContent = mensagemDeErro(err); } } }, h('div', { class: 'campo' }, h('label', { for: 'editar-titulo' }, 'Título'), titulo), h('div', { class: 'campo' }, h('label', { for: 'editar-texto' }, 'Texto'), texto), h('div', { class: 'campo' }, h('label', { for: 'editar-categoria' }, 'Categoria'), categoria), mensagem, h('button', { class: 'botao botao-secundario', type: 'submit' }, 'Salvar edição')));
    const apagar = h('button', { type: 'button', class: 'botao botao-perigo' }, 'Apagar publicação'); apagar.addEventListener('click', async () => { if (!window.confirm('Apagar esta publicação? Esta ação não pode ser desfeita.')) return; try { await apagarPost(id); window.location.assign('/comunidade'); } catch (err) { aviso.textContent = mensagemDeErro(err); } });
    formEdicao.append(apagar);
  }

  const denunciaForm = pessoa && estado.usuario.emailVerified && estado.perfil.suspenso !== true && !dono
    ? formularioDenuncia('post', id, 'Denunciar publicação') : null;
  const modArea = equipe ? h('div', { class: 'acoes' }, h('button', { type: 'button', class: 'botao botao-secundario', onclick: async () => { try { await moderarAlvo({ alvoTipo: 'post', alvoId: id, acao: 'ocultar', motivo: 'Revisão da comunidade' }); window.location.reload(); } catch (e) { aviso.textContent = mensagemDeErro(e); } } }, 'Ocultar'), h('button', { type: 'button', class: 'botao botao-perigo', onclick: async () => { if (!window.confirm('Remover esta publicação?')) return; try { await moderarAlvo({ alvoTipo: 'post', alvoId: id, acao: 'remover', motivo: 'Removida após revisão' }); window.location.assign('/comunidade'); } catch (e) { aviso.textContent = mensagemDeErro(e); } } }, 'Remover')) : null;

  return { titulo: item.titulo || 'Publicação', semIndexar: Boolean(item.oculto), descricao: 'Publicação da comunidade Space.', conteudo: h('div', {}, h('section', { class: 'pagina-topo' }, h('div', { class: 'container texto' }, item.oculto ? h('p', { class: 'aviso-minuta' }, 'Prévia de revisão') : null, h('p', { class: 'sobretitulo' }, item.categoria || 'Comunidade'), h('h1', {}, item.titulo || 'Publicação'), h('p', {}, h('a', { href: '/u/' + encodeURIComponent(item.autorNick || '') }, `${item.autorNome || 'Pessoa'} · @${item.autorNick || '—'}`), ' · ', formatarData(item.criadoEm), item.editadoEm ? ' · editado' : ''), ...renderizarCorpo(item.texto || '', { permitirImagens: false }).nos, item.midia?.length ? h('div', { class: 'post-midia' }, item.midia.map(midiaItem)) : null, h('div', { class: 'post-acoes' }, btnLike, compartilhar), aviso, formEdicao, denunciaForm, modArea)), h('section', { class: 'secao' }, h('div', { class: 'container' }, h('h2', {}, 'Comentários'), comentarioStatus, comentarioLista, btnMais, formComentario))) };
}
