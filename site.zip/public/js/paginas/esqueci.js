// Página "Esqueci minha senha".

import { h } from '../dom.js';
import { recuperarSenha } from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { campo, areaAlerta, botaoEnvio, ocupar, EMAIL_REGEX } from './_forms.js';
import { paginaForm } from './_comum.js';

export default function esqueci() {
  const alerta = areaAlerta();
  const email = campo({
    id: 'email',
    rotulo: 'E-mail da conta',
    tipo: 'email',
    autocompletar: 'email',
    extras: { autocapitalize: 'none', spellcheck: 'false', inputmode: 'email' },
  });
  const botao = botaoEnvio('Enviar link');

  async function enviar(evento) {
    evento.preventDefault();
    alerta.limpar();
    email.limpar();

    const valor = email.valor().trim();
    if (!EMAIL_REGEX.test(valor)) {
      email.erro('Digite o e-mail da sua conta, como nome@exemplo.com.');
      email.entrada.focus();
      return;
    }

    ocupar(botao, true, 'Enviando…');
    try {
      await recuperarSenha(valor);
      alerta.ok('Se existir uma conta com esse e-mail, enviei um link para criar uma senha nova. Confira também a caixa de spam.');
    } catch (erro) {
      // Não revela se o e-mail tem conta ou não.
      if (erro && erro.code === 'auth/user-not-found') {
        alerta.ok('Se existir uma conta com esse e-mail, enviei um link para criar uma senha nova. Confira também a caixa de spam.');
      } else {
        alerta.erro(mensagemDeErro(erro));
      }
    } finally {
      ocupar(botao, false);
    }
  }

  return {
    titulo: 'Recuperar senha',
    semIndexar: true,
    descricao: 'Peça um link para criar uma senha nova.',
    conteudo: paginaForm(
      {
        sobretitulo: 'Conta',
        titulo: 'Recuperar senha',
        lead: 'Digite o e-mail da sua conta. Eu envio um link para você criar uma senha nova.',
      },
      h(
        'form',
        { class: 'form', novalidate: true, onsubmit: enviar },
        alerta.el,
        email.el,
        h('div', { class: 'acoes' }, botao)
      ),
      h('p', { class: 'form-rodape' }, h('a', { href: '/entrar' }, 'Voltar para entrar'))
    ),
  };
}
