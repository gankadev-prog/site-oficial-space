// Como instalar e como conferir o arquivo. Aparece em Downloads e na página de cada app.
// Os apps não estão na Google Play, e isso é dito sem esconder nem assustar.

import { h } from '../dom.js';
import { secao } from './_comum.js';

function passo(titulo, ...texto) {
  return h('li', {}, h('div', {}, h('h3', {}, titulo), h('p', {}, ...texto)));
}

export function secaoInstalacao() {
  return secao(
    { rotulo: 'como-instalar', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h('h2', { id: 'como-instalar' }, 'Como instalar'),
      h(
        'p',
        { class: 'suave' },
        'Estes apps não estão na Google Play. Você baixa o arquivo (.apk) aqui e instala pelo próprio Android.'
      )
    ),
    h(
      'div',
      {},
      h(
        'ol',
        { class: 'passos' },
        passo('Baixe o arquivo', 'Toque em Baixar na ficha do app. O arquivo vai para a pasta de downloads do aparelho.'),
        passo(
          'Libere a instalação',
          'Ao abrir o arquivo, o Android pode avisar que o navegador não pode instalar apps desconhecidos. Toque em Configurações e ative a opção para essa fonte. Depois da instalação você pode desligá-la de novo.'
        ),
        passo(
          'Entenda o aviso do Play Protect',
          'O Play Protect pode mostrar um aviso por o app não vir da Google Play. Isso acontece com qualquer app de fora da loja e não quer dizer que encontrei um problema. Se ele disser que detectou algo perigoso, não instale e me avise em spacestorew@gmail.com.'
        ),
        passo('Instale', 'Toque em Instalar e espere terminar.')
      ),
      h('h3', { class: 'subtitulo' }, 'Como conferir o arquivo'),
      h(
        'p',
        {},
        'Cada versão tem um código chamado hash SHA-256, que funciona como a impressão digital do arquivo. Use um app de sua confiança que calcule o SHA-256 de um arquivo e compare com o código da página do app. Se forem iguais, o arquivo é idêntico ao que eu publiquei. Se forem diferentes, apague o arquivo e baixe de novo.'
      )
    )
  );
}
