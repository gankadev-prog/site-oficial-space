// Página "Downloads": uma ficha para cada app publicado.

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { listarApps } from '../dados-apps.js';
import { formatarBytes, formatarData, imagemBase64, apkUrlSegura } from '../formatar.js';
import { secao } from './_comum.js';
import { secaoInstalacao } from './_instalacao.js';

export function iconeDoApp(app, classe = 'app-icone') {
  const origem = imagemBase64(app.iconeMime, app.iconeBase64, 130000);
  if (origem) {
    return h('img', { class: classe, src: origem, alt: '', width: 88, height: 88 });
  }
  const inicial = typeof app.nome === 'string' && app.nome ? app.nome.charAt(0).toUpperCase() : '?';
  return h('div', { class: classe + ' app-icone-reservado', 'aria-hidden': 'true' }, inicial);
}

function ficha(app) {
  const versao = app.versaoAtual || {};
  const podeBaixar = apkUrlSegura(versao.apkUrl);
  const tamanho = formatarBytes(versao.tamanhoBytes);

  return h(
    'article',
    { class: 'ficha' },
    h(
      'div',
      { class: 'ficha-topo' },
      iconeDoApp(app),
      h(
        'div',
        {},
        h('h2', {}, app.nome),
        h('p', { class: 'suave ficha-dev' }, app.desenvolvedor || 'Guilherme Lucena Gonçalves')
      )
    ),
    app.resumo ? h('p', {}, app.resumo) : null,
    h(
      'p',
      { class: 'suave ficha-meta' },
      versao.nome ? `Versão ${versao.nome} · ${tamanho} · ${formatarData(versao.publicadaEm)}` : 'Versão ainda não informada'
    ),
    h(
      'div',
      { class: 'acoes' },
      podeBaixar
        ? h(
            'a',
            { class: 'botao botao-primario', href: versao.apkUrl, rel: 'noopener noreferrer' },
            icone('download'),
            `Baixar (${tamanho})`
          )
        : null,
      h('a', { class: 'botao botao-secundario', href: '/apps/' + app.slug }, 'Ver detalhes')
    )
  );
}

function aviso(titulo, texto, comRecarregar = false) {
  return h(
    'div',
    { class: 'caixa bloco' },
    h('h2', {}, titulo),
    h('p', {}, texto),
    comRecarregar
      ? h(
          'p',
          { class: 'acoes' },
          h('button', { type: 'button', class: 'botao botao-secundario', onclick: () => window.location.reload() }, 'Recarregar')
        )
      : null
  );
}

export default async function downloads() {
  let apps = [];
  let falhou = false;
  try {
    apps = await listarApps();
  } catch (erro) {
    console.error('Não consegui ler os downloads', erro);
    falhou = true;
  }

  let corpo;
  if (falhou) {
    corpo = aviso('Não consegui carregar os downloads', 'Pode ser a conexão. Tente de novo em instantes.', true);
  } else if (apps.length === 0) {
    corpo = aviso(
      'Ainda não há downloads publicados',
      'Quando eu publicar a primeira versão da Space Store ou do Creator Space, ela aparece aqui.'
    );
  } else {
    corpo = h('div', { class: 'fichas' }, apps.map(ficha));
  }

  return {
    titulo: 'Downloads',
    descricao:
      'Baixe a Space Store e o Creator Space para Android, com versão, tamanho, verificação de segurança e hash do arquivo.',
    conteudo: h(
      'div',
      {},
      h(
        'section',
        { class: 'pagina-topo' },
        h(
          'div',
          { class: 'container' },
          h('p', { class: 'sobretitulo' }, 'Downloads'),
          h('h1', {}, 'Baixe os apps'),
          h(
            'p',
            { class: 'lead' },
            'Os arquivos ficam no GitHub e este site mostra a versão, o tamanho e o hash de cada um, para você conferir o que baixou.'
          )
        )
      ),
      secao({ rotulo: 'apps-disponiveis' }, h('h2', { id: 'apps-disponiveis', class: 'so-leitor' }, 'Apps disponíveis'), corpo),
      secaoInstalacao()
    ),
  };
}
