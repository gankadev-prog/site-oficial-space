// Página "Ecossistema": o que é cada parte e como se conectam.

import { h, s } from '../dom.js';
import { secao, linkSeta } from './_comum.js';

function diagrama() {
  const nos = [
    { titulo: 'Desenvolvedor', sub: 'Escreve e envia o app', destaque: false },
    { titulo: 'Creator Space', sub: 'Painel onde o app é enviado', destaque: false },
    { titulo: 'Verificação', sub: 'Eu confiro: VirusTotal e conteúdo', destaque: true },
    { titulo: 'Space Store', sub: 'O app aparece para quem vai baixar', destaque: false },
  ];

  const svg = s(
    'svg',
    { class: 'diagrama', viewBox: '0 0 480 460', role: 'img', 'aria-labelledby': 'diagrama-titulo diagrama-desc' },
    s('title', { id: 'diagrama-titulo' }, 'Fluxo de publicação de um app'),
    s(
      'desc',
      { id: 'diagrama-desc' },
      'O desenvolvedor envia o app pelo Creator Space, eu faço a verificação e, depois disso, o app aparece na Space Store.'
    )
  );

  nos.forEach((no, i) => {
    const y = 10 + i * 120;
    svg.append(
      s('rect', { class: 'd-no' + (no.destaque ? ' d-no-destaque' : ''), x: 60, y, width: 360, height: 80, rx: 6 }),
      s('text', { class: 'd-titulo', x: 84, y: y + 34 }, no.titulo),
      s('text', { class: 'd-sub', x: 84, y: y + 60 }, no.sub)
    );
    if (i < nos.length - 1) {
      const base = y + 80;
      svg.append(
        s('path', {
          class: 'd-seta',
          d: `M240 ${base + 4} V${base + 34} M234 ${base + 27} L240 ${base + 35} L246 ${base + 27}`,
        })
      );
    }
  });

  return svg;
}

function topo() {
  return h(
    'section',
    { class: 'pagina-topo' },
    h(
      'div',
      { class: 'container' },
      h('p', { class: 'sobretitulo' }, 'O ecossistema'),
      h('h1', {}, 'Como os apps se encaixam'),
      h(
        'p',
        { class: 'lead' },
        'A Space Store é onde você baixa. O Creator Space é por onde os desenvolvedores publicam. Entre um e outro, eu confiro cada app antes de ele chegar na loja.'
      )
    )
  );
}

function fluxo() {
  return secao(
    { rotulo: 'fluxo', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo texto' },
      h('h2', { id: 'fluxo' }, 'O caminho de um app'),
      h(
        'p',
        {},
        'Todo app da loja segue o mesmo caminho. Quem desenvolve envia pelo Creator Space, eu faço a verificação e só então ele aparece na Space Store.'
      ),
      h(
        'div',
        { class: 'caixa' },
        h(
          'p',
          {},
          'Hoje os apps são distribuídos por este site, não pela Google Play. Na página de downloads explico como instalar e como conferir o arquivo.'
        )
      )
    ),
    h(
      'figure',
      { class: 'diagrama-figura' },
      diagrama(),
      h('figcaption', {}, 'Fluxo de publicação: do envio no Creator Space até a Space Store.')
    )
  );
}

function spaceStore() {
  return secao(
    { rotulo: 'space-store', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h('h2', { id: 'space-store' }, 'Space Store'),
      h('p', { class: 'suave' }, 'Loja de apps e jogos para Android.')
    ),
    h(
      'div',
      { class: 'texto' },
      h(
        'ul',
        { class: 'lista-simples' },
        h('li', {}, 'Página de detalhes para cada app, com desenvolvedor e informações sobre anúncios e compras.'),
        h('li', {}, 'Avaliações com estrelas e comentários.'),
        h('li', {}, 'Perfis de usuário com avatar, moldura, banner e @nick personalizados.'),
        h('li', {}, 'Selo de verificação e resultado da análise de segurança.'),
        h('li', {}, 'Controle parental.')
      ),
      linkSeta('/apps/space-store', 'Ir para a página da Space Store')
    )
  );
}

function creatorSpace() {
  return secao(
    { rotulo: 'creator-space', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h('h2', { id: 'creator-space' }, 'Creator Space'),
      h('p', { class: 'suave' }, 'Painel para quem desenvolve.')
    ),
    h(
      'div',
      { class: 'texto' },
      h('p', {}, 'É por ele que um desenvolvedor envia e gerencia os próprios apps na Space Store.'),
      h('p', {}, 'Cada envio passa pela minha verificação antes de aparecer na loja.'),
      h('p', {}, '[PREENCHER: o que mais vale destacar no painel do desenvolvedor.]'),
      linkSeta('/apps/creator-space', 'Ir para a página do Creator Space')
    )
  );
}

function verificacao() {
  return secao(
    { rotulo: 'verificacao', colunas: true },
    h(
      'div',
      { class: 'coluna-titulo' },
      h('h2', { id: 'verificacao' }, 'Verificação'),
      h('p', { class: 'suave' }, 'Antes de entrar na loja.')
    ),
    h(
      'div',
      { class: 'texto' },
      h(
        'p',
        {},
        'Todo app enviado pelo Creator Space passa por uma conferência minha: análise de segurança com o VirusTotal, revisão do conteúdo e moderação.'
      ),
      h(
        'p',
        {},
        'O selo de verificação mostra que o app passou por essa conferência. Ele não é garantia absoluta de que o app não tenha problemas. Os limites e o que acontece quando algo dá errado ficam explicados na política de publicação de apps.'
      ),
      linkSeta('/docs', 'Ler as políticas')
    )
  );
}

export default function ecossistema() {
  return {
    titulo: 'Ecossistema',
    descricao:
      'Como a Space Store e o Creator Space se conectam: do envio de um app até a loja.',
    conteudo: h('div', {}, topo(), fluxo(), spaceStore(), creatorSpace(), verificacao()),
  };
}
