// Página de detalhes de um app: /apps/space-store e /apps/creator-space.

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { obterApp, listarVersoes, listarCapturas, SLUGS } from '../dados-apps.js';
import {
  formatarBytes,
  formatarData,
  androidDeApi,
  descreverPermissao,
  imagemBase64,
  apkUrlSegura,
  relatorioSeguro,
  ehHashSha256,
} from '../formatar.js';
import { secao, paginaForm, linkSeta } from './_comum.js';
import { secaoInstalacao } from './_instalacao.js';
import { iconeDoApp } from './downloads.js';
import naoEncontrada from './naoEncontrada.js';

function blocoSecao(rotulo, titulo, ...filhos) {
  return secao(
    { rotulo, colunas: true },
    h('div', { class: 'coluna-titulo' }, h('h2', { id: rotulo }, titulo)),
    h('div', { class: 'texto' }, ...filhos)
  );
}

function paragrafos(texto) {
  return String(texto)
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => h('p', {}, p));
}

function simNao(valor) {
  return valor === true ? 'Sim' : 'Não';
}

function cabecalho(app, versao) {
  const podeBaixar = apkUrlSegura(versao.apkUrl);
  return h(
    'section',
    { class: 'pagina-topo' },
    h(
      'div',
      { class: 'container' },
      h(
        'div',
        { class: 'app-cabecalho' },
        iconeDoApp(app),
        h(
          'div',
          {},
          h('h1', {}, app.nome),
          h('p', { class: 'suave app-dev' }, app.desenvolvedor || 'Guilherme Lucena Gonçalves'),
          app.resumo ? h('p', { class: 'lead' }, app.resumo) : null
        )
      ),
      h(
        'div',
        { class: 'acoes' },
        podeBaixar
          ? h(
              'a',
              { class: 'botao botao-primario', href: versao.apkUrl, rel: 'noopener noreferrer' },
              icone('download'),
              `Baixar APK (${formatarBytes(versao.tamanhoBytes)})`
            )
          : h('p', { class: 'suave' }, 'O download desta versão ainda não está disponível.'),
        h('a', { class: 'botao botao-secundario', href: '#como-instalar' }, 'Como instalar')
      )
    )
  );
}

function faixa(app, versao) {
  const itens = [
    ['Versão', versao.nome || '—'],
    ['Tamanho', formatarBytes(versao.tamanhoBytes)],
    ['Classificação', app.classificacao || '—'],
    ['Android', Number.isFinite(versao.minSdk) ? androidDeApi(versao.minSdk) + ' ou mais novo' : '—'],
  ];
  return h(
    'div',
    { class: 'container faixa-area' },
    h(
      'dl',
      { class: 'faixa' },
      itens.map(([rotulo, valor]) => h('div', {}, h('dt', {}, rotulo), h('dd', {}, String(valor))))
    )
  );
}

function blocoCapturas() {
  const area = h('div', {
    class: 'capturas',
    role: 'region',
    tabindex: '0',
    'aria-label': 'Capturas de tela',
  });
  const secaoEl = secao({ rotulo: 'capturas' }, h('h2', { id: 'capturas', class: 'so-leitor' }, 'Capturas de tela'), area);
  secaoEl.hidden = true;

  return {
    el: secaoEl,
    preencher(lista) {
      const imagens = [];
      for (const captura of lista.slice(0, 6)) {
        const origem = imagemBase64(captura.mime, captura.dadosBase64, 200000);
        if (!origem) continue;
        const alt = typeof captura.alt === 'string' ? captura.alt.slice(0, 120) : '';
        imagens.push(h('img', { src: origem, alt: alt || 'Captura de tela do app', loading: 'lazy' }));
      }
      if (imagens.length > 0) {
        area.replaceChildren(...imagens);
        secaoEl.hidden = false;
      }
    },
  };
}

function blocoSeguranca(app, versao) {
  const seg = app.seguranca || {};
  const itens = [];

  itens.push(
    h(
      'p',
      {},
      seg.verificado === true
        ? `Conferi este app antes de publicar, em ${formatarData(seg.verificadoEm)}.`
        : 'Este app ainda não passou pela minha verificação de segurança.'
    )
  );
  itens.push(h('p', {}, 'Selo verde de segurança: ', h('strong', {}, simNao(seg.seloVerde))));

  if (Number.isFinite(seg.virusTotalMotores) && seg.virusTotalMotores > 0) {
    const maliciosos = Number.isFinite(seg.virusTotalMaliciosos) ? seg.virusTotalMaliciosos : 0;
    const suspeitos = Number.isFinite(seg.virusTotalSuspeitos) ? seg.virusTotalSuspeitos : 0;
    itens.push(
      h(
        'p',
        {},
        `Análise no VirusTotal: ${maliciosos} de ${seg.virusTotalMotores} antivírus marcaram o arquivo como malicioso e ${suspeitos} como suspeito. `,
        relatorioSeguro(seg.virusTotalUrl)
          ? h('a', { href: seg.virusTotalUrl, target: '_blank', rel: 'noopener noreferrer' }, 'Ver o relatório')
          : null
      )
    );
  }

  itens.push(
    h(
      'p',
      { class: 'suave' },
      'A verificação reduz o risco, mas não é uma garantia absoluta. Confira também o hash do arquivo que você baixou.'
    )
  );

  if (ehHashSha256(versao.sha256)) {
    const botaoCopiar = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Copiar hash');
    const retorno = h('p', { class: 'suave', 'aria-live': 'polite' });
    botaoCopiar.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(versao.sha256);
        retorno.textContent = 'Hash copiado.';
      } catch (erro) {
        retorno.textContent = 'Não consegui copiar. Segure o texto do hash para selecionar e copiar.';
      }
    });
    itens.push(
      h('h3', { class: 'subtitulo' }, 'Hash SHA-256 desta versão'),
      h('code', { class: 'hash' }, versao.sha256),
      h('div', { class: 'acoes' }, botaoCopiar),
      retorno
    );
  }

  const permissoes = Array.isArray(versao.permissoes)
    ? versao.permissoes.filter((p) => p && typeof p.id === 'string').slice(0, 40)
    : [];
  if (permissoes.length > 0) {
    itens.push(
      h('h3', { class: 'subtitulo' }, 'Permissões que o app pede'),
      h(
        'ul',
        { class: 'permissoes' },
        permissoes.map((permissao) => {
          const { rotulo, id } = descreverPermissao(permissao.id);
          return h(
            'li',
            {},
            h('strong', {}, rotulo),
            h('code', { class: 'permissao-id' }, id),
            typeof permissao.motivo === 'string' && permissao.motivo ? h('p', {}, permissao.motivo) : null
          );
        })
      )
    );
  }

  return blocoSecao('seguranca', 'Segurança', ...itens);
}

function blocoVersoes() {
  const lista = h('ul', { class: 'linhas' });
  const secaoEl = blocoSecao('versoes', 'Histórico de versões', lista);
  secaoEl.hidden = true;

  return {
    el: secaoEl,
    preencher(versoes) {
      const linhas = versoes
        .filter((v) => v && typeof v.nome === 'string')
        .map((v) =>
          h(
            'li',
            { class: 'linha versao-linha' },
            h(
              'div',
              {},
              h('h3', {}, 'Versão ' + v.nome),
              h('p', {}, `${formatarData(v.publicadaEm)} · ${formatarBytes(v.tamanhoBytes)}`),
              v.novidades ? h('p', {}, String(v.novidades)) : null
            ),
            apkUrlSegura(v.apkUrl)
              ? h('a', { class: 'link-seta', href: v.apkUrl, rel: 'noopener noreferrer' }, 'Baixar', icone('download', { tamanho: 18 }))
              : null
          )
        );
      if (linhas.length > 1) {
        lista.replaceChildren(...linhas);
        secaoEl.hidden = false;
      }
    },
  };
}

function dadosEstruturados(app, versao) {
  const dados = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: app.nome,
    operatingSystem: 'Android',
    author: { '@type': 'Person', name: app.desenvolvedor || 'Guilherme Lucena Gonçalves' },
  };
  if (app.resumo) dados.description = app.resumo;
  if (versao.nome) dados.softwareVersion = versao.nome;
  if (Number.isFinite(versao.tamanhoBytes)) dados.fileSize = formatarBytes(versao.tamanhoBytes);
  if (apkUrlSegura(versao.apkUrl)) dados.downloadUrl = versao.apkUrl;
  if (versao.publicadaEm && typeof versao.publicadaEm.toDate === 'function') {
    dados.datePublished = versao.publicadaEm.toDate().toISOString();
  }
  return dados;
}

function paginaNaoPublicada(slug) {
  const nome = slug === 'creator-space' ? 'Creator Space' : 'Space Store';
  return {
    titulo: nome,
    semIndexar: true,
    conteudo: paginaForm(
      {
        sobretitulo: 'App',
        titulo: nome,
        lead: 'Esta página ainda não foi publicada. Volte em breve.',
      },
      linkSeta('/downloads', 'Ver os downloads')
    ),
  };
}

function paginaDeErro() {
  return {
    titulo: 'App',
    semIndexar: true,
    conteudo: paginaForm(
      { titulo: 'Não consegui carregar este app', lead: 'Pode ser a conexão. Recarregue a página para tentar de novo.' },
      h(
        'p',
        { class: 'acoes' },
        h('button', { type: 'button', class: 'botao botao-primario', onclick: () => window.location.reload() }, 'Recarregar')
      )
    ),
  };
}

export default async function app({ params }) {
  const slug = params.slug;
  if (!SLUGS.includes(slug)) return naoEncontrada();

  let dados;
  try {
    dados = await obterApp(slug);
  } catch (erro) {
    console.error('Não consegui ler o app', erro);
    return paginaDeErro();
  }
  if (!dados) return paginaNaoPublicada(slug);

  const versao = dados.versaoAtual && typeof dados.versaoAtual === 'object' ? dados.versaoAtual : {};
  const capturas = blocoCapturas();
  const versoes = blocoVersoes();

  // Capturas e histórico carregam depois, para a página aparecer logo.
  listarCapturas(slug).then(capturas.preencher).catch((erro) => console.error('Capturas', erro));
  listarVersoes(slug).then(versoes.preencher).catch((erro) => console.error('Versões', erro));

  const conteudo = h(
    'div',
    {},
    cabecalho(dados, versao),
    faixa(dados, versao),
    capturas.el,
    dados.descricao
      ? blocoSecao(
          'sobre',
          'Sobre este app',
          ...paragrafos(dados.descricao),
          h(
            'p',
            { class: 'suave' },
            `Anúncios: ${simNao(dados.anuncios)} · Compras no app: ${simNao(dados.comprasNoApp)}`
          )
        )
      : null,
    versao.novidades
      ? blocoSecao(
          'novidades',
          'O que há de novo',
          h('p', { class: 'suave' }, `Versão ${versao.nome || ''} · ${formatarData(versao.publicadaEm)}`),
          ...paragrafos(versao.novidades)
        )
      : null,
    blocoSeguranca(dados, versao),
    secaoInstalacao(),
    versoes.el
  );

  return {
    titulo: dados.nome,
    descricao: dados.resumo || `Baixe o ${dados.nome} para Android.`,
    jsonld: dadosEstruturados(dados, versao),
    conteudo,
  };
}
