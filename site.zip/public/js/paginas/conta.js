// Página "Sua conta": perfil, confirmação de e-mail, sair e excluir a conta.

import { h } from '../dom.js';
import { navegar } from '../roteador.js';
import {
  esperarAuth,
  salvarPerfil,
  sair,
  reenviarVerificacao,
  recarregarUsuario,
  excluirConta,
  temSenha,
} from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { campo, caixaMarcar, areaAlerta, botaoEnvio, ocupar, focarPrimeiroErro } from './_forms.js';
import { paginaForm, redirecionar } from './_comum.js';

function formatarData(carimbo) {
  if (!carimbo || typeof carimbo.toDate !== 'function') return '—';
  return carimbo.toDate().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
}

function paginaDeErro() {
  return {
    titulo: 'Sua conta',
    semIndexar: true,
    conteudo: paginaForm(
      {
        titulo: 'Não consegui carregar seus dados',
        lead: 'Pode ser a conexão. Recarregue a página para tentar de novo.',
      },
      h(
        'p',
        { class: 'acoes' },
        h(
          'button',
          { type: 'button', class: 'botao botao-primario', onclick: () => window.location.reload() },
          'Recarregar'
        )
      )
    ),
  };
}

export default async function conta() {
  const estado = await esperarAuth();

  if (!estado.usuario) return redirecionar('/entrar?voltar=' + encodeURIComponent('/conta'));
  if (estado.erroPerfil) return paginaDeErro();
  if (!estado.perfil) return redirecionar('/cadastrar?voltar=' + encodeURIComponent('/conta'));

  const { usuario, perfil } = estado;

  // ---------- Confirmação de e-mail ----------
  const alertaEmail = areaAlerta();
  let blocoEmail = null;
  if (!usuario.emailVerified) {
    const botaoReenviar = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Reenviar e-mail');
    const botaoConfirmei = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Já confirmei');

    botaoReenviar.addEventListener('click', async () => {
      alertaEmail.limpar();
      botaoReenviar.disabled = true;
      try {
        await reenviarVerificacao();
        alertaEmail.ok('Enviei o e-mail de novo. Confira também a caixa de spam.');
      } catch (erro) {
        alertaEmail.erro(mensagemDeErro(erro));
      } finally {
        botaoReenviar.disabled = false;
      }
    });

    botaoConfirmei.addEventListener('click', async () => {
      alertaEmail.limpar();
      botaoConfirmei.disabled = true;
      try {
        const novo = await recarregarUsuario();
        if (novo.usuario && novo.usuario.emailVerified) {
          navegar('/conta', { substituir: true });
        } else {
          alertaEmail.erro('Ainda não consta como confirmado. Abra o link do e-mail e tente de novo.');
        }
      } catch (erro) {
        alertaEmail.erro(mensagemDeErro(erro));
      } finally {
        botaoConfirmei.disabled = false;
      }
    });

    blocoEmail = h(
      'div',
      { class: 'caixa bloco' },
      h('h2', {}, 'Confirme seu e-mail'),
      h('p', {}, `Enviei um link para ${usuario.email}. Abra o link para confirmar que o e-mail é seu.`),
      alertaEmail.el,
      h('div', { class: 'acoes' }, botaoReenviar, botaoConfirmei)
    );
  }

  // ---------- Perfil ----------
  const alertaPerfil = areaAlerta();
  const nome = campo({
    id: 'nome',
    rotulo: 'Nome',
    autocompletar: 'name',
    maximo: 50,
    valor: perfil.nome || '',
  });
  const bio = campo({
    id: 'bio',
    rotulo: 'Bio',
    tipo: 'textarea',
    maximo: 160,
    valor: perfil.bio || '',
    ajuda: 'Uma frase sobre você. Até 160 caracteres.',
  });
  const botaoSalvar = botaoEnvio('Salvar perfil');

  async function salvar(evento) {
    evento.preventDefault();
    alertaPerfil.limpar();
    nome.limpar();
    bio.limpar();

    const valorNome = nome.valor().trim();
    if (!valorNome) nome.erro('Digite seu nome.');
    if (bio.valor().trim().length > 160) bio.erro('A bio pode ter no máximo 160 caracteres.');
    if (nome.entrada.getAttribute('aria-invalid') || bio.entrada.getAttribute('aria-invalid')) {
      focarPrimeiroErro([nome, bio]);
      return;
    }

    ocupar(botaoSalvar, true, 'Salvando…');
    try {
      await salvarPerfil({ nome: valorNome, bio: bio.valor() });
      alertaPerfil.ok('Perfil salvo.');
    } catch (erro) {
      alertaPerfil.erro(mensagemDeErro(erro));
    } finally {
      ocupar(botaoSalvar, false);
    }
  }

  const formPerfil = h(
    'form',
    { class: 'form', novalidate: true, onsubmit: salvar },
    alertaPerfil.el,
    nome.el,
    bio.el,
    h('div', { class: 'acoes' }, botaoSalvar)
  );

  // ---------- Dados da conta ----------
  const dados = h(
    'dl',
    { class: 'dados' },
    h('dt', {}, '@nick'),
    h('dd', {}, '@' + perfil.nick),
    h('dt', {}, 'E-mail'),
    h('dd', {}, usuario.email || '—'),
    h('dt', {}, 'Membro desde'),
    h('dd', {}, formatarData(perfil.criadoEm))
  );

  // ---------- Sair ----------
  const alertaSair = areaAlerta();
  const botaoSair = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Sair deste aparelho');
  botaoSair.addEventListener('click', async () => {
    botaoSair.disabled = true;
    try {
      await sair();
      navegar('/');
    } catch (erro) {
      alertaSair.erro(mensagemDeErro(erro));
      botaoSair.disabled = false;
    }
  });

  // ---------- Excluir conta ----------
  const corpo = h('div', {});
  const alertaExcluir = areaAlerta();
  const senhaExcluir = campo({
    id: 'senha-excluir',
    rotulo: 'Sua senha',
    tipo: 'password',
    autocompletar: 'current-password',
  });
  const confirmar = caixaMarcar({
    id: 'confirmar-exclusao',
    rotulo: 'Entendi que isso não pode ser desfeito.',
  });
  const botaoExcluir = botaoEnvio('Excluir minha conta', 'botao botao-perigo');
  const usaSenha = temSenha(usuario);

  async function excluir(evento) {
    evento.preventDefault();
    alertaExcluir.limpar();
    senhaExcluir.limpar();
    confirmar.limpar();

    if (usaSenha && !senhaExcluir.valor()) senhaExcluir.erro('Digite sua senha para confirmar.');
    if (!confirmar.marcado()) confirmar.erro('Marque aqui para confirmar.');
    const campos = usaSenha ? [senhaExcluir, confirmar] : [confirmar];
    if (campos.some((c) => c.entrada.getAttribute('aria-invalid') === 'true')) {
      focarPrimeiroErro(campos);
      return;
    }

    ocupar(botaoExcluir, true, 'Excluindo…');
    try {
      await excluirConta({ senha: senhaExcluir.valor() });
      corpo.replaceChildren(
        h('h2', {}, 'Conta excluída'),
        h('p', {}, 'Apaguei seu perfil, seu @nick e seus dados de cadastro. Obrigado por ter passado por aqui.'),
        h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/' }, 'Voltar ao início'))
      );
      window.scrollTo(0, 0);
    } catch (erro) {
      alertaExcluir.erro(mensagemDeErro(erro));
      ocupar(botaoExcluir, false);
    }
  }

  const detalhesExcluir = h(
    'details',
    { class: 'perigo' },
    h('summary', {}, 'Excluir minha conta'),
    h(
      'form',
      { class: 'form', novalidate: true, onsubmit: excluir },
      h(
        'p',
        {},
        'Isso apaga seu perfil, seu @nick e seus dados de cadastro. Fica guardado apenas o registro de que você aceitou os Termos, sem nome nem e-mail, para eu poder comprovar o consentimento.'
      ),
      usaSenha ? null : h('p', { class: 'suave' }, 'Vou pedir para você entrar com o Google de novo, para confirmar que é você.'),
      alertaExcluir.el,
      usaSenha ? senhaExcluir.el : null,
      confirmar.el,
      h('div', { class: 'acoes' }, botaoExcluir)
    )
  );

  corpo.append(
    blocoEmail,
    h('h2', { class: 'titulo-bloco' }, 'Perfil'),
    formPerfil,
    h('h2', { class: 'titulo-bloco' }, 'Dados da conta'),
    dados,
    h('h2', { class: 'titulo-bloco' }, 'Sessão'),
    alertaSair.el,
    h('div', { class: 'acoes' }, botaoSair),
    h('h2', { class: 'titulo-bloco' }, 'Excluir conta'),
    detalhesExcluir
  );

  return {
    titulo: 'Sua conta',
    semIndexar: true,
    descricao: 'Perfil e configurações da sua conta.',
    conteudo: paginaForm({ sobretitulo: 'Conta', titulo: 'Sua conta', lead: '@' + perfil.nick }, corpo),
  };
}
