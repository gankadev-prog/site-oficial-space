// Página "Sua conta": perfil, confirmação de e-mail, sair e excluir a conta.

import { h } from '../dom.js';
import { navegar } from '../roteador.js';
import {
  esperarAuth,
  salvarPerfil,
  sair,
  reenviarVerificacao,
  recarregarUsuario,
  excluirConta,
  temSenha,
} from '../auth.js';
import { mensagemDeErro } from '../erros.js';
import { imagemBase64 } from '../formatar.js';
import { verificarModeracao } from '../dados-comunidade.js';
import { campo, caixaMarcar, areaAlerta, botaoEnvio, ocupar, focarPrimeiroErro } from './_forms.js';
import { paginaForm, redirecionar } from './_comum.js';

async function prepararImagem(arquivo, ladoMaximo, limiteBase64) {
  if (!arquivo || !['image/jpeg', 'image/png', 'image/webp'].includes(arquivo.type)) throw new Error('Escolha uma imagem JPEG, PNG ou WebP.');
  if (typeof createImageBitmap !== 'function') throw new Error('Este navegador não conseguiu preparar a imagem.');
  const bitmap = await createImageBitmap(arquivo);
  const escala = Math.min(1, ladoMaximo / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * escala));
  canvas.height = Math.max(1, Math.round(bitmap.height * escala));
  const contexto = canvas.getContext('2d');
  if (!contexto) throw new Error('Não consegui preparar a imagem.');
  contexto.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  for (const qualidade of [0.82, 0.72, 0.62, 0.5]) {
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', qualidade));
    if (!blob) continue;
    const base64 = (await new Promise((resolve, reject) => {
      const leitor = new FileReader(); leitor.onload = () => resolve(String(leitor.result).split(',')[1] || ''); leitor.onerror = () => reject(new Error('Não consegui ler a imagem.')); leitor.readAsDataURL(blob);
    }));
    if (base64.length <= limiteBase64) return { base64, mime: 'image/jpeg' };
  }
  throw new Error('A imagem ainda ficou grande. Escolha outra ou corte-a antes de enviar.');
}

function formatarData(carimbo) {
  if (!carimbo || typeof carimbo.toDate !== 'function') return '—';
  return carimbo.toDate().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
}

function paginaDeErro() {
  return {
    titulo: 'Sua conta',
    semIndexar: true,
    conteudo: paginaForm(
      {
        titulo: 'Não consegui carregar seus dados',
        lead: 'Pode ser a conexão. Recarregue a página para tentar de novo.',
      },
      h(
        'p',
        { class: 'acoes' },
        h(
          'button',
          { type: 'button', class: 'botao botao-primario', onclick: () => window.location.reload() },
          'Recarregar'
        )
      )
    ),
  };
}

export default async function conta() {
  const estado = await esperarAuth();

  if (!estado.usuario) return redirecionar('/entrar?voltar=' + encodeURIComponent('/conta'));
  if (estado.erroPerfil) return paginaDeErro();
  if (!estado.perfil) return redirecionar('/cadastrar?voltar=' + encodeURIComponent('/conta'));

  const { usuario, perfil } = estado;

  // ---------- Confirmação de e-mail ----------
  const alertaEmail = areaAlerta();
  let blocoEmail = null;
  if (!usuario.emailVerified) {
    const botaoReenviar = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Reenviar e-mail');
    const botaoConfirmei = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Já confirmei');

    botaoReenviar.addEventListener('click', async () => {
      alertaEmail.limpar();
      botaoReenviar.disabled = true;
      try {
        await reenviarVerificacao();
        alertaEmail.ok('Enviei o e-mail de novo. Confira também a caixa de spam.');
      } catch (erro) {
        alertaEmail.erro(mensagemDeErro(erro));
      } finally {
        botaoReenviar.disabled = false;
      }
    });

    botaoConfirmei.addEventListener('click', async () => {
      alertaEmail.limpar();
      botaoConfirmei.disabled = true;
      try {
        const novo = await recarregarUsuario();
        if (novo.usuario && novo.usuario.emailVerified) {
          navegar('/conta', { substituir: true });
        } else {
          alertaEmail.erro('Ainda não consta como confirmado. Abra o link do e-mail e tente de novo.');
        }
      } catch (erro) {
        alertaEmail.erro(mensagemDeErro(erro));
      } finally {
        botaoConfirmei.disabled = false;
      }
    });

    blocoEmail = h(
      'div',
      { class: 'caixa bloco' },
      h('h2', {}, 'Confirme seu e-mail'),
      h('p', {}, `Enviei um link para ${usuario.email}. Abra o link para confirmar que o e-mail é seu.`),
      alertaEmail.el,
      h('div', { class: 'acoes' }, botaoReenviar, botaoConfirmei)
    );
  }

  // ---------- Perfil ----------
  const alertaPerfil = areaAlerta();
  const nome = campo({
    id: 'nome',
    rotulo: 'Nome',
    autocompletar: 'name',
    maximo: 50,
    valor: perfil.nome || '',
  });
  const bio = campo({
    id: 'bio',
    rotulo: 'Bio',
    tipo: 'textarea',
    maximo: 160,
    valor: perfil.bio || '',
    ajuda: 'Uma frase sobre você. Até 160 caracteres.',
  });
  const avatarAtual = imagemBase64(perfil.avatarMime, perfil.avatarBase64, 150000);
  const bannerAtual = imagemBase64(perfil.bannerMime, perfil.bannerBase64, 220000);
  const avatarArquivo = h('input', { id: 'perfil-avatar', type: 'file', accept: 'image/jpeg,image/png,image/webp', 'aria-describedby': 'perfil-avatar-ajuda' });
  const bannerArquivo = h('input', { id: 'perfil-banner', type: 'file', accept: 'image/jpeg,image/png,image/webp', 'aria-describedby': 'perfil-banner-ajuda' });
  const avatarPreview = avatarAtual ? h('img', { class: 'avatar perfil-avatar-grande', src: avatarAtual, alt: 'Avatar atual' }) : h('span', { class: 'avatar-fallback perfil-avatar-grande', 'aria-hidden': 'true' }, (perfil.nome || '?').slice(0, 1));
  const bannerPreview = bannerAtual ? h('img', { class: 'banner-perfil', src: bannerAtual, alt: 'Banner atual' }) : h('p', { class: 'suave' }, 'Ainda sem banner.');
  const moldura = h('select', { id: 'perfil-moldura' },
    h('option', { value: '', selected: !perfil.moldura }, 'Sem moldura'),
    h('option', { value: 'linha', selected: perfil.moldura === 'linha' }, 'Linha'),
    h('option', { value: 'folha', selected: perfil.moldura === 'folha' }, 'Folha'),
    h('option', { value: 'arco', selected: perfil.moldura === 'arco' }, 'Arco'));
  avatarArquivo.addEventListener('change', () => { const arquivo = avatarArquivo.files?.[0]; if (arquivo) avatarPreview.src = URL.createObjectURL(arquivo); });
  bannerArquivo.addEventListener('change', () => { const arquivo = bannerArquivo.files?.[0]; if (arquivo && bannerPreview.tagName === 'IMG') bannerPreview.src = URL.createObjectURL(arquivo); else if (arquivo) bannerPreview.replaceWith(h('img', { class: 'banner-perfil', src: URL.createObjectURL(arquivo), alt: 'Prévia do banner' })); });
  const botaoSalvar = botaoEnvio('Salvar perfil');

  async function salvar(evento) {
    evento.preventDefault();
    alertaPerfil.limpar();
    nome.limpar();
    bio.limpar();

    const valorNome = nome.valor().trim();
    if (!valorNome) nome.erro('Digite seu nome.');
    if (bio.valor().trim().length > 160) bio.erro('A bio pode ter no máximo 160 caracteres.');
    if (nome.entrada.getAttribute('aria-invalid') || bio.entrada.getAttribute('aria-invalid')) {
      focarPrimeiroErro([nome, bio]);
      return;
    }

    ocupar(botaoSalvar, true, 'Salvando…');
    try {
      const dados = { nome: valorNome, bio: bio.valor(), moldura: moldura.value };
      if (avatarArquivo.files?.[0]) {
        const imagem = await prepararImagem(avatarArquivo.files[0], 256, 150000);
        dados.avatarBase64 = imagem.base64; dados.avatarMime = imagem.mime;
      }
      if (bannerArquivo.files?.[0]) {
        const imagem = await prepararImagem(bannerArquivo.files[0], 1280, 220000);
        dados.bannerBase64 = imagem.base64; dados.bannerMime = imagem.mime;
      }
      await salvarPerfil(dados);
      alertaPerfil.ok('Perfil salvo.');
    } catch (erro) {
      alertaPerfil.erro(mensagemDeErro(erro));
    } finally {
      ocupar(botaoSalvar, false);
    }
  }

  const formPerfil = h(
    'form',
    { class: 'form', novalidate: true, onsubmit: salvar },
    alertaPerfil.el,
    nome.el,
    bio.el,
    h('fieldset', { class: 'perfil-imagens' }, h('legend', {}, 'Aparência pública'),
      h('div', { class: 'campo' }, h('label', { for: 'perfil-avatar' }, 'Avatar'), h('p', { id: 'perfil-avatar-ajuda', class: 'campo-ajuda' }, 'JPEG, PNG ou WebP; reduzido neste aparelho.'), avatarPreview, avatarArquivo),
      h('div', { class: 'campo' }, h('label', { for: 'perfil-banner' }, 'Banner'), h('p', { id: 'perfil-banner-ajuda', class: 'campo-ajuda' }, 'JPEG, PNG ou WebP; reduzido neste aparelho.'), bannerPreview, bannerArquivo),
      h('div', { class: 'campo' }, h('label', { for: 'perfil-moldura' }, 'Moldura'), moldura)),
    h('div', { class: 'acoes' }, botaoSalvar)
  );

  // ---------- Dados da conta ----------
  const dados = h(
    'dl',
    { class: 'dados' },
    h('dt', {}, '@nick'),
    h('dd', {}, '@' + perfil.nick),
    h('dt', {}, 'E-mail'),
    h('dd', {}, usuario.email || '—'),
    h('dt', {}, 'Membro desde'),
    h('dd', {}, formatarData(perfil.criadoEm))
  );

  // ---------- Sair ----------
  const alertaSair = areaAlerta();
  const botaoSair = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Sair deste aparelho');
  botaoSair.addEventListener('click', async () => {
    botaoSair.disabled = true;
    try {
      await sair();
      navegar('/');
    } catch (erro) {
      alertaSair.erro(mensagemDeErro(erro));
      botaoSair.disabled = false;
    }
  });

  // ---------- Excluir conta ----------
  const corpo = h('div', {});
  const alertaExcluir = areaAlerta();
  const senhaExcluir = campo({
    id: 'senha-excluir',
    rotulo: 'Sua senha',
    tipo: 'password',
    autocompletar: 'current-password',
  });
  const confirmar = caixaMarcar({
    id: 'confirmar-exclusao',
    rotulo: 'Entendi que isso não pode ser desfeito.',
  });
  const botaoExcluir = botaoEnvio('Excluir minha conta', 'botao botao-perigo');
  const usaSenha = temSenha(usuario);

  async function excluir(evento) {
    evento.preventDefault();
    alertaExcluir.limpar();
    senhaExcluir.limpar();
    confirmar.limpar();

    if (usaSenha && !senhaExcluir.valor()) senhaExcluir.erro('Digite sua senha para confirmar.');
    if (!confirmar.marcado()) confirmar.erro('Marque aqui para confirmar.');
    const campos = usaSenha ? [senhaExcluir, confirmar] : [confirmar];
    if (campos.some((c) => c.entrada.getAttribute('aria-invalid') === 'true')) {
      focarPrimeiroErro(campos);
      return;
    }

    ocupar(botaoExcluir, true, 'Excluindo…');
    try {
      await excluirConta({ senha: senhaExcluir.valor() });
      corpo.replaceChildren(
        h('h2', {}, 'Conta excluída'),
        h('p', {}, 'Apaguei seu perfil, seu @nick e seus dados de cadastro. Obrigado por ter passado por aqui.'),
        h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/' }, 'Voltar ao início'))
      );
      window.scrollTo(0, 0);
    } catch (erro) {
      alertaExcluir.erro(mensagemDeErro(erro));
      ocupar(botaoExcluir, false);
    }
  }

  const detalhesExcluir = h(
    'details',
    { class: 'perigo' },
    h('summary', {}, 'Excluir minha conta'),
    h(
      'form',
      { class: 'form', novalidate: true, onsubmit: excluir },
      h(
        'p',
        {},
        'Isso apaga seu perfil, seu @nick e seus dados de cadastro. Fica guardado apenas o registro de que você aceitou os Termos, sem nome nem e-mail, para eu poder comprovar o consentimento.'
      ),
      usaSenha ? null : h('p', { class: 'suave' }, 'Vou pedir para você entrar com o Google de novo, para confirmar que é você.'),
      alertaExcluir.el,
      usaSenha ? senhaExcluir.el : null,
      confirmar.el,
      h('div', { class: 'acoes' }, botaoExcluir)
    )
  );

  corpo.append(
    blocoEmail,
    h('h2', { class: 'titulo-bloco' }, 'Perfil'),
    formPerfil,
    h('h2', { class: 'titulo-bloco' }, 'Dados da conta'),
    dados,
    h('h2', { class: 'titulo-bloco' }, 'Sessão'),
    alertaSair.el,
    h('div', { class: 'acoes' }, botaoSair),
    h('h2', { class: 'titulo-bloco' }, 'Excluir conta'),
    detalhesExcluir
  );
  if (await verificarModeracao(usuario.uid).catch(() => false)) corpo.append(h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/conta/moderacao' }, 'Ver denúncias')));

  return {
    titulo: 'Sua conta',
    semIndexar: true,
    descricao: 'Perfil e configurações da sua conta.',
    conteudo: paginaForm({ sobretitulo: 'Conta', titulo: 'Sua conta', lead: '@' + perfil.nick }, corpo),
  };
}
