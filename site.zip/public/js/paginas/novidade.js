// Página de uma novidade: /novidades/AAAA-MM-DD-titulo

import { h } from '../dom.js';
import { icone } from '../icones.js';
import { obterNovidade, listarImagens, SLUG_VALIDO } from '../dados-novidades.js';
import { renderizarCorpo } from '../markup.js';
import { formatarData, imagemBase64 } from '../formatar.js';
import { paginaForm, linkSeta, avisoPrevia } from './_comum.js';
import { etiquetas, linhaMeta } from './novidades.js';
import naoEncontrada from './naoEncontrada.js';

function paginaNaoExiste() {
  return {
    titulo: 'Novidade não encontrada',
    semIndexar: true,
    conteudo: paginaForm(
      {
        sobretitulo: 'Novidades',
        titulo: 'Não achei essa novidade',
        lead: 'Ela pode ter sido removida, ou o endereço está errado.',
      },
      linkSeta('/novidades', 'Ver todas as novidades')
    ),
  };
}

function paginaDeErro() {
  return {
    titulo: 'Novidade',
    semIndexar: true,
    conteudo: paginaForm(
      { titulo: 'Não consegui carregar esta novidade', lead: 'Pode ser a conexão. Recarregue a página para tentar de novo.' },
      h(
        'p',
        { class: 'acoes' },
        h('button', { type: 'button', class: 'botao botao-primario', onclick: () => window.location.reload() }, 'Recarregar')
      )
    ),
  };
}

function botaoCompartilhar(novidade) {
  const botao = h('button', { type: 'button', class: 'botao botao-secundario' }, 'Compartilhar');
  const retorno = h('span', { class: 'suave', 'aria-live': 'polite' });

  botao.addEventListener('click', async () => {
    const endereco = window.location.origin + '/novidades/' + novidade.slug;
    if (navigator.share) {
      try {
        await navigator.share({ title: novidade.titulo, url: endereco });
        return;
      } catch (erro) {
        // A pessoa fechou a janela de compartilhar: não há o que fazer.
        if (erro && erro.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(endereco);
      retorno.textContent = 'Link copiado.';
    } catch (erro) {
      retorno.textContent = 'Não consegui copiar. O endereço está na barra do navegador.';
    }
  });

  return h('div', { class: 'acoes' }, botao, retorno);
}

function dadosEstruturados(n) {
  const dados = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: n.titulo,
    author: { '@type': 'Person', name: n.autor || 'Guilherme Lucena Gonçalves' },
    mainEntityOfPage: window.location.origin + '/novidades/' + n.slug,
  };
  if (n.resumo) dados.description = n.resumo;
  if (n.publicadoEm && typeof n.publicadoEm.toDate === 'function') dados.datePublished = n.publicadoEm.toDate().toISOString();
  if (n.atualizadoEm && typeof n.atualizadoEm.toDate === 'function') dados.dateModified = n.atualizadoEm.toDate().toISOString();
  return dados;
}

export default async function novidade({ params }) {
  const slug = params.slug;
  if (!SLUG_VALIDO.test(slug)) return naoEncontrada();

  let dados;
  try {
    dados = await obterNovidade(slug);
  } catch (erro) {
    console.error('Não consegui ler a novidade', erro);
    return paginaDeErro();
  }
  if (!dados || typeof dados.titulo !== 'string' || typeof dados.corpo !== 'string') return paginaNaoExiste();

  const { nos, imagens } = renderizarCorpo(dados.corpo);

  // As imagens chegam depois do texto, para a página abrir logo.
  if (imagens.size > 0) {
    listarImagens(slug)
      .then((lista) => {
        for (const imagem of lista) {
          const alvo = imagens.get(imagem.ordem);
          const origem = imagemBase64(imagem.mime, imagem.dadosBase64, 200000);
          if (alvo && origem) alvo.setAttribute('src', origem);
        }
      })
      .catch((erro) => console.error('Imagens', erro));
  }

  const ehPrevia = Boolean(dados.previa);

  return {
    titulo: dados.titulo,
    descricao: dados.resumo || 'Novidade da Space Store e do Creator Space.',
    semIndexar: ehPrevia,
    jsonld: ehPrevia ? null : dadosEstruturados(dados),
    conteudo: h(
      'div',
      {},
      ehPrevia ? avisoPrevia() : null,
      h(
        'article',
        { class: 'pagina-curta artigo' },
        h(
          'div',
          { class: 'container' },
          h('p', { class: 'sobretitulo' }, h('a', { href: '/novidades' }, 'Novidades')),
          h('h1', {}, dados.titulo),
          h('p', { class: 'novidade-meta' }, ehPrevia ? 'Rascunho' : linhaMeta(dados)),
          etiquetas(dados.tags),
          h('div', { class: 'corpo-novidade' }, ...nos),
          h(
            'p',
            { class: 'suave assinatura' },
            `${dados.autor || 'Guilherme Lucena Gonçalves'}${dados.atualizadoEm ? ' · atualizado em ' + formatarData(dados.atualizadoEm) : ''}`
          ),
          ehPrevia ? null : botaoCompartilhar(dados),
          linkSeta('/novidades', 'Ver todas as novidades')
        )
      )
    ),
  };
}
