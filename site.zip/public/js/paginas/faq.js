import { h } from '../dom.js';
import { paginaForm } from './_comum.js';
import { destacarPreencher } from '../preencher.js';

const perguntas = [
  ['Como instalo um app?', 'Baixe o APK pela ficha do app, permita a instalação para a fonte usada no seu Android e confira o SHA-256 antes de instalar. Veja o passo a passo em Downloads.'],
  ['Por que o Play Protect pode avisar?', 'O Android pode avisar porque o arquivo foi baixado fora da Google Play. Um aviso não prova que há problema. Se o Play Protect disser que detectou algo perigoso, não instale e escreva para spacestorew@gmail.com.'],
  ['Como confiro o SHA-256?', 'Compare o código na ficha do app com o SHA-256 calculado para o arquivo baixado usando uma ferramenta de sua confiança. Se os códigos forem diferentes, não instale.'],
  ['Os apps são gratuitos?', '[PREENCHER: confirmar se cada app é gratuito e se há anúncios ou compras no app; veja essas informações na ficha de cada versão.]'],
  ['Como envio meu app pelo Creator Space?', '[PREENCHER: instruções atuais de envio pelo Creator Space, requisitos de pacote e prazos de revisão.]'],
  ['Como excluo minha conta?', 'Entre, abra Sua conta e use a seção Excluir minha conta. A exclusão pede confirmação de identidade; fica guardado apenas o registro mínimo de aceite dos documentos, sem nome nem e-mail.'],
  ['Como denuncio algo na comunidade?', 'Abra a publicação, o comentário ou o perfil e escolha Denunciar. Se não conseguir entrar no site, escreva para spacestorew@gmail.com.'],
  ['Quem pode criar conta?', 'É preciso ter pelo menos 16 anos. Entre 16 e 17 anos, o cadastro exige confirmar que o responsável concorda.'],
  ['Onde ficam meus dados?', 'O site usa Google Firebase para autenticação e Firestore para os dados. A Política de Privacidade explica o que fica público e o que é privado.'],
];

export default function faq() {
  return {
    titulo: 'Perguntas frequentes',
    descricao: 'Respostas sobre instalação, segurança, conta, dados e participação na comunidade.',
    conteudo: paginaForm({ sobretitulo: 'Ajuda', titulo: 'Perguntas frequentes', lead: 'Se algo ainda não estiver explicado, fale comigo pelo e-mail spacestorew@gmail.com.' },
      h('div', { class: 'faq-lista' }, perguntas.map(([pergunta, resposta]) => h('details', { class: 'faq-item' }, h('summary', {}, pergunta), h('p', {}, destacarPreencher(resposta)))),
        h('p', { class: 'acoes' }, h('a', { class: 'botao botao-secundario', href: '/contato' }, 'Ir para contato')))),
  };
}
