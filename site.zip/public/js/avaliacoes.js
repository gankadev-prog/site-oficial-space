import { h, s } from './dom.js';
import { esperarAuth } from './auth.js';
import { obterMinhaAvaliacao, resumirAvaliacoes, salvarAvaliacao } from './dados-comunidade.js';
import { mensagemDeErro } from './erros.js';

function estrela() {
  return s('svg', { viewBox: '0 0 24 24', width: 20, height: 20, fill: 'currentColor', 'aria-hidden': 'true', focusable: 'false' },
    s('path', { d: 'm12 2.8 2.8 5.7 6.3.9-4.55 4.43 1.08 6.26L12 17.13l-5.63 2.96 1.08-6.26L2.9 9.4l6.3-.91L12 2.8z' }));
}

function atualizarLista(resumo, status, lista) {
  if (!resumo.quantidade) status.textContent = 'Ainda sem avaliações.';
  else status.textContent = `Média ${resumo.media.toFixed(1)} de 5, calculada no navegador sobre ${resumo.quantidade} avaliações.`;
  lista.replaceChildren(...(resumo.itens || []).map((item) => h('li', { class: 'linha avaliacao-item' },
    h('p', {}, h('a', { href: '/u/' + encodeURIComponent(item.autorNick || '') }, '@' + (item.autorNick || 'pessoa')), ' · ', `${item.nota} de 5 estrelas`),
    item.comentario ? h('p', {}, item.comentario) : h('p', { class: 'suave' }, 'Sem comentário.'),
    h('time', {}, item.atualizadoEm?.toDate?.().toLocaleDateString('pt-BR') || 'Data não informada'))));
}

export function iniciarAvaliacoes(slug, raiz) {
  const status = h('p', { role: 'status', 'aria-live': 'polite' }, 'Carregando avaliações…');
  const lista = h('ul', { class: 'linhas', 'aria-label': 'Avaliações recentes' });
  const aviso = h('p', { class: 'suave' }, 'O resumo é calculado no navegador sobre até 200 avaliações; não há agregador no servidor.');
  const formArea = h('div', {});
  raiz.replaceChildren(status, lista, aviso, formArea);
  Promise.all([resumirAvaliacoes(slug), esperarAuth()]).then(async ([dados, estado]) => {
    atualizarLista(dados, status, lista);
    if (!estado.usuario || !estado.perfil) {
      formArea.append(h('p', {}, h('a', { href: '/entrar?voltar=' + encodeURIComponent(window.location.pathname) }, 'Entre para avaliar este app.')));
      return;
    }
    if (!estado.usuario.emailVerified) { formArea.append(h('p', {}, 'Confirme seu e-mail em ', h('a', { href: '/conta' }, 'Sua conta'), ' antes de avaliar.')); return; }
    if (estado.perfil.suspenso === true) { formArea.append(h('p', {}, 'Esta conta não pode avaliar no momento.')); return; }
    const atual = await obterMinhaAvaliacao(slug, estado.usuario.uid).catch(() => null);
    const grupo = h('div', { class: 'avaliacao-estrelas' });
    for (let n = 1; n <= 5; n += 1) {
      const input = h('input', { type: 'radio', name: 'nota', id: `nota-${n}`, value: n, checked: atual?.nota === n });
      grupo.append(h('label', { for: `nota-${n}`, 'aria-label': `${n} ${n === 1 ? 'estrela' : 'estrelas'}` }, input, estrela(), h('span', { class: 'so-leitor' }, String(n))));
    }
    const atualizarEstrelas = () => { const nota = Number(grupo.querySelector('input:checked')?.value || 0); Array.from(grupo.querySelectorAll('label')).forEach((el, i) => el.classList.toggle('selecionada', i < nota)); };
    grupo.addEventListener('change', atualizarEstrelas); atualizarEstrelas();
    const comentario = h('textarea', { id: 'avaliacao-comentario', maxlength: '500', rows: '3' });
    comentario.value = atual?.comentario || '';
    const alerta = h('p', { role: 'status', 'aria-live': 'polite' });
    const botao = h('button', { type: 'submit', class: 'botao botao-secundario' }, atual ? 'Atualizar avaliação' : 'Salvar avaliação');
    const form = h('form', { class: 'form', onsubmit: async (evento) => {
      evento.preventDefault(); const selecionado = grupo.querySelector('input:checked');
      if (!selecionado) { alerta.textContent = 'Escolha uma nota de 1 a 5 estrelas.'; return; }
      botao.disabled = true;
      try { await salvarAvaliacao(slug, selecionado.value, comentario.value); alerta.textContent = 'Avaliação salva.'; const novo = await resumirAvaliacoes(slug); atualizarLista(novo, status, lista); }
      catch (erro) { alerta.textContent = mensagemDeErro(erro); }
      finally { botao.disabled = false; }
    } }, h('fieldset', { class: 'avaliacao-grupo' }, h('legend', {}, atual ? 'Edite sua nota' : 'Sua nota, de 1 a 5 estrelas'), grupo), h('div', { class: 'campo' }, h('label', { for: 'avaliacao-comentario' }, 'Comentário opcional (até 500 caracteres)'), comentario), alerta, botao);
    formArea.append(form);
  }).catch((erro) => { status.textContent = `Não consegui carregar avaliações. ${mensagemDeErro(erro)}`; });
}
