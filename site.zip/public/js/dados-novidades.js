// Leitura das novidades (siteNovidades no Firestore). Quem escreve é só o admin.
// O id de cada novidade começa com a data (AAAA-MM-DD-titulo), então ordenar pelo id
// também ordena por data e dispensa índice composto.

import { db } from './firebase.js';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  documentId,
} from 'https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js';

export const POR_PAGINA = 10;
export const SLUG_VALIDO = /^\d{4}-\d{2}-\d{2}-[a-z0-9]+(?:-[a-z0-9]+)*$/;

function montarPagina(docs, quantidade) {
  const itens = docs.slice(0, quantidade).map((d) => ({ slug: d.id, ...d.data() }));
  return {
    itens,
    temMais: docs.length > quantidade,
    ultimo: itens.length > 0 ? itens[itens.length - 1].slug : null,
  };
}

// Plano B, se o Firestore reclamar de índice: lê as publicadas e ordena aqui mesmo.
async function listarSemIndice(depoisDe, quantidade) {
  const resposta = await getDocs(query(collection(db, 'siteNovidades'), where('publicado', '==', true), limit(200)));
  let docs = resposta.docs.slice().sort((a, b) => (a.id < b.id ? 1 : -1));
  if (depoisDe) docs = docs.filter((d) => d.id < depoisDe);
  return montarPagina(docs.slice(0, quantidade + 1), quantidade);
}

// Devolve { itens, temMais, ultimo }. "depoisDe" é o id do último item já mostrado.
export async function listarNovidades({ depoisDe = null, quantidade = POR_PAGINA } = {}) {
  try {
    const condicoes = [where('publicado', '==', true), orderBy(documentId(), 'desc')];
    if (depoisDe) condicoes.push(startAfter(depoisDe));
    condicoes.push(limit(quantidade + 1));
    const resposta = await getDocs(query(collection(db, 'siteNovidades'), ...condicoes));
    return montarPagina(resposta.docs, quantidade);
  } catch (erro) {
    if (erro && erro.code === 'failed-precondition') return listarSemIndice(depoisDe, quantidade);
    throw erro;
  }
}

// Devolve a novidade, ou null se não existe ou não é pública.
// Se vier com publicado = false, quem leu é o admin: a página mostra como prévia.
export async function obterNovidade(slug) {
  if (!SLUG_VALIDO.test(slug)) return null;
  try {
    const resposta = await getDoc(doc(db, 'siteNovidades', slug));
    if (!resposta.exists()) return null;
    const dados = resposta.data();
    return { slug, ...dados, previa: dados.publicado !== true };
  } catch (erro) {
    if (erro && erro.code === 'permission-denied') return null;
    throw erro;
  }
}

export async function listarImagens(slug) {
  const resposta = await getDocs(query(collection(db, 'siteNovidades', slug, 'imagens'), orderBy('ordem')));
  return resposta.docs.map((d) => d.data());
}
